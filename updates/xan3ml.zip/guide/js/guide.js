import { GUIDE_BASE_VIDEO_URL, GUIDE_UI_TEXT, GUIDE_CATEGORIES, GUIDE_ARTICLES } from './data.js';

let currentLang = localStorage.getItem('xan3_app_lang') === 'uk' ? 'uk' : 'ru';
let activeCategory = 'all';
let searchQuery = '';
let highlightedTopicId = null;

// Читаем URL-параметры при открытии (?cat=fleet или ?topic=fleet_delayed_start)
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('cat')) activeCategory = urlParams.get('cat');
if (urlParams.get('topic')) highlightedTopicId = urlParams.get('topic');

const searchInput = document.getElementById('search-input');
const clearBtn = document.getElementById('clear-search');
const categoryFiltersEl = document.getElementById('category-filters');
const articlesContainerEl = document.getElementById('articles-container');
const emptyStateEl = document.getElementById('empty-state');

function init() {
    bindEvents();
    updateStaticTexts();
    renderCategories();
    renderArticles();

    if (highlightedTopicId) {
        const targetCard = document.getElementById(`topic-${highlightedTopicId}`);
        if (targetCard) {
            targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
}

function bindEvents() {
    // Переключатель языка
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            currentLang = btn.dataset.lang;
            localStorage.setItem('xan3_app_lang', currentLang);
            updateStaticTexts();
            renderCategories();
            renderArticles();
        });
    });

    // Живой поиск с debounce 120 мс
    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            searchQuery = e.target.value.trim();
            clearBtn.classList.toggle('hidden', searchQuery.length === 0);
            renderArticles();
        }, 120);
    });

    clearBtn.addEventListener('click', () => {
        searchInput.value = '';
        searchQuery = '';
        clearBtn.classList.add('hidden');
        renderArticles();
        searchInput.focus();
    });
}

function updateStaticTexts() {
    const t = GUIDE_UI_TEXT[currentLang];
    document.getElementById('ui-title').textContent = t.title;
    document.getElementById('ui-subtitle').textContent = t.subtitle;
    searchInput.placeholder = t.searchPlaceholder;
    document.getElementById('ui-empty-text').textContent = t.emptySearch;

    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.lang === currentLang);
    });
}

function renderCategories() {
    categoryFiltersEl.innerHTML = '';
    GUIDE_CATEGORIES.forEach(cat => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `cat-btn ${cat.id === activeCategory ? 'active' : ''}`;
        btn.textContent = cat.name[currentLang];
        btn.addEventListener('click', () => {
            activeCategory = cat.id;
            renderCategories();
            renderArticles();
        });
        categoryFiltersEl.appendChild(btn);
    });
}

function escapeRegExp(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function highlightText(text, tokens) {
    if (!tokens.length) return text;
    const pattern = new RegExp(`(${tokens.map(escapeRegExp).join('|')})`, 'gi');
    return text.replace(pattern, '<mark class="xan-highlight">$1</mark>');
}

function renderArticles() {
    const t = GUIDE_UI_TEXT[currentLang];
    const tokens = searchQuery.toLowerCase().split(/\s+/).filter(Boolean);

    const filtered = GUIDE_ARTICLES.filter(article => {
        if (activeCategory !== 'all' && article.category !== activeCategory) {
            return false;
        }
        if (!tokens.length) return true;

        // Поиск по текущему языку + фоллбэк по второму языку
        const searchablePool = [
            article.title.ru, article.title.uk,
            article.summary.ru, article.summary.uk,
            ...article.steps.ru, ...article.steps.uk,
            ...article.tags.ru, ...article.tags.uk
        ].join(' ').toLowerCase();

        return tokens.every(token => searchablePool.includes(token));
    });

    articlesContainerEl.innerHTML = '';
    emptyStateEl.classList.toggle('hidden', filtered.length > 0);

    filtered.forEach(article => {
        const catObj = GUIDE_CATEGORIES.find(c => c.id === article.category);
        const catName = catObj ? catObj.name[currentLang] : '';

        const card = document.createElement('article');
        card.className = `article-card ${article.id === highlightedTopicId ? 'highlighted-topic' : ''}`;
        card.id = `topic-${article.id}`;

        const stepsHtml = article.steps[currentLang]
            .map(step => `<li>${highlightText(step, tokens)}</li>`)
            .join('');

        card.innerHTML = `
            <div class="card-header">
                <h2 class="card-title">${highlightText(article.title[currentLang], tokens)}</h2>
                <span class="card-badge">${catName}</span>
            </div>
            <p class="card-summary">${highlightText(article.summary[currentLang], tokens)}</p>
            <ol class="card-steps">${stepsHtml}</ol>
            ${article.videoFile ? `<div class="video-section">
                <button type="button" class="video-toggle-btn">${t.watchVideo}</button>
                <div class="video-wrapper hidden"></div>
            </div>` : ''}
        `;

        // Ленивая инициализация видео по клику
        if (article.videoFile) {
            const toggleBtn = card.querySelector('.video-toggle-btn');
            const wrapper = card.querySelector('.video-wrapper');
            let isLoaded = false;

            toggleBtn.addEventListener('click', () => {
                const isHidden = wrapper.classList.toggle('hidden');
                toggleBtn.textContent = isHidden ? t.watchVideo : t.hideVideo;

                if (!isHidden && !isLoaded) {
                    isLoaded = true;
                    const video = document.createElement('video');
                    video.src = GUIDE_BASE_VIDEO_URL + article.videoFile;
                    video.controls = true;
                    video.autoplay = true;
                    video.muted = true;
                    video.loop = true;
                    video.playsInline = true;
                    video.preload = 'metadata';

                    video.onerror = () => {
                        wrapper.innerHTML = `<div class="video-fallback">${t.videoSoon}</div>`;
                    };

                    wrapper.appendChild(video);
                }
            });
        }

        articlesContainerEl.appendChild(card);
    });
}

init();
