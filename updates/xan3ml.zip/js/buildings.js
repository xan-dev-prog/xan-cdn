// js/buildings.js — Тюнинг страниц Сооружения, Исследования, Верфь, Оборона

import { _ } from './query.js';
import { spaces, nsn, calculateShips } from './utils.js';
import { TRANSPORT_SPECS, TECH_TREE } from './game_data.js';

/**
 * Внутренняя функция расчёта МТ и БТ с учётом расхода топлива
 */
function generateShipsOutput(metal = 0, crystal = 0, uran = 0) {
    const m = Math.abs(parseInt(metal, 10)) || 0;
    const c = Math.abs(parseInt(crystal, 10)) || 0;
    const u = Math.abs(parseInt(uran, 10)) || 0;
    const totalResources = m + c + u;

    if (totalResources <= 0) return '';

    // Считаем через единую утилиту из utils.js по твоим игровым тарифам (132 и 330)
    const mtCount = calculateShips('MT', totalResources);
    const btCount = calculateShips('BT', totalResources);

    const mtTitle = t('b_mt_title').replace('{num}', spaces(mtCount));
    const btTitle = t('b_bt_title').replace('{num}', spaces(btCount));

    return `
        <div class="res-left-ships">
            <label title="${mtTitle}">
                МТ <input type="text" value="${mtCount}" readonly />
            </label>
            <br />
            <label title="${btTitle}">
                БТ <input type="text" value="${btCount}" readonly />
            </label>
            <div class="showresdiv">${t('b_copied')}</div>
        </div>
    `.trim();
}


/**
 * Главная стартовая функция модуля, вызываемая из switch(CURRENT_PAGE)
 */
export function initBuildingsPage() {
    _('body').insertAdjacentHTML('beforeend', `<link rel="stylesheet" href="${chrome.runtime.getURL('css/buildings.css')}" />`);

    // ПРАВИЛО ВЫСШЕГО ПРИОРИТЕТА v3.0: Изолированный префикс xan3_
    let hidIds = localStorage.getItem('xan3_hidBuildRes') ? localStorage.getItem('xan3_hidBuildRes').split('|') : [];
    const table = _('tr[id^="id_"]').closest('table');

    if (table) {
        table.querySelector('tbody').insertAdjacentHTML('afterbegin', `
            <tr>
                <th class="sett" colspan="3">
                    <img width="16" src="${chrome.runtime.getURL('images/settings.png')}" title="Настройки показа" />
                    <div id="setShowHide"><h3>${t('b_hide_show')}</h3></div>
                </th>
            </tr>
        `.trim());

        const div = _('#setShowHide');
        const img = div.closest('th').querySelector('img');
        const names = [..._('.name a', 1)].map(x => x.textContent);
        const trs = [..._('tr[id^="id_"]', 1)];

        trs.forEach(tr => {
            const num = tr.id.replace(/id_/, '');
            if (hidIds.includes(num)) {
                tr.style.display = 'none';
            }
        });

        img.addEventListener('click', () => {
            div.style.display = div.style.display === 'block' ? 'none' : 'block';
        });

        div.insertAdjacentHTML('beforeend', TECH_TREE
            .filter(z => names.includes(_t(z[1]))) // Мультиязычный поиск совпадений
            .sort((a, b) => {
                const nameA = a[1][window.currentLang] || a[1]['ru'];
                const nameB = b[1][window.currentLang] || b[1]['ru'];
                return nameA.localeCompare(nameB);
            })
            .map(x => `<span class="${hidIds.includes(x[0]) ? 'noShow' : 'Show'}" id="tech_${x[0]}">${_t(x[1])}</span>`)
            .join(', ')
        );

        div.addEventListener('click', function(e) {
            const targ = e.target;
            if (targ.tagName === 'SPAN') {
                const ID = targ.id.replaceAll(/[^\d]+/g, '');
                targ.className = targ.className === 'noShow' ? 'Show' : 'noShow';
                
                const targetTr = _('#id_' + ID);
                if (targetTr) {
                    targetTr.style.display = targ.className === 'noShow' ? 'none' : 'table-row';
                }

                if (hidIds.includes(ID)) {
                    hidIds.splice(hidIds.indexOf(ID), 1);
                } else {
                    hidIds.push(ID);
                }

                if (hidIds.length > 0) {
                    localStorage.setItem('xan3_hidBuildRes', hidIds.join('|'));
                } else {
                    localStorage.removeItem('xan3_hidBuildRes');
                }
            }
        });
    }
    /* === Парсинг нехватки ресурсов и привязка клика для копирования === */
    setTimeout(() => {
        // Вспомогательная внутренняя функция для обработки клика по ресурсам нехватки
        const setupNegativeResourceClick = (selector) => {
            const elements = selector === undefined ? [] : _(selector, 1);
            
            elements.forEach(el => {
                const currentTitle = el.getAttribute('title') || '';
                const spaceIndex = currentTitle.indexOf(' ');
                const formattedTitle = t('b_not_enough') + (spaceIndex !== -1 ? currentTitle.substr(spaceIndex) : '') + '\n' + t('b_click_copy');
                
                el.setAttribute('title', formattedTitle);
                el.style.cursor = 'pointer';

                el.addEventListener('click', () => {
                    const textToCopy = nsn(el.textContent) * -1; // убираем минус
                    
                    // Копируем через современный Clipboard API без создания временных инпутов
                    navigator.clipboard.writeText(textToCopy).then(() => {
                        const resDiv = el.closest('tr')?.querySelector('.showresdiv');
                        if (resDiv) {
                            resDiv.textContent = t('b_copied');
                            resDiv.style.display = 'block';
                            setTimeout(() => { resDiv.style.display = 'none'; }, 1000);
                        }
                    });
                });
            });
        };

        // Запускаем обработку для каждого типа нехватки ресов
        setupNegativeResourceClick('.metal.negative');
        setupNegativeResourceClick('.crystal.negative');
        setupNegativeResourceClick('.deuterium.negative');

        /* === Логика вывода необходимых кораблей под нехваткой ресурсов === */
        const leftResBlocks = _('.left-res', 1);
        leftResBlocks.forEach(block => {
            if (block.textContent.includes('-')) {
                const spans = block.querySelectorAll('span');
                
                // Извлекаем чистые цифры нехватки ресурсов из спанов
                const a = spans && spans[0]?.textContent.includes('-') ? nsn(spans[0].textContent.replace('-', '')) : '0';
				const b = spans && spans[1]?.textContent.includes('-') ? nsn(spans[1].textContent.replace('-', '')) : '0';
				const c = spans && spans[2]?.textContent.includes('-') ? nsn(spans[2].textContent.replace('-', '')) : '0';

                // Генерируем блок кораблей и вставляем его в предыдущую ячейку
                const targetTd = block.closest('tr').children[0];
                if (targetTd) {
                    targetTd.insertAdjacentHTML('beforeend', generateShipsOutput(a, b, c));
                    
                    // Вешаем копирование на инпуты МТ и БТ внутри созданного блока
                    targetTd.querySelectorAll('.res-left-ships input').forEach(input => {
                        input.addEventListener('click', (e) => {
                            e.stopPropagation(); // Защита от срабатывания клика на родительских элементах
                            navigator.clipboard.writeText(input.value).then(() => {
                                const resDiv = input.closest('.res-left-ships')?.querySelector('.showresdiv');
                                if (resDiv) {
                                    resDiv.style.display = 'block';
                                    setTimeout(() => { resDiv.style.display = 'none'; }, 1000);
                                }
                            });
                        });
                    });
                }
            }
        });
    }, 500);

    /* ========================================================================== */
    /* === НАЧАЛО: ВРАТА (Оптимизировано, заработает автоматически при gid=43) === */
    /* ========================================================================== */
	console.log("Работает часть модуля buildings для gid=43 (Врата)");
    if (location.search === '?gid=43') {
        const takeAllButtons = _('[title="Взять все"]', 1);
        console.log('takeAllButtons.length = ' + takeAllButtons.length);
        if (takeAllButtons.length > 1) {
            // Красим разделительную полоску через новый класс в CSS
            _('th[colspan="3"]:not(.c)', 1).forEach(th => th.classList.add('gate-divider-th'));
            
            const targetContainer = _('[title="Куда телепортируем"]', 1)?.closest('tr')?.previousElementSibling?.querySelector('td');
            
            if (targetContainer) {
                targetContainer.innerHTML = `<input id="takeall" class="btn-gate-takeall" type="button" value="${t('b_gate_all')}" title="${t('b_gate_title')}" />`;
                
                const takeAllBtn = _('#takeall');
                if (takeAllBtn) {
                    takeAllBtn.addEventListener('click', () => {
                        _('[title="Взять все"]', 1).forEach(btn => btn.click());
                        takeAllBtn.value = takeAllBtn.value === t('b_gate_all') ? t('b_gate_reset') : t('b_gate_all');
                    });
                }
            }
            window.scrollBy(0, 500);
        }
    }
    /* ========================================================================== */
    /* === КОНЕЦ: ВРАТА ========================================================= */
    /* ========================================================================== */
}
