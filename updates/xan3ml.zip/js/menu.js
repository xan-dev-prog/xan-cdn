// js/menu.js — Часть 1 из 2 (Централизованная генерация навигации XAN)

import { _ } from './query.js';
import { MENU_LINKS, MENU_ALLOWED_PAGES } from './game_data.js'; // Импортируем наш новый справочник
import { CURRENT_PAGE, CURRENT_UNIVERSE } from './utils.js';

const JUMPGATE_TTL_NORMAL = 12 * 60 * 60 * 1000; // 12 часов для обычного состояния
const JUMPGATE_TTL_BUILDING = 30 * 60 * 1000;   // 30 минут, если идёт постройка уровня

/**
 * Проверяет, разрешено ли кастомное меню на текущей странице игры
 * @returns {boolean}
 */
function isMenuAllowed() {
    // На главной странице Обзора меню активно ВСЕГДА и неизменяемо
    if (CURRENT_PAGE === 'overview') return true;
    
    // Считываем строку из LocalStorage без каких-либо дефолтных костылей внутри кода
    const allowedPagesStr = localStorage.getItem('xan3_menu_pages') || '';
    
    // Если ключ отсутствует или пустой — на внешних страницах меню строить ЗАПРЕЩЕНО
    if (!allowedPagesStr) return false;
    
    const allowedPages = allowedPagesStr.split(';');
    return allowedPages.includes(CURRENT_PAGE);
}

/**
 * Возвращает объект с информацией о текущей Луне по первому select в документе
 * @returns {{ isMoon: boolean, moonId: string|null }}
 */
function getCurrentMoonInfo() {
    const firstSelect = document.querySelector('select');
    const selectedOption = firstSelect && firstSelect.selectedIndex >= 0
        ? firstSelect.options[firstSelect.selectedIndex]
        : null;

    if (!selectedOption || !selectedOption.text.includes('*')) {
        return { isMoon: false, moonId: null };
    }

    const cpMatch = (selectedOption.value || '').match(/cp=(\d+)/);
    return {
        isMoon: true,
        moonId: cpMatch ? cpMatch[1] : null
    };
}

/**
 * Читает кэш уровней Врат для текущей вселенной из localStorage
 * @returns {Object}
 */
function getJumpGateCache() {
    try {
        const raw = localStorage.getItem(`xan3_jumpgates_${CURRENT_UNIVERSE}`);
        return raw ? JSON.parse(raw) : {};
    } catch (e) {
        return {};
    }
}

/**
 * Сохраняет кэш уровней Врат для текущей вселенной в localStorage
 * @param {Object} cache
 */
function saveJumpGateCache(cache) {
    try {
        localStorage.setItem(`xan3_jumpgates_${CURRENT_UNIVERSE}`, JSON.stringify(cache));
    } catch (e) {
        console.warn('[XAN] Ошибка сохранения кэша Врат:', e);
    }
}

/**
 * Извлекает данные об уровне Врат из DOM (текущего документа или ответа fetch)
 * @param {Document} rootDoc
 * @returns {{ level: number, rawText: string, isUpgrading: boolean, updatedAt: number }|null}
 */
function parseJumpGateFromRoot(rootDoc) {
    const levelEl = rootDoc.querySelector('.desc-header .level');
    if (!levelEl) return null;

    // Убираем текст дочернего span ("Уровень:"), оставляем чистое значение ("7" или "7 -> 8")
    const clone = levelEl.cloneNode(true);
    const labelSpan = clone.querySelector('span');
    if (labelSpan) labelSpan.remove();

    const rawText = clone.textContent.replace(/\s+/g, ' ').trim();
    const levelMatch = rawText.match(/^(\d+)/);
    const currentLevel = levelMatch ? parseInt(levelMatch[1], 10) : 0;
    const isUpgrading = rawText.includes('->');

    return {
        level: currentLevel,
        rawText: rawText,
        isUpgrading: isUpgrading,
        updatedAt: Date.now()
    };
}

/**
 * Создаёт DOM-элемент пункта меню (<li>)
 * @param {Object} item
 * @param {string} viewMode
 * @param {string} planetParams
 * @param {string} [customTitle]
 * @returns {HTMLLIElement}
 */
function createMenuItemElement(item, viewMode, planetParams, customTitle = '') {
    const li = document.createElement('li');
    li.className = `xan-menu-item ${CURRENT_PAGE === item.id ? 'xan-active-item' : ''}`;
    if (item.url === 'buildings.php?gid=43') {
        li.dataset.xanJumpgate = 'true';
    }

    const a = document.createElement('a');
    let href = item.url;
    if (item.url === 'imperium.php') href += planetParams;

    a.href = href;
    if (item.target) a.target = item.target;

    // Условие ТЗ: Атрибут title добавляется строго в режиме иконок с динамическим переводом
    if (viewMode === 'icon') {
        a.title = customTitle || _t(item.name);
    }

    // Создаем спан для иконки из спрайта
    const iconSpan = document.createElement('span');
    iconSpan.className = item.icon ? `xan-menu-icon ${item.icon}` : '';
    if (!item.icon) {
        iconSpan.style.display = 'inline-block';
        iconSpan.style.width = '26px';
    }

    // Создаем спан для текстового названия с динамическим переводом
    const textSpan = document.createElement('span');
    textSpan.className = 'xan-menu-text';
    textSpan.textContent = _t(item.name);

    a.appendChild(iconSpan);
    a.appendChild(textSpan);
    li.appendChild(a);
    return li;
}

/**
 * Формирует строку title для пункта Врат с учётом уровня и активной стройки
 * @param {Object} item
 * @param {Object|undefined} gateData
 * @returns {string}
 */
function formatJumpGateTitle(item, gateData) {
    const baseName = _t(item.name);
    if (!gateData || !gateData.level) return baseName;
    const levelLabel = gateData.rawText || gateData.level;
    return `${baseName} (${levelLabel})`;
}
// js/menu.js — Часть 2 из 2

/**
 * Фоново запрашивает страницу Врат, парсит уровень из .desc-header .level и обновляет кэш и DOM
 * @param {string} moonId
 * @param {Object} jumpGateItem
 * @param {HTMLUListElement} ul
 * @param {string} viewMode
 * @param {string} planetParams
 */
async function syncJumpGateLevel(moonId, jumpGateItem, ul, viewMode, planetParams) {
    try {
        const response = await fetch('buildings.php?gid=43', { credentials: 'same-origin' });
        if (!response.ok) return;

        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const parsedData = parseJumpGateFromRoot(doc);
        if (!parsedData) return;

        const cache = getJumpGateCache();
        cache[moonId] = parsedData;
        saveJumpGateCache(cache);

        // Обновляем DOM, если статус Врат изменился после фонового запроса
        const existingLi = ul.querySelector('li[data-xan-jumpgate="true"]');
        if (parsedData.level > 0) {
            const newTitle = formatJumpGateTitle(jumpGateItem, parsedData);
            if (existingLi) {
                const link = existingLi.querySelector('a');
                if (link && viewMode === 'icon') {
                    link.title = newTitle;
                }
            } else {
                const newLi = createMenuItemElement(jumpGateItem, viewMode, planetParams, newTitle);
                const xanBtnLi = ul.querySelector('.xan-settings-trigger-item');
                if (xanBtnLi) {
                    ul.insertBefore(newLi, xanBtnLi);
                } else {
                    ul.appendChild(newLi);
                }
            }
        } else if (existingLi) {
            existingLi.remove();
        }
    } catch (e) {
        console.warn('[XAN] Фоновая проверка Врат не удалась:', e);
    }
}

/**
 * Главная централизованная функция инициализации меню XAN для ВСЕХ страниц
 * @param {string} targetSelector - Селектор элемента игры (например, 'table'), куда или перед которым монтируется меню
 */
export function initCustomMenu(targetSelector) {
    if (!isMenuAllowed()) return;

    // Защита от повторного рендеринга меню на странице
    if (document.getElementById('menu')) return;

    const targetContainer = document.querySelector(targetSelector);
    if (!targetContainer) return;

    // Считываем настройки отображения (text или icon)
    const viewMode = localStorage.getItem('xan3_menu_view_mode') || 'text';
    
    // Получаем маску видимости пунктов меню пользователя
    const userFormedMenu = localStorage.getItem('xan3_UserFormedMenu')
        ? localStorage.getItem('xan3_UserFormedMenu').split(';').map(Number)
        : [];

    // Вытаскиваем параметры текущей планеты из селектора игры для корректной ссылки на Империю
    const planetSelect = _('.menu-item');
    let planetParams = '';
    if (planetSelect) {
        const selectedValue = planetSelect.value || '';
        if (selectedValue.includes('&')) {
            planetParams = selectedValue.substring(selectedValue.indexOf('&'));
        }
    }

    // Проверяем, находится ли игрок на Луне и получаем её ID (cp)
    const { isMoon, moonId } = getCurrentMoonInfo();

    // Фильтруем и сортируем пункты меню строго по правилам настроек пользователя (Мультиязычная сортировка)
    let userLinks = [...MENU_LINKS];
    if (userFormedMenu.length > 0) {
        userLinks = MENU_LINKS.filter((_, i) => userFormedMenu[i] === 1);
    }

    // Отделяем «Врата» (buildings.php?gid=43) для показа только на Луне и строго в конце списка
    const jumpGateItem = userLinks.find(item => item.url === 'buildings.php?gid=43');
    userLinks = userLinks
        .filter(item => item.url !== 'buildings.php?gid=43')
        .sort((a, b) => _t(a.name).localeCompare(_t(b.name)));

    // Проверяем кэш Врат для текущей Луны
    let gateData = null;
    let shouldSyncGate = false;
    if (jumpGateItem && isMoon && moonId) {
        const cache = getJumpGateCache();
        const isJumpGatePage = CURRENT_PAGE === 'buildings' && new URLSearchParams(window.location.search).get('gid') === '43';

        if (isJumpGatePage) {
            const freshData = parseJumpGateFromRoot(document);
            if (freshData) {
                cache[moonId] = freshData;
                saveJumpGateCache(cache);
            }
        }

        gateData = cache[moonId];
        const ttl = gateData && gateData.isUpgrading ? JUMPGATE_TTL_BUILDING : JUMPGATE_TTL_NORMAL;

        if (!isJumpGatePage && (!gateData || (Date.now() - gateData.updatedAt) > ttl)) {
            shouldSyncGate = true;
        }

        if (gateData && gateData.level > 0) {
            userLinks.push(jumpGateItem);
        }
    }

    // Создаем наш единый JS-контейнер меню
    const menuWrap = document.createElement('div');
    menuWrap.id = 'menu';
    menuWrap.className = `xan-mode-${viewMode}`;
    
    // Динамически инжектируем URL спрайта для обхода ограничений безопасности CSP
    const spriteUrl = chrome.runtime.getURL('images/icons_20.png');
    menuWrap.style.setProperty('--xan-menu-sprite', `url(${spriteUrl})`);

    const ul = document.createElement('ul');
    ul.className = 'xan-menu-list';

    // Собираем элементы меню
    userLinks.forEach(item => {
        const customTitle = item.url === 'buildings.php?gid=43'
            ? formatJumpGateTitle(item, gateData)
            : '';
        const li = createMenuItemElement(item, viewMode, planetParams, customTitle);
        ul.appendChild(li);
    });

    menuWrap.appendChild(ul);
    
    // МУТАЦИЯ КОДА: Ссылка «XAN» теперь добавляется СТРОГО на странице Обзора!
    if (CURRENT_PAGE === 'overview') {
        const settingsLi = document.createElement('li');
        settingsLi.className = 'xan-menu-item xan-settings-trigger-item';
        
        const settingsA = document.createElement('a');
        settingsA.href = '#null';
        settingsA.id = 'xan-lnk';
        settingsA.title = t('m_settings_title'); // Внедрено: Мультиязычный тайтл настроек XAN
        settingsA.textContent = 'XAN';
        
        settingsLi.appendChild(settingsA);
        ul.appendChild(settingsLi);
    }

    // Логика позиционирования и монтирования контейнера в DOM
    if (CURRENT_PAGE === 'overview') {
        const holder = document.getElementById('menu-holder');
        if (holder) {
            holder.appendChild(menuWrap);
        } else {
            targetContainer.parentNode.insertBefore(menuWrap, targetContainer);
        }
    } else {
        // На внешних страницах (Сооружения, Флот и т.д.) просто ставим перед основным блоком игры
        targetContainer.parentNode.insertBefore(menuWrap, targetContainer);
    }

    // Безопасная инициализация событий
    if (!menuWrap.dataset.xanMenuEventsAttached) {
        attachMenuEvents(menuWrap);
    }

    // Запускаем фоновую синхронизацию уровня Врат, если кэш отсутствует или устарел
    if (shouldSyncGate && moonId && jumpGateItem) {
        syncJumpGateLevel(moonId, jumpGateItem, ul, viewMode, planetParams);
    }
}

/**
 * Навешивает безопасные события на элементы меню
 * @param {HTMLElement} menuElement 
 */
function attachMenuEvents(menuElement) {
    menuElement.dataset.xanMenuEventsAttached = 'true';
    
    menuElement.addEventListener('click', (e) => {
        // Клик по кнопке настроек XAN перехватывается в overview_ui.js, тут обрабатываем только переходы
        const link = e.target.closest('a');
        if (!link || link.id === 'xan-lnk') return;
        
        const urlTarget = link.getAttribute('href');
        console.log(`[XAN Навигация] Переход: ${urlTarget}`);
    });
}
