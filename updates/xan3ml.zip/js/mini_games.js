// js/mini_games.js — Роутер мини-игр и общая UI-панель управления

import { _ } from './query.js';
import { getRandomInt } from './utils.js';
import { initMemoryGame } from './mg_memory.js';
import { initLinesGame } from './mg_lines.js';
import { initDeliveryGame } from './mg_delivery.js';

const AUTOSTART_STORAGE_KEY = 'xan3_minigames_autostart';
const RUN_ONCE_SESSION_KEY = 'xan3_minigames_run_once';

export function initMinigamesPage() {
    const form = _('form[name="gamestart"]');
    if (!form) return;

    const titleCell = form.querySelector('td.c');
    const titleText = (titleCell?.textContent || '').trim();

    if (titleText.includes('Память') || titleText.includes("Пам'ять") || titleText.includes('Memory')) {
        //initMemoryGame(form);
		return;
    } else if (titleText.includes('Линии') || titleText.includes('Лінії') || titleText.includes('Lines')) {
        initLinesGame(form);
    } else if (titleText.includes('Доставка') || titleText.includes('Delivery')) {
        initDeliveryGame(form);
    }
}


export function createMinigameControlBar(form, onStartCallback, onStopCallback) {
    const startSubmitBtn = form.querySelector('.start-game input[type="submit"]');
    const headerRow = form.querySelector('tr:first-child th');
    const isAutoStart = localStorage.getItem(AUTOSTART_STORAGE_KEY) === '1';

    if (headerRow) {
        headerRow.innerHTML = `
            <div id="xan-mg-panel" style="display:flex; align-items:center; justify-content:space-between; gap:8px; padding:4px 8px; background:rgba(20,25,35,0.85); border:1px solid #30363d; border-radius:4px; font-weight:normal;">
                <div style="display:flex; align-items:center; gap:8px;">
                    <button type="button" id="xan-mg-toggle-btn" style="cursor:pointer; padding:3px 10px; background:#238636; color:#fff; border:1px solid #2ea043; border-radius:3px; font-weight:bold;">
                        ▶ Решить
                    </button>
                    <label style="display:flex; align-items:center; gap:4px; cursor:pointer; color:#c9d1d9; font-size:11px; user-select:none;">
                        <input type="checkbox" id="xan-mg-autostart" ${isAutoStart ? 'checked' : ''} style="cursor:pointer; margin:0;">
                        Автостарт
                    </label>
                </div>
                <span id="xan-mg-status" style="color:#8b949e; font-size:11px;">${startSubmitBtn ? 'Нажмите «Решить» для старта' : 'Готов к запуску'}</span>
            </div>
        `;
    }

    const toggleBtn = _('#xan-mg-toggle-btn');
    const autoCheck = _('#xan-mg-autostart');
    const statusEl = _('#xan-mg-status');

    const setStatus = (text, color = '#8b949e') => {
        if (statusEl) {
            statusEl.textContent = text;
            statusEl.style.color = color;
        }
    };

    const setRunningUI = (running) => {
        if (!toggleBtn) return;
        if (running) {
            toggleBtn.textContent = '⏹ Стоп';
            toggleBtn.style.background = '#da3633';
            toggleBtn.style.borderColor = '#f85149';
        } else {
            toggleBtn.textContent = '▶ Решить';
            toggleBtn.style.background = '#238636';
            toggleBtn.style.borderColor = '#2ea043';
        }
    };

    if (autoCheck) {
        _(autoCheck).on('change', () => {
            localStorage.setItem(AUTOSTART_STORAGE_KEY, autoCheck.checked ? '1' : '0');
        });
    }

    const triggerStartOrSolve = () => {
        if (startSubmitBtn) {
            sessionStorage.setItem(RUN_ONCE_SESSION_KEY, '1');
            setStatus('Запуск игры...', '#58a6ff');
            startSubmitBtn.click();
            return;
        }
        onStartCallback();
    };

    if (toggleBtn) {
        _(toggleBtn).on('click', () => {
            if (toggleBtn.textContent.includes('Стоп')) {
                onStopCallback();
                setStatus('Остановка...', '#d29922');
            } else {
                triggerStartOrSolve();
            }
        });
    }

    const shouldRunOnce = sessionStorage.getItem(RUN_ONCE_SESSION_KEY) === '1';
    if (shouldRunOnce) {
        sessionStorage.removeItem(RUN_ONCE_SESSION_KEY);
    }

    if (isAutoStart || shouldRunOnce) {
        setTimeout(() => {
            if (!isMinigameOver()) {
                triggerStartOrSolve();
            }
        }, getRandomInt(250, 450));
    }

    return { setStatus, setRunningUI };
}

export function isMinigameOver() {
    const counterText = (_('#mg-counter')?.textContent || '').trim();
    return /Победа|Перемога|Проигрыш|Програш|Время вышло|Час вийшов/i.test(counterText);
}

export function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
