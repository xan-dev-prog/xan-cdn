// js/cargo.js — Изолированный модуль управления шаблонами грузов (Cargo Manager)
// ЧАСТЬ 1 ИЗ 3

import { _ } from './query.js';
import { spaces } from './utils.js';

export function initCargoModule() {
    console.log('Запущен модуль Грузы');
    
    // Жесткая защита от повторных проходов расширения при перезапусках
    if (document.querySelector('#cargos')) return;

    // Внутренний микро-хелпер поиска из твоего старого скрипта
    const findEl = (selector, all = false) => !all ? document.querySelector(selector) : document.querySelectorAll(selector);

    // Получаем сохранённые в LocalStorage грузы и парсим в массив
    const carg = localStorage.xan3_xgCargos ? localStorage.xan3_xgCargos.split(';').map(x => x.split('|')) : [];
    const savedCargosHtml = !carg.length
        ? t('c_no_cargos')
        : carg.map(x => {
            const currentTitle = t('c_title_res').replace('{m}', x[2]).replace('{c}', x[3]).replace('{u}', x[4]);
            return `
                <span class="data" data-met="${x[2]}" data-crys="${x[3]}" data-ur="${x[4]}" title="${currentTitle}">${x[1]}</span>
                <span class="singledel" data-id="${x[0]}" title="${t('c_title_del_single')}">✖</span><br />
            `;
          }).join('');

    // 1. Поиск ячейки "Погрузка" и инжекция строки грузов строго по твоему старому алгоритму
    const allTds = Array.from(_('td', true));
    const loadingTd = allTds.find(x => x.textContent.trim() === '[ Взять все ресурсы ]' || x.textContent.includes('Взять все ресурсы'));
    
    if (loadingTd) {
        loadingTd.closest('tr')?.insertAdjacentHTML('afterend', `
            <tr height="40" class="xan-cargo-control-row">
                <td style="border:none; white-space:nowrap; vertical-align: middle;">
                    <span id="delAllCargos" style="color:#ff0000;" title="${t('c_title_del_all')}">-</span>
                    <span style="color:orange; cursor:help;" title="${t('c_label')}">${t('c_label')}</span>
                    <span id="addCargo" style="color:#00ff00;" title="${t('c_title_add')}">+</span>
                </td>
                <td align="center" colspan="3" style="border:none; vertical-align: middle;">
                    <div id="cargos"><br />${savedCargosHtml}</div>
                </td>
            </tr>
        `);
    }
    // js/cargo.js — ЧАСТЬ 2 ИЗ 3

    // 2. Поиск ячейки "Выбор миссии" и инжекция формы создания нового груза под левую таблицу
    const missionTd = allTds.find(x => x.textContent.trim() === 'Выбор миссии' || x.textContent.includes('Выбор миссии'));
    if (missionTd) {
        missionTd.closest('table')?.insertAdjacentHTML('afterend', `
            <table width="100%" align="center" id="cargoForm" style="display:none; margin-top: 5px;">
                <tbody>
                    <tr><td class="pad" colspan="2" style="font-weight:bold; color:orange; text-align:center;">${t('c_form_title')}</td></tr>
                    <tr><td width="30%">${t('c_form_name')}</td><td><input type="text" id="crgname" maxlength="10" value="Груз_${carg.length + 1}" title="${t('c_form_max')}" style="text-align:center;" /></td></tr>
                    <tr><td><span class="pickres">${t('c_metal')}</span></td><td><input type="text" id="cargomet" value="0" style="text-align:center;" /></td></tr>
                    <tr><td><span class="pickres">${t('c_crystal')}</span></td><td><input type="text" id="cargocrys" value="0" style="text-align:center;" /></td></tr>
                    <tr><td><span class="pickres">${t('c_uran')}</span></td><td><input type="text" id="cargouran" value="0" style="text-align:center;" /></td></tr>
                    <tr><td class="pad" colspan="2" style="text-align:center;"><span id="createCargo" title="${t('c_form_save_title')}" style="cursor:pointer;">${t('c_form_save')}</span></td></tr>
                </tbody>
            </table>
        `);
    }

    // 3. Поиск ячейки "Взять все ресурсы" и инжекция стрелочек [▼] и [▲]
    const allFonts = Array.from(findEl('font', true));
    const takeAllFont = allFonts.find(x => x.textContent.trim() === 'Взять все ресурсы' || x.textContent.includes('Взять все ресурсы'));
    const takeAllTd = takeAllFont?.closest('td');

    if (takeAllTd) {
        takeAllTd.style.whiteSpace = 'nowrap';
        if (!document.querySelector('#unload')) {
            takeAllTd.insertAdjacentHTML('afterbegin', `<div id="unload" style="display:inline; margin-right:5px; cursor:pointer;" title="${t('c_title_unload')}">[<span style="color:lightsteelblue;">▼</span>]</div> `);
        }
        if (!document.querySelector('#reverseload')) {
            takeAllTd.insertAdjacentHTML('beforeend', `<div id="reverseload" style="display:inline; margin-left:5px; cursor:pointer;" title="${t('c_title_reverse')}">[<span style="color:orange;">▲</span>]</div>`);
        }
    }

    // Пробрасываем управление в блок интерактивных событий (Часть 3)
    bindCargoEvents(carg, findEl);
}
// js/cargo.js — ЧАСТЬ 3 ИЗ 3

function bindCargoEvents(carg, findEl) {
    
    // Внутренняя функция обновления полей создания груза
    function updSavedCargo() {
        const cargoMet = document.querySelector('#cargomet');
        const cargoCrys = document.querySelector('#cargocrys');
        const cargoUran = document.querySelector('#cargouran');
        
        const nativeM = document.querySelector('[name="resource1"]') || document.querySelector('[name^=resource1]');
        const nativeC = document.querySelector('[name="resource2"]') || document.querySelector('[name^=resource2]');
        const nativeU = document.querySelector('[name="resource3"]') || document.querySelector('[name^=resource3]');

        if (cargoMet && cargoCrys && cargoUran && nativeM && nativeC && nativeU) {
            cargoMet.value = nativeM.value.replace(/[^\d]+/g, '') || '0';
            cargoCrys.value = nativeC.value.replace(/[^\d]+/g, '') || '0';
            cargoUran.value = nativeU.value.replace(/[^\d]+/g, '') || '0';
        }
    }

    // 1. Массовое удаление: Клик по красному минусу "-"
    document.querySelector('#delAllCargos')?.addEventListener('click', () => {
        if (!carg.length) return;
        if (confirm(t('c_conf_del_all'))) {
            localStorage.removeItem('xan3_xgCargos');
            setTimeout(() => location.reload(), 500);
        }
    });

    // 2. Делегирование событий клика внутри контейнера списка грузов #cargos
    document.querySelector('#cargos')?.addEventListener('click', (e) => {
        const trg = e.target;
        
        // Клик по красному крестику "✖" для удаления одиночной погрузки
        if (trg.classList.contains('singledel')) {
            if (confirm(t('c_conf_del_single'))) {
                const trimmed = carg.filter(x => x[0] != trg.dataset.id);
                if (trimmed.length) {
                    localStorage.xan3_xgCargos = trimmed.map(x => x.join('|')).join(';');
                } else {
                    localStorage.removeItem('xan3_xgCargos');
                }
                setTimeout(() => location.reload(), 500);
            }
        }
        
        // Клик по названию груза для мгновенной погрузки ресурсов в трюмы флота
        if (trg.classList.contains('data')) {
            const nativeM = document.querySelector('[name="resource1"]') || document.querySelector('[name^=resource1]');
            const nativeC = document.querySelector('[name="resource2"]') || document.querySelector('[name^=resource2]');
            const nativeU = document.querySelector('[name="resource3"]') || document.querySelector('[name^=resource3]');

            if (nativeM && nativeC && nativeU) {
                nativeM.value = trg.dataset.met || 0;
                nativeC.value = trg.dataset.crys || 0;
                nativeU.value = trg.dataset.ur || 0;
                
                [nativeM, nativeC, nativeU].forEach(inp => inp.dispatchEvent(new Event('change', { bubbles: true })));
                updSavedCargo();
            }
        }
    });

    // 3. Делегирование кликов по таблице трюмов
    const allTds = Array.from(findEl('td', true));
    const cargoTable = allTds.find(x => x.textContent.includes('Занятость трюмов'))?.closest('table');
    
    cargoTable?.addEventListener('click', (e) => {
        const trg = e.target;
        
        if (trg.tagName === 'A' || trg.tagName === 'FONT') { 
            setTimeout(updSavedCargo, 50); 
        }
        
        // Реверсивная умная загрузка по клику на стрелочку [▲]
        if (trg.closest('#reverseload')) {
            const links = Array.from(cargoTable.querySelectorAll('a'));
            links.reverse().forEach(link => {
                if (link.getAttribute('onclick')?.includes('maxResource')) {
                    link.click();
                }
            });
            setTimeout(updSavedCargo, 50);
        }
        
        // Полная мгновенная выгрузка трюмов в 0 по клику на стрелочку [▼]
        if (trg.closest('#unload')) {
            const nativeM = document.querySelector('[name="resource1"]') || document.querySelector('[name^=resource1]');
            const nativeC = document.querySelector('[name="resource2"]') || document.querySelector('[name^=resource2]');
            const nativeU = document.querySelector('[name="resource3"]') || document.querySelector('[name^=resource3]');

            if (nativeM && nativeC && nativeU) {
                nativeM.value = 0;
                nativeC.value = 0;
                nativeU.value = 0;
                [nativeM, nativeC, nativeU].forEach(inp => inp.dispatchEvent(new Event('change', { bubbles: true })));
            }
            updSavedCargo();
        }
    });

    // Отслеживание ручного изменения полей игроком (потеря фокуса инпута)
    document.querySelectorAll('[name^=resource]').forEach(el => {
        el.addEventListener('blur', updSavedCargo);
    });

    // Клик по зелёному плюсику "+" для открытия/закрытия формы
    document.querySelector('#addCargo')?.addEventListener('click', () => {
        const attentionTh = Array.from(document.querySelectorAll('font')).find(x => x.textContent.includes('Внимание!'))?.closest('th');
        if (attentionTh) attentionTh.remove();

        const form = document.querySelector('#cargoForm');
        if (form) {
            form.style.display = form.style.display === 'table' ? 'none' : 'table';
            updSavedCargo();
        }
    });

    // Перенос значений из трюма игры в инпуты формы при клике на текстовые спаны
    document.querySelector('#cargoForm')?.addEventListener('click', (e) => {
        const trg = e.target;
        
        if (trg.classList.contains('pickres')) {
            const inp = trg.closest('tr').querySelector('input');
            const formInputs = Array.from(document.querySelectorAll('#cargoForm [id^=cargo]'));
            const resIndex = formInputs.indexOf(inp) + 1;
            
            const nativeInput = document.querySelector(`[name=resource${resIndex}]`) || document.querySelector(`[name^=resource${resIndex}]`);
            if (inp && nativeInput) {
                inp.value = nativeInput.value.replace(/[^\d]+/g, '') || '0';
            }
        }
    });

    // Финальное сохранение заполненного шаблона груза в LocalStorage
    document.querySelector('#createCargo')?.addEventListener('click', () => {
        const crgName = document.querySelector('#crgname');
        const cMet = document.querySelector('#cargomet');
        const cCrys = document.querySelector('#cargocrys');
        const cUran = document.querySelector('#cargouran');

        if (!crgName || !cMet || !cCrys || !cUran) return;

        const totalSum = Number(cMet.value) + Number(cCrys.value) + Number(cUran.value);
        if (!totalSum || isNaN(totalSum) || !crgName.value.trim()) {
            alert(t('c_err_empty'));
            return;
        }

        const date = new Date();
        const now = date.getTime();
        carg.push([
            now,
            crgName.value.trim(),
            cMet.value,
            cCrys.value,
            cUran.value
        ]);
        
        localStorage.xan3_xgCargos = carg.map(x => x.join('|')).join(';');
        setTimeout(() => location.reload(), 500);
    });
}
