// Стабильный и легкий хелпер _Query для XAN (Расширенная версия с безопасной HTML-вставкой)
export function _(selector, all = false) {
    if (!selector) return null;
    
    // 1. Находим элементы в DOM (строка или готовый объект)
    let result;
    if (typeof selector === 'string') {
        result = !all ? document.querySelector(selector) : document.querySelectorAll(selector);
    } else {
        result = selector;
        if (!all && (result instanceof NodeList || Array.isArray(result))) {
            all = true;
        }
    }

    if (!result || (all && result.length === 0)) return result;

    // Если методы уже прикреплены к этому объекту — сразу возвращаем без лишней работы
    if (result._xanExtended) return result;

    // 2. Вспомогательный хелпер для чейнинга
    const _run = (cb) => {
        if (all) result.forEach(cb); else cb(result);
        return result;
    };

    // Вспомогательная функция для вставки HTML-строки или DOM-элемента
    const _insert = (el, position, content) => {
        if (typeof content === 'string') {
            el.insertAdjacentHTML(position, content);
        } else if (content instanceof Element) {
            el.insertAdjacentElement(position, content);
        }
    };

    // 3. Кастомные методы
    const methods = {
        /* === КЛАССЫ === */
        addCls: (cls) => _run(el => el.classList.add(cls)),
        removeCls: (cls) => _run(el => el.classList.remove(cls)),
        replaceCls: (oldC, newC) => _run(el => el.classList.replace(oldC, newC)),
        toggleCls: (cls, f) => _run(el => el.classList.toggle(cls, f)),
        closestAddCls: (sel, cls) => _run(el => el.closest(sel)?.classList.add(cls)),

        /* === АТРИБУТЫ, ДАТА-АТРИБУТЫ И КОНТЕНТ === */
        attr: (name, val) => _run(el => el.setAttribute(name, val)),
        rmAttr: (name) => _run(el => el.removeAttribute(name)),
        text: (txt) => _run(el => el.innerText = txt),
        html: (str) => _run(el => el.innerHTML = str),

        /* === ВСТАВКА И УДАЛЕНИЕ HTML / ЭЛЕМЕНТОВ === */
        append: (content) => _run(el => _insert(el, 'beforeend', content)),
        prepend: (content) => _run(el => _insert(el, 'afterbegin', content)),
        after: (content) => _run(el => _insert(el, 'afterend', content)),
        before: (content) => _run(el => _insert(el, 'beforebegin', content)),
        remove: () => _run(el => Element.prototype.remove.call(el)),
        
        data(key, val) {
            if (val !== undefined) return _run(el => el.dataset[key] = val);
            return all ? Array.from(result).map(el => el.dataset[key]) : result.dataset[key];
        },

        /* === СТИЛИ И ВИДИМОСТЬ === */
        hide: () => _run(el => el.style.display = 'none'),
        show: (type = 'block') => _run(el => el.style.display = type),
        css: (obj) => _run(el => Object.keys(obj).forEach(k => el.style[k] = obj[k])),

        /* === СОБЫТИЯ === */
        on: (ev, cb, opt) => _run(el => el.addEventListener(ev, cb, opt)),

        /* === НАШ УНИВЕРСАЛЬНЫЙ НАВИГАТОР ПО ТЕКСТУ === */
        fndDpst(textQuery) {
            const checkElement = (el) => {
                if (!el) return false;
                const txt = el.textContent || '';
                const hasText = txt.trim() === textQuery || txt.includes(textQuery);
                const isDeepest = !Array.from(el.children).some(child => 
                    (child.textContent || '').includes(textQuery)
                );
                return hasText && isDeepest;
            };

            if (all) {
                const found = [];
                result.forEach(parent => {
                    if (checkElement(parent)) found.push(parent);
                    const descendants = Array.from(parent.querySelectorAll('*')).filter(checkElement);
                    found.push(...descendants);
                });
                return Array.from(new Set(found));
            } else {
                if (checkElement(result)) return result;
                return Array.from(result.querySelectorAll('*')).find(checkElement) || null;
            }
        }
    };

    // Внедряем методы скрыто
    Object.keys(methods).forEach(key => {
        Object.defineProperty(result, key, {
            value: methods[key],
            enumerable: false,
            configurable: true,
            writable: true
        });
    });

    Object.defineProperty(result, '_xanExtended', {
        value: true,
        enumerable: false,
        configurable: true
    });

    return result;
}
