// js/phalanx.js — ЧАСТЬ 1 ИЗ 4
import { nsn } from './utils.js';

let fetchTimerId = null; 

export function initPhalanxPage() {
    const tables = document.querySelectorAll('table[width="570"]');
    if (!tables || tables.length < 2) return;
    const secTab = tables.item(1); 

    const hideDangerAlert = localStorage.getItem('xan3_phalanxHideDangerAlert') === '1';

    const redFont = document.querySelector('font[color="red"]');
    if (redFont && !hideDangerAlert) {
        const redText = redFont.textContent || '';
        const targetRow = redFont.closest('tr');
        const limeFonts = document.querySelectorAll('font[color="lime"]');
        const isAlienFleet = redText.includes('Чужой') || redText.includes('Чужий') || redText.includes('Alien');

        if (targetRow && isAlienFleet && targetRow === secTab.rows.item(1) && limeFonts && limeFonts.length > 1) {
            const cells = targetRow.querySelectorAll('td, th');
            cells.forEach(c => c.classList.add('xan-phalanx-danger-row'));
            secTab.classList.add('xan-phalanx-danger-border');
            
            const redTh = redFont.closest('th');
            if (redTh) {
                redTh.insertAdjacentHTML('beforeend', `<h2 class="xan-phalanx-warning-title">${t('p_danger_msg')}</h2>`);
            }
        }
    }

    const scanTimeRow = document.querySelector('[title="Время сканирования"]') || document.querySelector('[title*="сканирован"]') || document.querySelector('[title*="скануван"]');
    if (scanTimeRow) {
        const scanTimeTr = scanTimeRow.closest('tr');
        if (scanTimeTr && scanTimeTr.cells && scanTimeTr.cells.length >= 3) {
            
            if (!scanTimeTr.cells.item(0).querySelector('#xan_toggle_danger')) {
                scanTimeTr.cells.item(0).insertAdjacentHTML('afterbegin', `
                    <input type="checkbox" id="xan_toggle_danger" title="${t('p_danger_toggle_title')}" ${hideDangerAlert ? 'checked' : ''} class="xan-phalanx-checkbox-danger" />
                `);
                document.getElementById('xan_toggle_danger')?.addEventListener('change', function() {
                    localStorage.setItem('xan3_phalanxHideDangerAlert', this.checked ? '1' : '0');
                    window.location.reload();
                });
            }

            if (!scanTimeTr.cells.item(2).querySelector('#xan_easy_add')) {
                scanTimeTr.cells.item(2).insertAdjacentHTML('beforeend', `<button id="xan_easy_add" title="${t('p_easy_add_title')}" class="xan-phalanx-easy-add-btn"> ✔ </button>`);
                document.getElementById('xan_easy_add')?.addEventListener('click', function() {
                    const txt = this.closest('td')?.textContent || '';
                    const match = txt.match(/\[(\d+):(\d+):(\d+)\]/);
                    if (match) {
                        //addNewCoordinates(match.at(1), match.at(2), match.at(3), txt.includes('*') ? '*' : '');
						addNewCoordinates(match.at(1), match.at(2), match.at(3), '*');
                    }
                });
            }
        }
    }

    if (secTab.textContent.includes(t('p_game_no_fleets')) || secTab.textContent.includes('Флоти не помічені')) return;
// js/phalanx.js — ЧАСТЬ 2 ИЗ 4
    let theAlien = localStorage.getItem('xan3_watchedAlien') ? localStorage.getItem('xan3_watchedAlien').split('|') : [];

    const scanInterval = parseInt(localStorage.getItem('xan3_phalanxInterval') || '1', 10);
    const stopMinutesBuffer = parseInt(localStorage.getItem('xan3_phalanxStopBuffer') || '0', 10);
    const startTimeTarget = localStorage.getItem('xan3_phalanxStartTime') || '';
    //const scanMethod = 'reload'; 
	const scanMethod = localStorage.getItem('xan3_phalanxMethod') || 'fetch';
    const doWatch = localStorage.getItem('xan3_doWatch') === '1';

    // js/phalanx.js — Начало Части 2 из 4 (Полностью чистый рабочий блок)
    let uranInfoHtml = `<div id="xan_uran_calc_container" class="xan-phalanx-uran-calc-div"></div>`;
    const allTds = Array.from(document.querySelectorAll('td'));
    const uranTd = allTds.find(x => x.title === 'Урана в наличии' || x.title === 'Урану в наявності');
    const priceTd = allTds.find(x => x.title?.includes('Стоимость =') || x.title?.includes('Вартість ='));
	
    if (uranTd) uranTd.closest('tbody').insertAdjacentHTML('beforeend', `<tr><th colspan="3">${uranInfoHtml}</th></tr>`);


    const centerElem = document.querySelector('center');
    if (centerElem && !document.getElementById('xan_phalanx_panel')) {
        const spansHtml = theAlien.length ? theAlien.map((x, i) => `<span class="xan-cory" data-ind="${i}">${x}</span>`).join(', ') : t('p_no_coords');
        
        const isWaitingAlarm = doWatch && startTimeTarget !== '';
        const isCurrentlyRecording = doWatch && !isWaitingAlarm;

        let startCellContent = `<input type="button" id="xan_rec_start" value="${t('p_btn_start')}" class="xan-btn-start">`;
        if (isWaitingAlarm) {
            startCellContent = `<input type="button" id="xan_rec_start" value="Жду... ⏰" class="xan-btn-start xan-phalanx-btn-alarm-waiting">`;
        } else if (isCurrentlyRecording) {
            startCellContent = `
                <div class="xan-rec-indicator">
                    🔴 REC (${scanMethod.toUpperCase()})
                </div>
            `;
        }

        // js/phalanx.js — Находим место генерации таблицы во 2-й части
                centerElem.insertAdjacentHTML('beforeend', `
            <table width="570" id="xan_phalanx_panel" class="xan-phalanx-table">
                <tbody>
                    <tr>
                        <th colspan="3" class="xan-phalanx-header">
                            ${window.t('p_panel_header')} 
                            <div id="xanPhalanxHelpBtn" class="xan-phalanx-help-trigger" title="${window.t('p_help_title')}">[?]</div>
                        </th>
                    </tr>
                    <tr id="xan-phalanx-help-row" style="display: none;">
                        <td colspan="3" class="b xan-phalanx-help-box">
                            <h3>${window.t('p_help_guide_hdr')}</h3>
                            
                            <p class="xan-phalanx-help-cat-base">🎯 ${window.t('p_help_cat_base')}:</p>
                            <ul>
                                <li><b>${window.t('p_help_base1_title')}:</b> ${window.t('p_help_base1_desc')}</li>
                                <li><b>${window.t('p_help_base2_title')}:</b> ${window.t('p_help_base2_desc')}</li>
                            </ul>

                            <p class="xan-phalanx-help-cat-modes">⏱️ ${window.t('p_help_cat_modes')}:</p>
                            <ul>
                                <li><b>${window.t('p_help_mode1_title')}:</b> ${window.t('p_help_mode1_desc')}</li>
                                <li><b>${window.t('p_help_mode2_title')}:</b> ${window.t('p_help_mode2_desc')}</li>
                            </ul>

                            <p class="xan-phalanx-help-cat-safety">🛡️ ${window.t('p_help_cat_safety')}:</p>
                            <ul>
                                <li><b>${window.t('p_help_safe1_title')}:</b> ${window.t('p_help_safe1_desc')}</li>
                                <li><b>${window.t('p_help_safe2_title')}:</b> ${window.t('p_help_safe2_desc')}</li>
                                <li><b>${window.t('p_help_safe3_title')}:</b> ${window.t('p_help_safe3_desc')}</li>
                            </ul>
                        </td>
                    </tr>
                    <tr><th colspan="3" id="xan_al" class="xan-phalanx-coords-list">${spansHtml}</th></tr>
                    <tr>
                        <th>-</th>
                        <th class="coords_cell">
                            <button id="xan_addnew" class="xan-btn">${window.t('p_btn_add')}</button> 
                            <b>[</b><input type="text" id="xanAlienGal" size="1">:<input type="text" id="xanAlienSys" size="3">:<input type="text" id="xanAlienPlan" size="2"><b>]</b>
                            <select id="xanPlanType"><option value="">${window.t('p_opt_planet')}</option><option value="*">${window.t('p_opt_moon')}</option></select>
                        </th>
                        <th>-</th>
                    </tr>
                    <tr>
                        <th colspan="3" class="xan-phalanx-panel-row-controls">
                            Старт: <input type="time" id="xan_p_start_time" value="${startTimeTarget}" step="1" class="xan-phalanx-input-time">
                            &nbsp;|&nbsp; Буфер: <input type="number" id="xan_p_buffer" value="${stopMinutesBuffer}" min="0" max="60" class="xan-phalanx-input-buffer"> ${window.t('p_unit_min')}
                            &nbsp;|&nbsp; Тик: <select id="xan_p_interval" class="xan-phalanx-select-interval"><option value="1" ${scanInterval===1?'selected':''}>1с</option><option value="2" ${scanInterval===2?'selected':''}>2с</option><option value="3" ${scanInterval===3?'selected':''}>3с</option></select>
							&nbsp;|&nbsp; ${window.t('p_label_method')} <select id="xan_p_method" class="xan-phalanx-select-interval"><option value="fetch" ${scanMethod==='fetch'?'selected':''}>Fetch</option><option value="reload" ${scanMethod==='reload'?'selected':''}>Reload</option></select>
                            &nbsp;|&nbsp; <input type="button" id="xan_rec_reset" value="Сброс" class="xan-btn xan-phalanx-btn-reset">
                        </th>
                    </tr>
                    <tr>
                        <th id="xan_start_cell_bridge">${startCellContent}</th>
                        <th><div id="xan_return_time"></div></th>
                        <th>
                            <input type="button" id="xan_rec_stop" value="${window.t('p_btn_stop')}" class="xan-btn-stop xan-phalanx-btn-stop-panel">
                        </th>
                    </tr>
                </tbody>
            </table>
        `);


        // Логика переключения видимости инструкции по клику на [ ? ]
        document.getElementById('xanPhalanxHelpBtn')?.addEventListener('click', (e) => {
            e.preventDefault();
            const helpRow = document.getElementById('xan-phalanx-help-row');
            if (helpRow) {
                helpRow.style.display = helpRow.style.display === 'none' ? '' : 'none';
            }
        });

        // js/phalanx.js — Конец Части 2 из 4
        document.getElementById('xan_p_start_time')?.addEventListener('change', function() { localStorage.setItem('xan3_phalanxStartTime', this.value); });
        document.getElementById('xan_p_buffer')?.addEventListener('change', function() { localStorage.setItem('xan3_phalanxStopBuffer', this.value); });
        
        // Функция динамического пересчета урана строго по Vanilla JS API
        /*
        const updateUraniumCalculation = () => {
            const container = document.getElementById('xan_uran_calc_container');
            if (!container || !uranTd || !priceTd) return;

            const uText = uranTd.querySelector('font[color="orange"]') ? uranTd.querySelector('font[color="orange"]').textContent : uranTd.textContent;
            const pText = priceTd.querySelector('span') ? priceTd.querySelector('span').textContent : priceTd.textContent;
            
            const totalScansPossible = Math.floor(nsn(uText) / nsn(pText));
            if (totalScansPossible > 0) {
                const currentTick = parseInt(document.getElementById('xan_p_interval')?.value || scanInterval, 10);
                const totalSeconds = totalScansPossible * currentTick;
                
                // Высчитываем дни и остаток времени
                const days = Math.floor(totalSeconds / 86400);
                const remainAfterDays = totalSeconds % 86400;
                
                const hrs = Math.floor(remainAfterDays / 3600);
                const mins = Math.floor((remainAfterDays % 3600) / 60);
                const secs = remainAfterDays % 60;

                // Форматируем остаток времени в ЧЧ:ММ:СС
                const timeString = 
                    String(hrs).padStart(2, '0') + ':' + 
                    String(mins).padStart(2, '0') + ':' + 
                    String(secs).padStart(2, '0');
                
                let finalDuration = '';
                if (days > 0) {
                    // Определяем текущий язык расширения из localStorage (по умолчанию ru)
                    const currentLang = localStorage.getItem('xan3_app_lang') || 'ru';
                    let dayWord = '';

                    if (currentLang === 'uk') {
                        // Склонение для украинского языка (день / дні / днів)
                        if (days % 10 === 1 && days % 100 !== 11) dayWord = 'день';
                        else if ((days % 10 === 2 || days % 10 === 3 || days % 10 === 4) && (days % 100 < 10 || days % 100 >= 20)) dayWord = 'дні';
                        else dayWord = 'днів';
                    } else {
                        // Склонение для русского языка (день / дня / дней)
                        if (days % 10 === 1 && days % 100 !== 11) dayWord = 'день';
                        else if ((days % 10 === 2 || days % 10 === 3 || days % 10 === 4) && (days % 100 < 10 || days % 100 >= 20)) dayWord = 'дня';
                        else dayWord = 'дней';
                    }
                    
                    finalDuration = `${days} ${dayWord} ${timeString}`;
                } else {
                    finalDuration = timeString;
                }
                
                // Подставляем отформатированную строку в интерфейс
                container.innerHTML = t('p_uran_calc').replace('~ {min} мин.', finalDuration);
            }
        };*/



        // Запускаем расчет один раз сразу при загрузке страницы
        updateUraniumCalculation();

        // Обновленный обработчик: считает на лету и сохраняет тик, страница больше не моргает!
        document.getElementById('xan_p_interval')?.addEventListener('change', function() { 
            localStorage.setItem('xan3_phalanxInterval', this.value); 
            updateUraniumCalculation(); 
        });
		
		document.getElementById('xan_p_method')?.addEventListener('change', function() {
			localStorage.setItem('xan3_phalanxMethod', this.value);
		});

// --------------------------------------------------------------------------


    }
// js/phalanx.js — ЧАСТЬ 3 ИЗ 4
    document.getElementById('xan_addnew')?.addEventListener('click', function() {
        const gal = document.getElementById('xanAlienGal')?.value;
        const sys = document.getElementById('xanAlienSys')?.value;
        const plan = document.getElementById('xanAlienPlan')?.value;
        const type = document.getElementById('xanPlanType')?.value;
        if (gal && sys && plan) addNewCoordinates(gal, sys, plan, type);
    });

    document.getElementById('xan_al')?.addEventListener('click', function(e) {
        if (e.target.tagName !== 'SPAN') return;
        const idx = parseInt(e.target.dataset.ind, 10);
        if (!isNaN(idx)) {
            theAlien.splice(idx, 1);
            if (theAlien.length) localStorage.setItem('xan3_watchedAlien', theAlien.join('|'));
            else localStorage.removeItem('xan3_watchedAlien');
            window.location.reload();
        }
    });

    const targetThs = document.querySelectorAll('th[width="430"]');
    const savedTargetHash = localStorage.getItem('xan3_phalanxTargetHash') ?? '';
    let overlibFleetCounter = {};

    if (targetThs) {
        targetThs.forEach(function(x) {
            const fleetLink = Array.from(x.querySelectorAll('a')).find(a => a.textContent.trim() === 'флот' || a.textContent.trim() === 'fleet');
            const firstOne = x.querySelector('a[href^="./galaxy.php?"]');
            if (!fleetLink || !firstOne) return;

            const coordMatch = firstOne.textContent.match(/(\d+):(\d+):(\d+)/);
            if (!coordMatch) return;
            const cleanCoords = coordMatch.at(1) + ':' + coordMatch.at(2) + ':' + coordMatch.at(3);
            const formattedTarget = '[' + cleanCoords + ']' + (x.textContent.includes('(Луна)') || x.textContent.includes('(Місяць)') || x.innerHTML.includes('*') ? '*' : '');

            if (theAlien.includes(formattedTarget) && (x.textContent.includes('Оставить') || x.textContent.includes('Залишити'))) {
                const baseHash = btoa(encodeURIComponent(fleetLink.getAttribute('onmouseover') || '')).substring(0, 25);
                overlibFleetCounter[baseHash] = (overlibFleetCounter[baseHash] === undefined) ? 0 : overlibFleetCounter[baseHash] + 1;
                const currentFleetHash = baseHash + '_f' + overlibFleetCounter[baseHash];

                const isTargetSelected = savedTargetHash === currentFleetHash;
                const picColor = isTargetSelected ? 'green' : 'red';
                const statusAttr = isTargetSelected ? 'seen' : 'notseen';
                const galkaTitle = isTargetSelected ? t('p_target_unselect_title') : t('p_target_select_title');

                if (!x.querySelector('.xan-target-galka')) {
                    x.insertAdjacentHTML('afterbegin', `
                        <div class="xan-phalanx-galka-wrapper">
                            <img class="xan-target-galka" 
                                 data-status="${statusAttr}" 
                                 data-fleet-hash="${currentFleetHash}" 
                                 src="${chrome.runtime.getURL('images/tick-' + picColor + '.png')}" 
                                 title="${galkaTitle}"
                                 alt="" />
                        </div>
                    `);
                }

                if ((savedTargetHash === '') ? (document.querySelectorAll('#xanBotFound').length === 0) : (savedTargetHash === currentFleetHash)) {
                    firstOne.classList.add('xan-phalanx-target-hl'); firstOne.id = 'xanBotFound';
                    firstOne.dataset.matchedFormat = formattedTarget; firstOne.dataset.fleetHash = currentFleetHash;
                    
                    // Стало:
					const alElem = document.getElementById('xan_al');
					if (alElem) alElem.classList.add('xan-phalanx-found-match');

					document.querySelectorAll('.xan-cory').forEach(s => { 
					// Строгое сравнение текстового содержимого элемента с полным отформатированным целевым шаблоном
					if (s.textContent.trim() === formattedTarget.trim()) s.classList.add('xan-cory-active'); 
					});

                } else { firstOne.style.color = '#bbbb00'; }
            }
        });

        document.querySelectorAll('.xan-target-galka').forEach(g => {
            g.addEventListener('click', function() { 
                const currentStatus = this.getAttribute('data-status');
                if (currentStatus === 'notseen') {
                    localStorage.setItem('xan3_phalanxTargetHash', this.dataset.fleetHash); 
                } else {
                    localStorage.removeItem('xan3_phalanxTargetHash');
                }
                window.location.reload(); 
            });
        });
    }

    const returnTimeDiv = document.getElementById('xan_return_time');
    if (returnTimeDiv) {
        returnTimeDiv.innerHTML = `<b class="xan-clickable-time">${localStorage.getItem('xan3_returnTime') ?? t('p_default_rtime')}</b>`;
        returnTimeDiv.addEventListener('click', (e) => { 
            if (e.target.tagName === 'B') { 
                localStorage.removeItem('xan3_returnTime'); 
                localStorage.removeItem('xan3_phalanxTargetHash'); 
                window.location.reload(); 
            } 
        });
    }

    document.getElementById('xan_rec_start')?.addEventListener('click', function() { 
        if (theAlien.length > 1 && (localStorage.getItem('xan3_phalanxTargetHash') ?? '') === '') {
            alert("⚠️ Ошибка запуска автоматизации!\n\nУ вас в списке отслеживания находится " + theAlien.length + " коорд. Для точной записи отзыва оставьте только ОДНУ цель, кликнув по лишним координатам в списке для их удаления, либо зафиксируйте конкретный флот зеленой галкой.");
            return;
        }
        localStorage.removeItem('xan3_returnTime'); 
        localStorage.setItem('xan3_doWatch', '1'); 
        window.location.reload(); 
    });
    
    document.getElementById('xan_rec_stop')?.addEventListener('click', function() { 
        localStorage.removeItem('xan3_doWatch'); 
        localStorage.removeItem('xan3_phalanxTargetHash'); 
        if (fetchTimerId) clearTimeout(fetchTimerId); 
        window.location.reload(); 
    });
    
    document.getElementById('xan_rec_reset')?.addEventListener('click', function() {
        localStorage.removeItem('xan3_phalanxStartTime'); 
        localStorage.removeItem('xan3_phalanxStopBuffer');
        localStorage.removeItem('xan3_doWatch'); 
        localStorage.removeItem('xan3_phalanxTargetHash');
        localStorage.removeItem('xan3_returnTime'); 
        window.location.reload();
    });

    watcherScheduler(theAlien.length ? theAlien : null);
}

function addNewCoordinates(gal, sys, plan, type) {
    let arr = localStorage.getItem('xan3_watchedAlien') ? localStorage.getItem('xan3_watchedAlien').split('|') : [];
    const fmt = `[${gal}:${sys}:${plan}]${type}`;
    if (!arr.includes(fmt)) { arr.push(fmt); localStorage.setItem('xan3_watchedAlien', arr.join('|')); }
    window.location.reload();
}
// js/phalanx.js — ЧАСТЬ 4 ИЗ 4
function watcherScheduler(targetAlienStr) {
    if (fetchTimerId) {
        clearInterval(fetchTimerId);
        clearTimeout(fetchTimerId);
        fetchTimerId = null;
    }
    if (localStorage.getItem('xan3_doWatch') !== '1' || !targetAlienStr) return;

    const start = localStorage.getItem('xan3_phalanxStartTime') || '';
    const interval = parseInt(localStorage.getItem('xan3_phalanxInterval') || '1', 10) * 1000;

    if (start) {
        const parts = start.split(':');
        if (parts.length >= 2) {
            const targetHours = parseInt(parts.at(0), 10);
            const targetMinutes = parseInt(parts.at(1), 10);
            const targetSeconds = parts.at(2) ? parseInt(parts.at(2), 10) : 0;

            fetchTimerId = setInterval(() => {
                const now = new Date();
                const tDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), targetHours, targetMinutes, targetSeconds);
                
                if (tDate.getTime() + 60000 < now.getTime()) {
                    tDate.setDate(tDate.getDate() + 1);
                }
                
                const diff = tDate.getTime() - now.getTime();
                let remainingSec = Math.round(diff / 1000);

                if (remainingSec > 0) {
                    const retTimeDiv = document.getElementById('xan_return_time');
                    if (retTimeDiv) {
                        const hrs = Math.floor(remainingSec / 3600);
                        const mins = Math.floor((remainingSec % 3600) / 60);
                        const secs = remainingSec % 60;

                        const displayTime = 
                            String(hrs).padStart(2, '0') + ':' + 
                            String(mins).padStart(2, '0') + ':' + 
                            String(secs).padStart(2, '0');

                        retTimeDiv.innerHTML = `
                            <span class="xan-phalanx-span-scheduled">
                                ⏰ Скан запланирован на ${start} (осталось ${displayTime})
                            </span>`;
                    }
                } else {
                    clearInterval(fetchTimerId);
                    fetchTimerId = null;
                    localStorage.removeItem('xan3_phalanxStartTime');
                    
                    sessionStorage.setItem('xan3_p_last_reload_trigger', Date.now().toString());
                    
                    window.location.reload();
                    return;
                }
            }, 1000);
            return;
        }
    }
    
    executePhalanxReloadLoop(targetAlienStr, interval);
}

function executePhalanxReloadLoop(targetAlienStr, scanInterval) {
    const scanMethod = localStorage.getItem('xan3_phalanxMethod') || 'fetch';
    const savedTargetHash = localStorage.getItem('xan3_phalanxTargetHash') ?? '';
    const buffer = parseInt(localStorage.getItem('xan3_phalanxStopBuffer') || '0', 10);
    const cleanWatchedArray = (typeof targetAlienStr === 'string' ? targetAlienStr.split('|') : Array.from(targetAlienStr || [])).map(s => s.trim());

    // Вспомогательный парсер документа (работает и для текущего document, и для ответа fetch)
    const analyzeDocument = (doc) => {
        const scanTimeElem = doc.querySelector('td[title="Время сканирования"]') || doc.querySelector('td[title*="сканирован"]') || doc.querySelector('td[title*="скануван"]');
        const uranElem = Array.from(doc.querySelectorAll('td')).find(x => x.title === 'Урана в наличии' || x.title === 'Урану в наявності');
        const rows = Array.from(doc.querySelectorAll('th[width="430"]')).filter(x => Array.from(x.querySelectorAll('a')).some(a => a.textContent.trim() === 'флот' || a.textContent.trim() === 'fleet'));

        // Вытаскиваем реальные секунды из <script>last[1] = 11553; ... </script>
        const lastSecondsMap = {};
        doc.querySelectorAll('script').forEach(sc => {
            const matches = sc.textContent.matchAll(/last\[(\d+)\]\s*=\s*(\d+)/g);
            for (const m of matches) {
                lastSecondsMap[m.at(1)] = parseInt(m.at(2), 10);
            }
        });

        let overlibFleetCounter = {};
        let allHashes = [];
        let matched = null;
        let remSec = Infinity;

        rows.forEach((x, idx) => {
            const fLink = Array.from(x.querySelectorAll('a')).find(a => a.textContent.trim() === 'флот' || a.textContent.trim() === 'fleet');
            const fOne = x.querySelector('a[href^="./galaxy.php?"]');
            if (!fLink || !fOne) return;
            const m = fOne.textContent.match(/(\d+):(\d+):(\d+)/);
            if (!m) return;

            const isMoon = x.textContent.includes('(Луна)') || x.textContent.includes('(Місяць)') || x.innerHTML.includes('*');
            const fmt = '[' + m.at(1) + ':' + m.at(2) + ':' + m.at(3) + ']' + (isMoon ? '*' : '');
            const hash = btoa(encodeURIComponent(fLink.getAttribute('onmouseover') || '')).substring(0, 25);
            overlibFleetCounter[hash] = (overlibFleetCounter[hash] === undefined) ? 0 : overlibFleetCounter[hash] + 1;
            const curHash = hash + '_f' + overlibFleetCounter[hash];
            allHashes.push(curHash);

            const isTargetInWatched = cleanWatchedArray.some(addr => addr === fmt.trim());

            if ((savedTargetHash === '' && isTargetInWatched && !matched) || (savedTargetHash !== '' && savedTargetHash === curHash)) {
                if (savedTargetHash === '') matched = fmt;

                const parentTr = x.closest('tr');
                const timerDiv = parentTr ? parentTr.querySelector('div[id^="div"]') : null;
                if (timerDiv) {
                    const divNum = timerDiv.id.replace('div', '');
                    if (lastSecondsMap[divNum] !== undefined) {
                        remSec = lastSecondsMap[divNum];
                    } else if (timerDiv.textContent.trim() !== '-') {
                        remSec = parseTimeToSeconds(timerDiv.textContent);
                    }
                }
            }
        });

        let exists = (savedTargetHash === '') ? (matched !== null) : allHashes.includes(savedTargetHash);
        let isBufferStop = false;
        let isLandingStop = false;

        if (exists) {
            if (buffer > 0 && (remSec / 60) < buffer) {
                exists = false;
                isBufferStop = true;
            } else if (remSec <= 0) {
                exists = false;
                isLandingStop = true;
            }
        }

        return { exists, isBufferStop, isLandingStop, scanTimeElem, uranElem, lastSecondsMap };
    };

    // Обновление живого интерфейса при работе в режиме fetch
    const updateLiveUI = (parsed) => {
        // 1. Обновляем верхнее время сканирования
        const liveScanTd = document.querySelector('td[title="Время сканирования"]') || document.querySelector('td[title*="сканирован"]') || document.querySelector('td[title*="скануван"]');
        if (liveScanTd && parsed.scanTimeElem) {
            liveScanTd.textContent = parsed.scanTimeElem.textContent.trim();
        }

                // 2. Обновляем остаток урана и пересчитываем время
        const liveUranTd = Array.from(document.querySelectorAll('td')).find(x => x.title === 'Урана в наличии' || x.title === 'Урану в наявності');
        if (liveUranTd && parsed.uranElem) {
            liveUranTd.innerHTML = parsed.uranElem.innerHTML;
            updateUraniumCalculation();
        }


        // 3. Синхронизируем таймер полета флота в реальном времени
        Object.entries(parsed.lastSecondsMap).forEach(([id, sec]) => {
            if (window.last && typeof window.last === 'object') {
                window.last[id] = sec;
            }
            const divEl = document.getElementById('div' + id);
            if (divEl && sec > 0) {
                const h = Math.floor(sec / 3600);
                const m = Math.floor((sec % 3600) / 60);
                const s = sec % 60;
                divEl.textContent = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
            }
        });

        // 4. Моргаем красным индикатором REC
        const recIndicator = document.querySelector('.xan-rec-indicator');
        if (recIndicator) {
            recIndicator.classList.remove('xan-rec-blink');
            void recIndicator.offsetWidth;
            recIndicator.classList.add('xan-rec-blink');
        }
    };

    // Единая обработка результата (для текущего DOM и для fetch)
    const handleResult = (parsed, isFromFetch = false) => {
        if (localStorage.getItem('xan3_doWatch') !== '1') return;

        if (parsed.exists) {
            if (parsed.scanTimeElem) {
                const rTimeStr = window.t('p_watcher_last_scan') + parsed.scanTimeElem.textContent.trim();
                localStorage.setItem('xan3_returnTime', rTimeStr);
                const rTimeEl = document.querySelector('#xan_return_time b');
                if (rTimeEl) rTimeEl.textContent = rTimeStr;
            }
            if (isFromFetch) updateLiveUI(parsed);

            fetchTimerId = setTimeout(() => {
                if (scanMethod === 'fetch') {
                    runFetchCycle();
                } else {
                    window.location.reload();
                }
            }, scanInterval);
        } else {
            if (parsed.scanTimeElem) {
                const timeStamp = parsed.scanTimeElem.textContent.trim();
                if (parsed.isBufferStop) {
                    localStorage.setItem('xan3_returnTime', `🛑 [БУФЕР ОСТАНОВЛЕН]`);
                    console.log(`[XAN Phalanx] Автоматизация остановлена по буферу экономии урана (${buffer} мин). Время последнего чека: ${timeStamp}`);
                } else if (parsed.isLandingStop) {
                    localStorage.setItem('xan3_returnTime', '🛬 [ФЛОТ ПРИЗЕМЛИЛСЯ]');
                    console.log(`[XAN Phalanx] Целевой флот долетел до планеты и совершил посадку (отзыва не было). Время фиксации: ${timeStamp}`);
                } else {
                    localStorage.setItem('xan3_returnTime', window.t('p_watcher_return') + timeStamp);
                }
            }
            localStorage.removeItem('xan3_doWatch');
            localStorage.removeItem('xan3_phalanxTargetHash');
            window.location.reload();
        }
    };

        // Фоновый запрос с чтением в UTF-8
    const runFetchCycle = async () => {
        if (localStorage.getItem('xan3_doWatch') !== '1') return;
        try {
            const targetUrl = window.location.href;
            const response = await fetch(targetUrl, {
                method: 'GET',
                credentials: 'include',
                cache: 'no-store'
            });
            const htmlText = await response.text();

            const parser = new DOMParser();
            const fetchedDoc = parser.parseFromString(htmlText, 'text/html');

            const hasPhalanxTable = fetchedDoc.querySelector('td[title="Время сканирования"]') || fetchedDoc.querySelector('td[title*="сканирован"]') || fetchedDoc.querySelector('td[title*="скануван"]');
            if (!hasPhalanxTable) {
                console.warn('[XAN Phalanx] Ответ fetch не содержит таблицу фаланги, повтор через интервал...');
                fetchTimerId = setTimeout(runFetchCycle, scanInterval);
                return;
            }

            const parsed = analyzeDocument(fetchedDoc);
            handleResult(parsed, true);
        } catch (err) {
            console.error('[XAN Phalanx] Ошибка fetch-запроса, повтор через интервал:', err);
            fetchTimerId = setTimeout(runFetchCycle, scanInterval);
        }
    };




    // Первичная проверка текущей загруженной страницы
    const initialParsed = analyzeDocument(document);
    handleResult(initialParsed, false);
}



function parseTimeToSeconds(tStr) {
    if (!tStr) return 0;
    let s = 0;
    const parts = tStr.split(':');
    if (parts.length === 3) {
        s += parseInt(parts.at(0), 10) * 3600;
        s += parseInt(parts.at(1), 10) * 60;
        s += parseInt(parts.at(2), 10);
        return s;
    }
    const h = tStr.match(/(\d+)\s*(h|ч)/i), m = tStr.match(/(\d+)\s*(m|м)/i), sec = tStr.match(/(\d+)\s*(s|с)/i);
    if (h) s += parseInt(h.at(1), 10) * 3600;
    if (m) s += parseInt(m.at(1), 10) * 60;
    if (sec) s += parseInt(sec.at(1), 10);
    return s;
}

function updateUraniumCalculation() {
    const container = document.getElementById('xan_uran_calc_container');
    const allTds = Array.from(document.querySelectorAll('td'));
    const uranTd = allTds.find(x => x.title === 'Урана в наличии' || x.title === 'Урану в наявності');
    const priceTd = allTds.find(x => x.title?.includes('Стоимость =') || x.title?.includes('Вартість ='));

    if (!container || !uranTd || !priceTd) return;

    const uText = uranTd.querySelector('font[color="orange"]') ? uranTd.querySelector('font[color="orange"]').textContent : uranTd.textContent;
    const pText = priceTd.querySelector('span') ? priceTd.querySelector('span').textContent : priceTd.textContent;
    
    const totalScansPossible = Math.floor(nsn(uText) / nsn(pText));
    if (totalScansPossible > 0) {
        const defaultInterval = parseInt(localStorage.getItem('xan3_phalanxInterval') || '1', 10);
        const currentTick = parseInt(document.getElementById('xan_p_interval')?.value || defaultInterval, 10);
        const totalSeconds = totalScansPossible * currentTick;
        
        const days = Math.floor(totalSeconds / 86400);
        const remainAfterDays = totalSeconds % 86400;
        
        const hrs = Math.floor(remainAfterDays / 3600);
        const mins = Math.floor((remainAfterDays % 3600) / 60);
        const secs = remainAfterDays % 60;

        const timeString = 
            String(hrs).padStart(2, '0') + ':' + 
            String(mins).padStart(2, '0') + ':' + 
            String(secs).padStart(2, '0');
        
        let finalDuration = '';
        if (days > 0) {
            const currentLang = localStorage.getItem('xan3_app_lang') || 'ru';
            let dayWord = '';

            if (currentLang === 'uk') {
                if (days % 10 === 1 && days % 100 !== 11) dayWord = 'день';
                else if ((days % 10 === 2 || days % 10 === 3 || days % 10 === 4) && (days % 100 < 10 || days % 100 >= 20)) dayWord = 'дні';
                else dayWord = 'днів';
            } else {
                if (days % 10 === 1 && days % 100 !== 11) dayWord = 'день';
                else if ((days % 10 === 2 || days % 10 === 3 || days % 10 === 4) && (days % 100 < 10 || days % 100 >= 20)) dayWord = 'дня';
                else dayWord = 'дней';
            }
            
            finalDuration = `${days} ${dayWord} ${timeString}`;
        } else {
            finalDuration = timeString;
        }
        
        container.innerHTML = t('p_uran_calc').replace('~ {min} мин.', finalDuration);
    }
}

