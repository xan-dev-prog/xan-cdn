import { nsn, spaces, getRandomInt } from './utils.js';
import { U_MINES, A_MINES, M_MINES } from './game_data.js';

const MIN_RATE = 1800;
const MIN_ENERGY = MIN_RATE * 25;

let pl = '';
let currCoords = '';
let mySavedArgs = [];

export function initMessagesPage() {
    const selectEl = document.querySelector('.menu-item select');
    if (!selectEl) return;

    pl = selectEl.options[selectEl.selectedIndex]?.text || '';
    if (!pl.includes('[') || !pl.includes(':')) return;

    currCoords = pl.substring(pl.indexOf('[') + 1, pl.lastIndexOf(':')).replace(/[^\d]+/ig, '_');
    
    const storedArgs = localStorage.getItem(`xan3_respyArgs_${currCoords}`);
    mySavedArgs = storedArgs ? storedArgs.split('|') : [];

    initGlobalOkButtons();
    parseSpyReports();
    improveMessages();
    initReportsComparison();
	
	/* test */
	const tdFrom = [...document.querySelectorAll('td')].find( x => x.textContent === 'От' );
	if (tdFrom) {
		tdFrom.style.cursor = 'pointer';
		tdFrom.addEventListener('click', () => {
			const greenBadges = document.querySelectorAll('[src$="tick-green.png"]');
					greenBadges.forEach(badge => {
						const tab = badge.closest('table');
						const tr = tab.closest('tr');
						const targ = tr.previousElementSibling.querySelector('[name^="delmes"]');
						if (targ) {
							targ.setAttribute('checked', true);
						} else {
							console.log('Какой-то косяк с поиском по DOM');
						}
					});
		});
	} else{
		console.log(' Ячейка с текстом "От" не найдена ');
	}
}

function initGlobalOkButtons() {
    const okButtons = document.querySelectorAll('input[value="[ ok ]"]');
    okButtons.forEach((btn, index) => {
        if (index === 0 || index === 2) {
            btn.classList.add('xan-ok-btn-highlight');
            btn.setAttribute('title', window.t("msg_del_all_title"));
            
            if (!btn.dataset.xanClickAttached) {
                btn.dataset.xanClickAttached = 'true';
                btn.addEventListener('mousedown', () => {
                    const deletes = document.querySelectorAll('select[id^="deletemess"]');
                    deletes.forEach(select => {
                        select.selectedIndex = 6;
                    });
                });
            }
        }
    });
}
function parseSpyReports() {
    const searchStr = window.location.search;
    if (!searchStr.includes('messcat=100') && !searchStr.includes('search_term') && !searchStr.includes('messcat=0')) return;

    const headers = document.querySelectorAll('[id^="number_"]');
    headers.forEach(header => {
        if (!header.textContent.includes(window.t("msg_spy_report"))) return;

        const nextRow = header.nextElementSibling;
        if (!nextRow) return;

        const allTds = Array.from(nextRow.querySelectorAll('td'));

        const mTd = allTds.find(td => td.textContent.includes(window.t("msg_metal_mine")));
        const aTd = allTds.find(td => td.textContent.includes(window.t("msg_crystal_mine")));
        const uTd = allTds.find(td => td.textContent.includes(window.t("msg_uran_synth")));

        const m_lev = Math.round(parseInt(mTd?.nextElementSibling?.textContent || '0')) || 0;
        const a_lev = Math.round(parseInt(aTd?.nextElementSibling?.textContent || '0')) || 0;
        const u_lev = Math.round(parseInt(uTd?.nextElementSibling?.textContent || '0')) || 0;

        const total_rate = Math.round((20 + (M_MINES[m_lev] || 0) + 4 * (10 + (A_MINES[a_lev] || 0) + (U_MINES[u_lev] || 0))) / 100);

        const mStorTd = allTds.find(td => td.textContent.includes(window.t("msg_metal_storage")));
        const aStorTd = allTds.find(td => td.textContent.includes(window.t("msg_crystal_storage")));
        const uStorTd = allTds.find(td => td.textContent.includes(window.t("msg_uran_storage")));

        const m_storage = parseInt(mStorTd?.nextElementSibling?.textContent || '0') || 0;
        const a_storage = parseInt(aStorTd?.nextElementSibling?.textContent || '0') || 0;
        const u_storage = parseInt(uStorTd?.nextElementSibling?.textContent || '0') || 0;
        const total_storage = m_storage + a_storage + u_storage;

        const energyTd = allTds.find(td => td.textContent.includes(window.t("msg_energy")));
        const energy = energyTd ? nsn(energyTd.nextElementSibling?.textContent || '') : 0;

        header.setAttribute('title', m_lev + ' ' + a_lev + ' ' + u_lev);

        if (isFinite(total_rate) && isFinite(total_storage)) {
            let clrClass = 'xan-bg-salmon';
            let title_tail = '';

            if (total_rate >= MIN_RATE) {
                if ((MIN_RATE / 40) <= total_storage) {
                    if (energy >= MIN_ENERGY) {
                        clrClass = 'xan-bg-green';
                    } else {
                        clrClass = 'xan-bg-cyan';
                        title_tail = '\nУровень энергии ниже минимального (мин. ' + MIN_ENERGY + '): ' + energy;
                    }
                } else {
                    clrClass = 'xan-bg-yellow';
                    title_tail = '\nУровень складов ниже минимального (мин. ' + (MIN_RATE / 40) + '): ' + total_storage;
                }
            }

            const targetTd = nextRow.querySelector('td.b');
            if (targetTd) {
                targetTd.setAttribute('title', 'Баллы: ' + total_rate + title_tail);
                targetTd.className = 'b ' + clrClass;
            }
        }
    });
}

function filterMes() {
    const msgCellCheck = document.getElementById('msgcell') || document.querySelector('#msgcell');
    if (!msgCellCheck) return;

    const badges = document.querySelectorAll('[data-visibility]');
    badges.forEach(badge => {
        const isHidden = badge.getAttribute('data-visibility') === 'hid';
        const rootContainer = badge.closest('tr');
        if (!rootContainer) return;

        let sibling = rootContainer.nextElementSibling;
        while (sibling && !sibling.querySelector('[id^="number_"]')) {
            sibling.style.display = isHidden ? 'none' : '';
            sibling = sibling.nextElementSibling;
        }

        const outerTable = badge.closest('table');
        if (outerTable) {
            const nextNode = outerTable.nextElementSibling;
            if (nextNode && nextNode.getAttribute('width') === '500') {
                nextNode.style.display = isHidden ? 'none' : '';
            }
        }
    });

    if (!document.getElementById('delMA')) {
        const submitBtn = document.querySelector('input[value="[ Отправить ]"]') || 
                          document.querySelector('input[value="[ Надіслати ]"]');
        if (submitBtn) {
            const row = submitBtn.closest('tr');
            if (row && row.previousElementSibling) {
                const checked = localStorage.getItem('xan3_delMesAfter') ? 'checked' : '';
                row.previousElementSibling.insertAdjacentHTML('beforebegin', 
                    '<tr class="xan-auto-row">' +
                        '<th class="c">' + window.t("msg_del_after_farm") + ' <span class="xan-help-tip" title="' + window.t("msg_del_after_farm") + '">[?]</span></th>' +
                        '<th class="c"><input id="delMA" type="checkbox" ' + checked + ' /></th>' +
                    '</tr>'
                );
                
                const delMAEl = document.getElementById('delMA');
                if (delMAEl) {
                    delMAEl.addEventListener('change', function() {
                        if (this.checked) {
                            localStorage.setItem('xan3_delMesAfter', '1');
                        } else {
                            localStorage.removeItem('xan3_delMesAfter');
                        }
                    });
                }
            }

            // --- ПЕРВАЯ СТАБИЛЬНАЯ РЕДАКЦИЯ: ВЫЛЕТ В ФОНЕ -> ПОЛНОЕ УДАЛЕНИЕ ---
            if (!submitBtn.dataset.xanSubmitAttached) {
                submitBtn.dataset.xanSubmitAttached = 'true';
                
                submitBtn.addEventListener('click', async function(e) {
                    const delMA = document.getElementById('delMA');
                    if (!delMA || !delMA.checked) return; 

                    e.preventDefault();

                    const attackForm = submitBtn.closest('form');
                    if (!attackForm) return;

                    const attackData = new FormData(attackForm);
                    if (submitBtn.name) {
                        attackData.append(submitBtn.name, submitBtn.value);
                    }

                    try {
                        submitBtn.value = "...Вылет...";
                        submitBtn.disabled = true;

                        // 1. Отправляем атаку на сервер
                        await fetch(attackForm.getAttribute('action') || window.location.href, {
                            method: 'POST',
                            body: attackData
                        });

                        // 2. Находим зеленые бейджи и отмечаем идущие вверх от них чекбоксы
                        /* const greenBadges = document.querySelectorAll('img[data-visibility="hid"].xan-tick-badge');
                        
                        greenBadges.forEach(badge => {
                            if (!badge.getAttribute('src').includes('tick-green.png')) return;

                            const targetTr = badge.closest('tr');
                            if (!targetTr) return;

                            const allRows = Array.from(document.querySelectorAll('tr'));
                            const targetIndex = allRows.indexOf(targetTr);
                            if (targetIndex === -1) return;

                            for (let i = targetIndex - 1; i >= 0; i--) {
                                const currentRow = allRows[i];
                                if (currentRow.id && currentRow.id.startsWith('number_')) {
                                    const delCheckbox = currentRow.querySelector('input[name^="delmes"]');
                                    if (delCheckbox) {
                                        delCheckbox.checked = true;
                                    }
                                }
                            }
                        }); */
						/* Мой вариант. ИИ намудрил выше нерабочую фигню, которую я закомментировал, но оставил на память */
						const greenBadges = document.querySelectorAll('[src$="tick-green.png"]');
					
						greenBadges.forEach(badge => {
							const tab = badge.closest('table');
							const tr = tab.closest('tr');
							const targ = tr.previousElementSibling.querySelector('[name^="delmes"]');
								if (targ) {
									targ.setAttribute('checked', true);
								} else {
									console.log('Какой-то косяк с поиском по DOM');
								}
						});

                        // 3. Находим кнопки [ ok ] и кликаем по второй
                        const okButtons = document.querySelectorAll('input[value="[ ok ]"]');
                        if (okButtons && okButtons[1]) {
                            okButtons[1].click();
                        } else {
                            location.reload();
                        }

                    } catch (err) {
                        console.error('Ошибка при отправке атаки:', err);
                        submitBtn.value = "[ Ошибка! ]";
                        submitBtn.disabled = false;
                        alert('Не удалось отправить флот в атаку: ' + err.message);
                    }
                });
            }
            // --- КОНЕЦ ЛОГИКИ ---
        }
    }

    calculateProfitableReports();
}



function calculateProfitableReports() {
    const rawElement = document.getElementById('msgcell') || document.querySelector('#msgcell');
    if (!rawElement) return; 

    const configData = localStorage.getItem('xan3_minMTtoFarm') ? localStorage.getItem('xan3_minMTtoFarm').split('|') : [];
    const maxFlInput = document.querySelector('input[name="maxFL"]');
    const minMT = +(configData[0]) || (maxFlInput ? +maxFlInput.value : 0) || 0;
    const maxSlt = +(configData[1]) || 1;

    // Сбор ячеек по overlib подсказкам игрового сервера
    const allTds = Array.from(document.querySelectorAll('td.i'));
    const mtCells = allTds.filter(td => {
        const mouseOverAttr = td.getAttribute('onmouseover') || '';
        return mouseOverAttr.includes('Необходимо кораблей «Малый танкер»') || 
               mouseOverAttr.includes('Необхідно кораблів «Малий танкер»');
    });

    const profitableOnes = mtCells.filter(cell => nsn(cell.textContent) >= minMT);
    const summary = profitableOnes.map(cell => cell.textContent.replace(/&nbsp;/ig, ' ').trim());

    let clrClass = 'xan-text-crimson';
    if (profitableOnes.length >= maxSlt) clrClass = 'xan-text-green';
    else if (profitableOnes.length >= Math.floor(maxSlt * 0.7)) clrClass = 'xan-text-orange';

    const statBlock = document.getElementById('mySavedStat');
    if (statBlock && !document.getElementById('setMinMT')) {
        statBlock.insertAdjacentHTML('beforeend', 
            ' <span style="margin: 0 10px;">|</span>' + 
            '<div id="setMinMT" style="display: inline; margin-left: 10px; cursor: pointer;" class="xan-farm-header">' +
                window.t("msg_good_ones_label") + ' <span id="good_ones" class="' + clrClass + '">' + profitableOnes.length + '</span>' +
            '</div>' +
            ' <span style="margin: 0 5px;">|</span>' +
            '<div id="xanHelpBtn" style="display: inline; margin-left: 5px; cursor: pointer; color: #6495ED; font-weight: bold; padding: 0 4px;" title="' + window.t("msg_help_title") + '">[ ? ]</div>'
        );
    }

    rawElement.className = 'c xan-msg-cell-clean';

    // Подключение изолированных обработчиков событий
    initHelpButtonLogic(rawElement);
    initTooltipLogic(summary, minMT);
    initSettingsMenuLogic(rawElement, mtCells, minMT, maxSlt);
}

function initHelpButtonLogic(rawElement) {
    const helpBtn = document.getElementById('xanHelpBtn');
    if (!helpBtn) return;

    helpBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const existingHelp = document.getElementById('xan-help-guide');
        if (existingHelp) {
            existingHelp.remove();
            return;
        }

        rawElement.insertAdjacentHTML('beforeend', 
            '<div id="xan-help-guide" style="background: #15171e; border: 1px solid #34495e; border-radius: 5px; padding: 15px; margin-top: 15px; text-align: left; color: #e0e0e0; font-family: sans-serif; font-size: 12px; line-height: 1.5; max-width: 600px; margin-left: auto; margin-right: auto;">' +
                '<h3 style="margin-top:0; color: #6495ED; border-bottom: 1px solid #34495e; padding-bottom: 5px; font-size: 14px;">' + window.t("msg_help_guide_hdr") + '</h3>' +
                
                '<p style="color: #4db8ff; font-weight: bold; margin: 10px 0 5px 0;">📊 ' + window.t("msg_help_cat_filter") + ':</p>' +
                '<ul style="margin: 0; padding-left: 20px; list-style-type: square;">' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_step1_title") + ':</b> ' + window.t("msg_help_step1_desc") + '</li>' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_step2_title") + ':</b> ' + window.t("msg_help_step2_desc") + '</li>' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_step3_title") + ':</b> ' + window.t("msg_help_step3_desc") + '</li>' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_step4_title") + ':</b> ' + window.t("msg_help_step4_desc") + '</li>' +
                '</ul>' +

                '<p style="color: #ff944d; font-weight: bold; margin: 12px 0 5px 0;">🚀 ' + window.t("msg_help_cat_farm") + ':</p>' +
                '<ul style="margin: 0; padding-left: 20px; list-style-type: square;">' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_farm1_title") + ':</b> ' + window.t("msg_help_farm1_desc") + '</li>' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_farm2_title") + ':</b> ' + window.t("msg_help_farm2_desc") + '</li>' +
                '</ul>' +

                '<p style="color: #33cc66; font-weight: bold; margin: 12px 0 5px 0;">👁️ ' + window.t("msg_help_cat_respy") + ':</p>' +
                '<ul style="margin: 0; padding-left: 20px; list-style-type: square;">' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_spy1_title") + ':</b> ' + window.t("msg_help_spy1_desc") + '</li>' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_spy2_title") + ':</b> ' + window.t("msg_help_spy2_desc") + '</li>' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_spy3_title") + ':</b> ' + window.t("msg_help_spy3_desc") + '</li>' +
                '</ul>' +

                '<p style="color: #cc66ff; font-weight: bold; margin: 12px 0 5px 0;">🛠️ ' + window.t("msg_help_cat_utils") + ':</p>' +
                '<ul style="margin: 0; padding-left: 20px; list-style-type: square;">' +
                    '<li style="margin-bottom: 4px;"><b>' + window.t("msg_help_util1_title") + ':</b> ' + window.t("msg_help_util1_desc") + '</li>' +
                    '<li style="margin-bottom: 0;"><b>' + window.t("msg_help_util2_title") + ':</b> ' + window.t("msg_help_util2_desc") + '</li>' +
                '</ul>' +
            '</div>'
        );
    });
}

function initTooltipLogic(summary, minMT) {
    const goodOnesBtn = document.getElementById('good_ones');
    if (!goodOnesBtn) return;

    goodOnesBtn.addEventListener('mouseover', (e) => {
        const content = summary
            .sort((a, b) => nsn(a) - nsn(b))
            .map((x, i, arr) => {
                if (i === 0) return x;
                const prevNum = nsn(arr[i - 1]);
                const currNum = nsn(x);
                const prevDigits = Math.floor(Math.log10(prevNum || 1));
                const currDigits = Math.floor(Math.log10(currNum || 1));
                return currDigits > prevDigits ? '<br/><br/>' + x : ', ' + x;
            })
            .join('');

        document.body.insertAdjacentHTML('beforeend', 
            '<div id="xan-tip" class="xan-floating-tip">' +
                '<h3>' + window.t("msg_good_ones_label") + ' (Мин: ' + minMT + ' МТ)</h3>' +
                (content ? content : '<span style="color: #a0a0a0; font-style: italic;">Нет подходящих докладов</span>') +
            '</div>'
        );

        const tip = document.getElementById('xan-tip');
        if (tip) {
            tip.style.top = (e.pageY + 30) + 'px';
            tip.style.left = (e.pageX - (tip.offsetWidth / 2)) + 'px';
        }
    });

    goodOnesBtn.addEventListener('mouseout', () => {
        const tip = document.getElementById('xan-tip');
        if (tip) tip.remove();
    });
}

function initSettingsMenuLogic(rawElement, mtCells, minMT, maxSlt) {
    const setMinMTBtn = document.getElementById('setMinMT');
    if (!setMinMTBtn) return;

    setMinMTBtn.addEventListener('click', function(e) {
        e.preventDefault();
        const configContainer = document.getElementById('xan-config-container');
        if (configContainer) {
            configContainer.remove();
            return;
        }

        rawElement.insertAdjacentHTML('beforeend', 
            '<div id="xan-config-container" class="xan-inline-config" style="margin-top: 10px;">' +
                '<p>' + window.t("msg_min_mt_setup") + ' <input id="input_setMinMT" type="number" value="' + minMT + '" /></p>' +
                '<p>' + window.t("msg_max_slots_setup") + ' <input id="input_setMaxSlt" type="number" value="' + maxSlt + '" /></p>' +
                '<p>' +
                    '<button id="saveMinMT" class="xan-custom-input-select xan-ok-button-highlight">[ ' + window.t("msg_btn_save") + ' ]</button>' +
                    '<button id="delUnprofitable">[ Удалить невыгодные ]</button>' +
                '</p>' +
            '</div>'
        );

        document.getElementById('saveMinMT')?.addEventListener('click', () => {
            const minMTVal = document.getElementById('input_setMinMT')?.value || 0;
            const maxSltVal = document.getElementById('input_setMaxSlt')?.value || 0;
            localStorage.setItem('xan3_minMTtoFarm', minMTVal + '|' + maxSltVal);
            setTimeout(() => location.reload(), 300);
        });

        document.getElementById('delUnprofitable')?.addEventListener('click', (event) => {
            event.preventDefault();
            let checkedCount = 0;

            mtCells.forEach(cell => {
                const parsedValue = nsn(cell.textContent);
                if (parsedValue > 0 && parsedValue < minMT) {
                    let currentElement = cell.closest('tr');
                    if (!currentElement) return;

                    let mainFormRow = currentElement;
                    while (mainFormRow && mainFormRow.parentElement && mainFormRow.parentElement.closest('table').id === '') {
                        mainFormRow = mainFormRow.parentElement.closest('tr');
                    }
                    if (!mainFormRow) mainFormRow = currentElement.closest('table').closest('tr');
                    if (!mainFormRow) return;

                    let headerRow = mainFormRow.previousElementSibling;
                    while (headerRow && !(headerRow.id && headerRow.id.startsWith('number_'))) {
                        headerRow = headerRow.previousElementSibling;
                    }

                    if (headerRow) {
                        const delCheckbox = headerRow.querySelector('input[name^="delmes"]');
                        if (delCheckbox && !delCheckbox.checked) {
                            delCheckbox.checked = true;
                            checkedCount++;
                        }
                    }
                }
            });

            if (checkedCount > 0) {
                const okButtons = document.querySelectorAll('input[value="[ ok ]"]');
                if (okButtons && okButtons[1]) okButtons[1].click();
                else alert('Чекбоксы отмечены (' + checkedCount + '), но вторая кнопка [ ok ] не найдена.');
            } else {
                alert('Невыгодных докладов на этой странице не обнаружено.');
            }
        });
    });
}


async function sendShips(order, g, s, p, ptype, shipcount, myOtherPlanet, curr) {
    const msgCell = document.getElementById('msgcell');
    if (!msgCell) return;

    try {
        const formData = new FormData();
        formData.append('ship210', shipcount);
        formData.append('ship209', '0');
        formData.append('mission', order);
        formData.append('galaxy', g);
        formData.append('system', s);
        formData.append('planet', p);
        formData.append('planettype', ptype);
        formData.append('myOtherPlanet', myOtherPlanet);

        const response = await fetch('flotenajax.php?action=send', { method: 'POST', body: formData });
        const resData = await response.json();

        if (resData.code === 0 && resData.message.includes('отправлены на')) {
            const count = document.querySelectorAll('.xan-spy-log-row').length;
            msgCell.insertAdjacentHTML('beforeend', '<div class="xan-spy-log-row">' + (count + 1) + '. ' + resData.message + '</div>');
            window.scrollBy({ top: 15, left: 0, behavior: 'smooth' });

            curr++;
            if (curr < mySavedArgs.length) {
                setTimeout(() => {
                    const args = mySavedArgs[curr].split(',');
                    sendShips(args[0], args[1], args[2], args[3], args[4], args[5], args[6], curr);
                }, getRandomInt(1000, 3000));
            } else {
                msgCell.insertAdjacentHTML('beforeend', '<div class="xan-text-success">' + window.t("msg_respy_complete") + '</div>');
                const timesBtn = document.getElementById('times');
                if (timesBtn) setTimeout(() => timesBtn.click(), 2500);
            }
        } else {
            if (resData.message.includes('Флоты заняты')) {
                const waitMin = 1;
                msgCell.insertAdjacentHTML('beforeend', '<div>' + window.t("msg_no_slots_wait").replace('{num}', waitMin) + '</div>');
                setTimeout(() => {
                    const args = mySavedArgs[curr].split(',');
                    sendShips(args[0], args[1], args[2], args[3], args[4], args[5], args[6], curr);
                }, waitMin * 60 * 1000);
            } else {
                msgCell.insertAdjacentHTML('beforeend', '<div class="xan-text-warning">' + resData.message + '</div>');
                
                if (resData.message === window.t("msg_no_spies_err")) {
                    msgCell.insertAdjacentHTML('beforeend', '<div class="xan-text-success">' + window.t("msg_respy_complete") + '</div>');
                    const timesBtn = document.getElementById('times');
                    if (timesBtn) setTimeout(() => timesBtn.click(), 1500);
                } else {
                    curr++;
                    setTimeout(() => {
                        const nextArgs = mySavedArgs[curr]?.split(',');
                        if (nextArgs) {
                            sendShips(nextArgs[0], nextArgs[1], nextArgs[2], nextArgs[3], nextArgs[4], nextArgs[5], nextArgs[6], curr);
                        } else {
                            msgCell.insertAdjacentHTML('beforeend', '<div class="xan-text-success">' + window.t("msg_respy_complete") + '</div>');
                            const timesBtn = document.getElementById('times');
                            if (timesBtn) setTimeout(() => timesBtn.click(), 1000);
                        }
                    }, 1000);
                }
            }
        }
    } catch (err) {
        msgCell.insertAdjacentHTML('beforeend', '<div class="xan-text-crimson">Error: ' + err.message + '</div>');
    }
}

function renderSavedStatus() {
    const statBlock = document.getElementById('mySavedStat');
    if (!statBlock) return;

    statBlock.innerHTML = '<span id="savedSummary" title="' + window.t("msg_saved_total_title").replace('{num}', mySavedArgs.length) + '">' + window.t("msg_saved_label") + ' ' + mySavedArgs.length + '</span>';
    
    const posSelect = document.getElementById('respyPosition');
    if (!posSelect) return;
    posSelect.innerHTML = '';

    if (mySavedArgs.length === 0) return;

    statBlock.insertAdjacentHTML('afterbegin', 
        '<div id="readUp" style="display:inline-block;" class="xan-btn-orange" title="' + window.t("msg_read_up_title") + '">' + window.t("msg_read_up") + '</div>&nbsp;&nbsp;|&nbsp;&nbsp;' +
        '<div id="showList" style="display:inline-block;" class="xan-btn-green" title="' + window.t("msg_show_list_title") + '">' + window.t("msg_show_list") + '</div>&nbsp;&nbsp;|&nbsp;&nbsp;'
    );

    const readUpBtn = document.getElementById('readUp');
    if (readUpBtn) {
        readUpBtn.addEventListener('click', function() {
            const listDiv = document.getElementById('argList');
            if (listDiv) {
                listDiv.remove();
                this.textContent = window.t("msg_read_up");
                this.className = 'xan-btn-orange';
            } else {
                this.textContent = window.t("msg_show_list");
                this.className = 'xan-btn-salmon';
                const msgCell = document.getElementById('msgcell');
                if (msgCell) {
                    msgCell.insertAdjacentHTML('beforeend', 
                        '<div id="argList" class="xan-arg-list-box">' +
                            '<textarea rows="10" id="newList" placeholder="' + window.t("msg_textarea_placeholder") + '"></textarea><br />' +
                            '<input id="saveNewList" type="button" value="' + window.t("msg_btn_save") + '" title="' + window.t("msg_save_new_list_title") + '" />' +
                            '<input id="addNewList" type="button" value="' + window.t("msg_btn_add") + '" title="' + window.t("msg_add_new_list_title") + '" />' +
                        '</div>'
                    );
                }

                document.getElementById('saveNewList')?.addEventListener('click', () => {
                    const rawVal = document.getElementById('newList')?.value || '';
                    if (rawVal.length < 10) return;
                    const temp = [];
                    rawVal.split('\n').forEach(line => line.includes('.') && temp.push(line.substring(line.indexOf('.') + 2)));
                    localStorage.setItem(`xan3_respyArgs_${currCoords}`, temp.join('|'));
                    setTimeout(() => location.reload(), 300);
                });

                document.getElementById('addNewList')?.addEventListener('click', () => {
                    const rawVal = document.getElementById('newList')?.value || '';
                    if (rawVal.length < 10) return;
                    const currentSet = new Set(mySavedArgs);
                    if (rawVal.includes('Атакова') || rawVal.includes('Атакува')) {
                        rawVal.split('\n').filter(s => s.includes('Атако') || s.includes('Атаку')).forEach(row => {
                            const matches = row.match(/\[.+?\]/g);
                            if (matches) {
                                const digits = matches[0].match(/\d+/g);
                                if (digits) currentSet.add('6,' + digits.join(',') + ',1,20,0');
                            }
                        });
                        localStorage.setItem(`xan3_respyArgs_${currCoords}`, [...currentSet].join('|'));
                        setTimeout(() => location.reload(), 300);
                    }
                });
            }
        });
    }

    const showListBtn = document.getElementById('showList');
    if (showListBtn) {
        showListBtn.addEventListener('click', function() {
            const listDiv = document.getElementById('argList');
            if (listDiv) {
                listDiv.remove();
                this.textContent = window.t("msg_show_list");
                this.className = 'xan-btn-green';
            } else {
                this.textContent = window.t("msg_hide_list");
                this.className = 'xan-btn-salmon';
                const msgCell = document.getElementById('msgcell');
                if (msgCell) msgCell.insertAdjacentHTML('beforeend', '<div id="argList" class="xan-arg-list-box"></div>');
                
                const uniq = new Set();
                const container = document.getElementById('argList');
                if (container) {
                    mySavedArgs.forEach((item, i) => {
                        const isUniq = uniq.has(item);
                        uniq.add(item);
                        container.insertAdjacentHTML('beforeend', '<div class="' + (isUniq ? 'xan-text-salmon' : '') + '"><span class="xan-text-orange">' + (i + 1) + '</span>. ' + item + '</div>');
                    });

                    container.insertAdjacentHTML('beforeend', '<div class="xan-summary-row">' + window.t("msg_uniq_found") + ' <span class="' + (uniq.size === mySavedArgs.length ? 'xan-text-green' : 'xan-text-crimson') + '">' + uniq.size + '</span></div>');
                }
            }
        });
    }

    for (let i = 0; i < mySavedArgs.length; i++) {
        const opt = document.createElement('option');
        opt.value = i.toString();
        opt.textContent = (i + 1).toString();
        posSelect.appendChild(opt);
    }
}

export function improveMessages() {
    const searchStr = window.location.search;
    if (!searchStr.includes('messcat=100') && !searchStr.includes('search_term') && !searchStr.includes('messcat=0')) return;

    const hasSpyReportsOnPage = document.querySelectorAll('[id^="spyGo"]').length > 0;
    
    let hasAnySavedCoordinatesInStorage = false;
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('xan3_respyArgs_')) {
            const data = localStorage.getItem(key);
            if (data && data.trim().length > 0) {
                hasAnySavedCoordinatesInStorage = true;
                break;
            }
        }
    }

    if (!hasAnySavedCoordinatesInStorage && !hasSpyReportsOnPage) {
        return; 
    }

    const isfarmBtn = document.querySelector('input[value="[ Ишкофарм ]"], input[value="[ Ішкофарм ]"]');
    const firstPlsTr = [...document.querySelectorAll('td')].find(x => x.textContent === '+')?.closest('tr');
    
    if (!firstPlsTr) return;

    const controlPanelHtml = 
        '<tr class="xan-control-panel-row">' +
            '<td data-cont="clearSavedMessages" class="c">-</td>' +
            '<td class="c" colspan="3">' +
                '<span id="mySavedStat">-</span>' +
                '<span style="margin: 0 10px;">|</span>' +
                '<select id="respyPosition" title="' + window.t("msg_pos_title") + '"></select>' +
            '</td>' +
            '<td class="c">' +
                '<div id="respyButton" class="xan-eye-btn" title="' + window.t("msg_respy_btn_title") + '">' +
                    '<img src="' + chrome.runtime.getURL('images/eye.png') + '" alt="XAN" />' +
                '</div>' +
            '</td>' +
        '</tr>' +
        '<tr class="xan-control-panel-row">' +
            '<th id="msgcell" colspan="5" class="c"></th>' +
        '</tr>';

    firstPlsTr.insertAdjacentHTML('afterend', controlPanelHtml);

    renderSavedStatus();

    const respyBtn = document.getElementById('respyButton');
    if (respyBtn) {
        respyBtn.addEventListener('click', () => {
            const listDiv = document.getElementById('argList');
            if (listDiv) {
                const showListBtn = document.getElementById('showList');
                if (showListBtn) showListBtn.click();
            }
            
            const msgCell = document.getElementById('msgcell');
            if (!msgCell) return;

            if (mySavedArgs.length === 0) {
                msgCell.innerHTML = '<span class="xan-text-salmon">' + window.t("msg_no_saved_reports") + '</span>';
            } else {
                const posSelect = document.getElementById('respyPosition');
                const pos = +(posSelect?.value) || 0;
                const args = mySavedArgs[pos].split(',');
                sendShips(args[0], args[1], args[2], args[3], args[4], args[5], args[6], pos);
            }
        });
    }

    if (mySavedArgs.length > 0) {
        const clearCell = document.querySelector('[data-cont="clearSavedMessages"]');
        if (clearCell) {
            clearCell.innerHTML = '<img src="' + chrome.runtime.getURL('images/clear.png') + '" id="delSavedMes" title="' + window.t("msg_del_saved_title") + '" style="cursor:pointer;" />';
            document.getElementById('delSavedMes')?.addEventListener('click', () => {
                if (confirm(window.t("msg_confirm_del_coords"))) {
                    localStorage.removeItem(`xan3_respyArgs_${currCoords}`);
                    setTimeout(() => location.reload(), 200);
                }
            });
        }
    }

    const goButtons = document.querySelectorAll('[id^="spyGo"]');
    goButtons.forEach(goBtn => {
        const parentNode = goBtn.parentNode;
        if (!parentNode) return;
        
        const rawOnclick = parentNode.getAttribute('onclick') || '';
        const args = rawOnclick.substring(rawOnclick.indexOf('(') + 1, rawOnclick.indexOf(')')).replace(/[\s]+/ig, '');
        const isSaved = mySavedArgs.includes(args);

        parentNode.parentNode?.insertAdjacentHTML('beforeend', 
            '<img data-visibility="' + (isSaved ? 'hid' : 'vis') + '" data-args="' + args + '" src="' + chrome.runtime.getURL('images/tick-' + (isSaved ? 'green' : 'red') + '.png') + '" class="xan-tick-badge" />'
        );
    });

    const badges = document.querySelectorAll('[data-visibility]');
    badges.forEach(badge => {
        badge.addEventListener('click', function() {
            const isvis = this.getAttribute('data-visibility');
            const targetArgs = this.getAttribute('data-args');
            const nextSrc = isvis === 'hid' ? 'red' : 'green';
            const nextVis = isvis === 'hid' ? 'vis' : 'hid';

            this.setAttribute('src', chrome.runtime.getURL('images/tick-' + nextSrc + '.png'));
            this.setAttribute('data-visibility', nextVis);

            if (isvis === 'vis') {
                if (!mySavedArgs.includes(targetArgs)) mySavedArgs.push(targetArgs);
            } else {
                const idx = mySavedArgs.indexOf(targetArgs);
                if (idx !== -1) mySavedArgs.splice(idx, 1);
            }

            localStorage.setItem(`xan3_respyArgs_${currCoords}`, mySavedArgs.join('|'));
            renderSavedStatus();
            filterMes();
        });
    });

    filterMes();
}
export function initReportsComparison() {
    const searchStr = window.location.search;
    if (!searchStr.includes('messcat=100') && !searchStr.includes('search_term') && !searchStr.includes('messcat=0')) return;

    const headers = document.querySelectorAll('[id^="number_"]');
    headers.forEach(row => {
        if (!row.nextElementSibling?.textContent.includes(window.t("msg_defense"))) return;

        Array.from(row.children).forEach(cell => {
            cell.classList.add('xan-clickable-hdr');
            cell.setAttribute('title', window.t("msg_compare_title"));

            cell.addEventListener('click', function() {
                this.classList.toggle('xan-compare-active');
                const activeNodes = document.querySelectorAll('.xan-compare-active');

                if (activeNodes.length === 2) {
                    const aRow = activeNodes[0].closest('tr');
                    const bRow = activeNodes[1].closest('tr');

                    if (aRow && bRow && aRow.nextElementSibling?.textContent === bRow.nextElementSibling?.textContent) {
                        const tabs1 = fetchReportTablesData(aRow.nextElementSibling);
                        const tabs2 = fetchReportTablesData(bRow.nextElementSibling);

                        compareTableArrays(tabs1, tabs2);
                        compareTableArrays(tabs2, tabs1);
                    }
                } else {
                    const marks = document.querySelectorAll('.xan-greater, .xan-lesser, .xan-uniq');
                    marks.forEach(el => {
                        el.classList.remove('xan-greater', 'xan-lesser', 'xan-uniq');
                        el.removeAttribute('title');
                    });
                }
            });
        });
    });
}

function fetchReportTablesData(rootRow) {
    return Array.from(rootRow.querySelectorAll('table')).slice(0, 3).map(table => 
        Array.from(table.querySelectorAll('[align="right"]')).map(td => [
            td, 
            td.previousElementSibling?.textContent || '', 
            nsn(td.textContent)
        ])
    );
}

function compareTableArrays(source, target) {
    for (let i = 0; i < source.length; i++) {
        for (let n = 0; n < source[i].length; n++) {
            const matchedItem = target[i]?.find(item => item[1] === source[i][n][1]) || null;
            const currentTd = source[i][n][0];

            if (matchedItem) {
                const srcVal = source[i][n][2];
                const trgVal = matchedItem[2];

                if (srcVal > trgVal) {
                    currentTd.className = 'xan-greater';
                    currentTd.setAttribute('title', window.t("msg_greater_title"));
                } else if (srcVal < trgVal) {
                    currentTd.className = 'xan-lesser';
                    currentTd.setAttribute('title', window.t("msg_lesser_title"));
                }
            } else {
                currentTd.className = 'xan-uniq';
            }
        }
    }
}
