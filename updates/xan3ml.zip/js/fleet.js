// js/fleet.js — Главный диспетчер флота (Роутер)

import { isScriptActive } from './utils.js';
// === ГЛАВНАЯ ФУНКЦИЯ МОДУЛЯ (ТОЧКА ВХОДА) ===
// Именно её мы вызываем из главного switch-роутера в main.js

export function initFleetModule(page) {
  console.log(`[Fleet Router] Активирован для страницы: ${page}`);

  switch (page) {
    case 'fleet':    // Первая страница (выбор кораблей)
      import(chrome.runtime.getURL('js/fleet_page1.js'))
        .then(module => module.initPage1())
        .catch(err => console.error("[XAN Fleet] Ошибка загрузки этапа 1:", err));
      break;

    case 'floten1': // Вторая страница (координаты и скорость)
      import(chrome.runtime.getURL('js/fleet_page2.js'))
        .then(module => module.initPage2())
        .catch(err => console.error("[XAN Fleet] Ошибка загрузки этапа 2:", err));
      break;

    case 'floten2': // Третья страница (выбор миссии и ресурсов)
      // 1. Запуск базовой логики этапа 3 (кнопка Пуск, рефреш, удержание ресурсов на Луне)
      import(chrome.runtime.getURL('js/fleet_page3.js'))
        .then(module => module.initPage3())
        .catch(err => console.error("[XAN Fleet] Ошибка загрузки этапа 3:", err));

      // 2. ИЗОЛИРОВАННЫЙ ЗАПУСК КАРГО-МЕНЕДЖЕРА С ПРОВЕРКОЙ ЧЕРЕЗ СИСТЕМНУЮ УТИЛИТУ XAN
      if (isScriptActive('cargo')) {
          import(chrome.runtime.getURL('js/cargo.js'))
            .then(module => module.initCargoModule())
            .catch(err => console.error("[XAN Fleet] Ошибка загрузки Cargo Manager:", err));
      }
      break;


  }
}



// === ОБЩАЯ ФУНКЦИЯ ===

function runCommonFleetLogic() {
  console.log('-> Скрипт: Запущена общая магия для всех страниц флота ✨');
  // Код, который сработает в любом случае (для fleet, fleet1 и fleet2)
}
