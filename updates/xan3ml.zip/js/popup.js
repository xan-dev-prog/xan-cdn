document.addEventListener('DOMContentLoaded', async () => {
  // 1. Проверяем, не скрыл ли пользователь баннер в текущей сессии браузера
  if (sessionStorage.getItem('updateBannerDismissed') === 'true') {
    return; // Если скрыл, ничего не делаем, баннер остается display: none
  }

  // 2. Читаем данные об обновлении из глобального хранилища расширения
  const data = await chrome.storage.local.get(['updateAvailable', 'downloadUrl', 'newVersion']);
  
  if (data.updateAvailable) {
    const banner = document.getElementById('update-banner');
    const link = document.getElementById('download-link');
    const versionSpan = document.getElementById('new-version-num');
    const closeBtn = document.getElementById('close-banner');
    
    // Подставляем актуальные данные
    versionSpan.textContent = data.newVersion;
    link.href = data.downloadUrl;
    
    // Показываем баннер пользователю
    banner.style.display = 'block';
    
	// При открытии попапа очищаем уведомление на иконке
	chrome.action.setBadgeText({ text: "" });
	
    // 3. Обработчик клика на крестик
    closeBtn.addEventListener('click', () => {
      banner.style.display = 'none'; // Скрываем визуально прямо сейчас
      sessionStorage.setItem('updateBannerDismissed', 'true'); // Запоминаем до закрытия браузера
    });
  }
  
    // Временная кнопка открытия справочника XAN в новой вкладке
  const openGuideBtn = document.getElementById('open-guide-btn');
  if (openGuideBtn) {
    openGuideBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('guide/index.html') });
    });
  }

});
