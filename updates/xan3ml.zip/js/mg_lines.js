// js/mg_lines.js — Самообучающийся Pro-солвер мини-игры «Линии» (10x10)

import { _ } from './query.js';
import { getRandomInt } from './utils.js';
import { createMinigameControlBar, isMinigameOver, sleep } from './mini_games.js';

const AI_STATE_KEY = 'xan3_lines_ai_state_v1';
const SPEED_STORAGE_KEY = 'xan3_lines_speed_mode';

const SPEED_PROFILES = {
    fast: { clickMin: 120, clickMax: 220, thinkMin: 500, thinkMax: 750, longMin: 800, longMax: 1100 },
    normal: { clickMin: 180, clickMax: 320, thinkMin: 850, thinkMax: 1250, longMin: 1300, longMax: 1750 },
    careful: { clickMin: 240, clickMax: 420, thinkMin: 1250, thinkMax: 1750, longMin: 1800, longMax: 2400 }
};

const DEFAULT_WEIGHTS = {
    w4: 440,
    w3: 150,
    w2: 38,
    wFork: 260,
    wOpen: 42,
    wHintMatch: 185,
    wHintBlock: 110,
    wDisplace: 36,
    wEdge: 16,
    wCenter: 22,
    greedThreshold: 54
};

function getEmptyAIState() {
    return {
        generation: 1,
        bestWeights: { ...DEFAULT_WEIGHTS },
        candidateWeights: null,
        championScores: [],
        candidateScores: [],
        history: []
    };
}

function normalizeAIState(parsed) {
    if (!parsed || typeof parsed !== 'object') return getEmptyAIState();
    return {
        generation: parsed.generation || 1,
        bestWeights: { ...DEFAULT_WEIGHTS, ...(parsed.bestWeights || {}) },
        candidateWeights: parsed.candidateWeights ? { ...DEFAULT_WEIGHTS, ...parsed.candidateWeights } : null,
        championScores: Array.isArray(parsed.championScores) ? parsed.championScores : [],
        candidateScores: Array.isArray(parsed.candidateScores) ? parsed.candidateScores : [],
        history: Array.isArray(parsed.history) ? parsed.history : []
    };
}

async function loadAIState() {
    try {
        if (chrome?.storage?.local) {
            const res = await chrome.storage.local.get(AI_STATE_KEY);
            if (res && res[AI_STATE_KEY]) {
                return normalizeAIState(res[AI_STATE_KEY]);
            }
            const legacyRaw = localStorage.getItem(AI_STATE_KEY);
            if (legacyRaw) {
                const migrated = normalizeAIState(JSON.parse(legacyRaw));
                await chrome.storage.local.set({ [AI_STATE_KEY]: migrated });
                localStorage.removeItem(AI_STATE_KEY);
                return migrated;
            }
        }
    } catch (e) {}
    return getEmptyAIState();
}

function saveAIState(state) {
    try {
        if (chrome?.storage?.local) {
            chrome.storage.local.set({ [AI_STATE_KEY]: state });
        }
    } catch (e) {}
}

function mutateWeights(baseWeights) {
    const next = { ...baseWeights };
    const keys = Object.keys(DEFAULT_WEIGHTS);
    const mutationsCount = getRandomInt(2, 3);
    for (let i = 0; i < mutationsCount; i++) {
        const k = keys[getRandomInt(0, keys.length - 1)];
        const factor = 1 + (Math.random() * 0.4 - 0.2);
        if (k === 'greedThreshold') {
            next[k] = Math.max(40, Math.min(72, Math.round(next[k] + getRandomInt(-6, 6))));
        } else {
            next[k] = Math.max(5, Math.round(next[k] * factor));
        }
    }
    return next;
}
export async function initLinesGame(form) {
    const cells = Array.from(form.querySelectorAll('.space th.cell'));
    if (cells.length !== 100) return;

    const SIZE = 10;
    const DX_4 = new Array(0, 1, 0, -1);
    const DY_4 = new Array(1, 0, -1, 0);
    const AX_4 = new Array(1, 0, 1, -1);
    const AY_4 = new Array(0, 1, 1, 1);

    let isRunning = false;
    let stopRequested = false;
    let aiState = await loadAIState();

    const ui = createMinigameControlBar(
        form,
        () => startLinesSolving(),
        () => { stopRequested = true; }
    );

    const savedSpeed = localStorage.getItem(SPEED_STORAGE_KEY) || 'normal';

    const panel = _('#xan-mg-panel');
    if (panel) {
        panel.insertAdjacentHTML('afterend', `
            <div id="xan-lines-stats" style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-top:4px; padding:3px 8px; background:rgba(13,17,23,0.85); border:1px solid #21262d; border-radius:4px; font-size:11px; color:#8b949e; font-weight:normal;">
                <span id="xan-lines-metrics"></span>
                <div style="display:flex; align-items:center; gap:6px;">
                    <select id="xan-lines-speed" title="Темп игры бота (пауза между ходами)" style="cursor:pointer; padding:1px 4px; background:#161b22; color:#c9d1d9; border:1px solid #30363d; border-radius:3px; font-size:10px;">
                        <option value="fast" ${savedSpeed === 'fast' ? 'selected' : ''}>⚡ Быстро (~0.6с)</option>
                        <option value="normal" ${savedSpeed === 'normal' ? 'selected' : ''}>🧑 Норма (~1.0с)</option>
                        <option value="careful" ${savedSpeed === 'careful' ? 'selected' : ''}>🐢 Осторожно (~1.5с)</option>
                    </select>
                    <button type="button" id="xan-lines-train-btn" title="Быстрая эволюционная тренировка весов в памяти браузера (0 запросов на сервер)" style="cursor:pointer; padding:1px 7px; background:#1f6feb; color:#fff; border:1px solid #388bfd; border-radius:3px; font-size:10px;">
                        ⚡ Обучить (40 игр)
                    </button>
                    <button type="button" id="xan-lines-reset-btn" title="Сбросить статистику и веса ИИ" style="cursor:pointer; padding:1px 6px; background:#21262d; color:#8b949e; border:1px solid #30363d; border-radius:3px; font-size:10px;">
                        ↺
                    </button>
                </div>
            </div>
        `);
    }

    _('#xan-lines-speed')?.on('change', (e) => {
        localStorage.setItem(SPEED_STORAGE_KEY, e.target.value);
    });

    function updateStatsUI() {
        const metricsEl = _('#xan-lines-metrics');
        if (!metricsEl) return;

        const hist = aiState.history;
        const bestScore = hist.length ? Math.max(...hist.map(h => h.score)) : 0;
        const recent10 = hist.slice(-10);
        const avg10 = recent10.length
            ? Math.round(recent10.reduce((sum, h) => sum + h.score, 0) / recent10.length)
            : 0;

        let trendHtml = '<span style="color:#8b949e;">—</span>';
        if (hist.length >= 6) {
            const prevSlice = hist.slice(-10, -5);
            const lastSlice = hist.slice(-5);
            if (prevSlice.length && lastSlice.length) {
                const prevAvg = prevSlice.reduce((s, h) => s + h.score, 0) / prevSlice.length;
                const lastAvg = lastSlice.reduce((s, h) => s + h.score, 0) / lastSlice.length;
                const diff = Math.round(lastAvg - prevAvg);
                if (diff > 0) trendHtml = `<span style="color:#3fb950;">▲ +${diff}</span>`;
                else if (diff < 0) trendHtml = `<span style="color:#f85149;">▼ ${diff}</span>`;
                else trendHtml = `<span style="color:#8b949e;">0</span>`;
            }
        }

        metricsEl.innerHTML = `🧠 Поколение: <b style="color:#c9d1d9;">#${aiState.generation}</b> | Игр: <b style="color:#c9d1d9;">${hist.length}</b> | Рекорд: <b style="color:#3fb950;">${bestScore}</b> | Среднее: <b style="color:#58a6ff;">${avg10}</b> (${trendHtml})`;
    }

    updateStatsUI();

    _('#xan-lines-reset-btn')?.on('click', () => {
        try {
            chrome?.storage?.local?.remove(AI_STATE_KEY);
            localStorage.removeItem(AI_STATE_KEY);
        } catch (e) {}
        aiState = getEmptyAIState();
        updateStatsUI();
        ui.setStatus('Память ИИ сброшена', '#d29922');
    });

    function readStateFromDOM() {
        const board = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
        const hints = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
        const colorCounts = {};
        let occupiedCount = 0;

        for (let idx = 0; idx < 100; idx++) {
            const div = cells[idx].querySelector('div');
            if (!div) continue;

            const tr = (div.style.transform || '').replace(/\s+/g, '');
            if (tr.includes('scale(0)')) continue;

            const posX = parseInt(div.style.backgroundPositionX, 10);
            if (Number.isNaN(posX)) continue;

            const colorId = Math.abs(Math.round(posX / 40));
            if (colorId <= 0) continue;

            const x = idx % SIZE;
            const y = Math.floor(idx / SIZE);

            if (tr.includes('scale(0.4)')) {
                hints[x][y] = colorId;
            } else {
                board[x][y] = colorId;
                colorCounts[colorId] = (colorCounts[colorId] || 0) + 1;
                occupiedCount++;
            }
        }
        return { board, hints, colorCounts, occupiedCount };
    }

    function buildEmptyComponents(board) {
        const compId = Array.from({ length: SIZE }, () => Array(SIZE).fill(-1));
        const compCells = [];

        for (let x = 0; x < SIZE; x++) {
            for (let y = 0; y < SIZE; y++) {
                if (board[x][y] !== 0 || compId[x][y] !== -1) continue;

                const id = compCells.length;
                const list = [{ x, y }];
                compId[x][y] = id;
                let head = 0;

                while (head < list.length) {
                    const cur = list[head++];
                    for (let d = 0; d < 4; d++) {
                        const nx = cur.x + DX_4[d];
                        const ny = cur.y + DY_4[d];
                        if (nx >= 0 && nx < SIZE && ny >= 0 && ny < SIZE && board[nx][ny] === 0 && compId[nx][ny] === -1) {
                            compId[nx][ny] = id;
                            list.push({ x: nx, y: ny });
                        }
                    }
                }
                compCells.push(list);
            }
        }
        return { compId, compCells };
    }
    function scoreCellLines(board, hints, colorCounts, cx, cy, color, w) {
        let clearedBalls = 0;
        let linePotential = 0;
        let activeDirections = 0;

        for (let d = 0; d < 4; d++) {
            const dx = AX_4[d];
            const dy = AY_4[d];

            let chain = 1;
            let fStep = 1;
            while (true) {
                const nx = cx + dx * fStep;
                const ny = cy + dy * fStep;
                if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE || board[nx][ny] !== color) break;
                chain++;
                fStep++;
            }

            let bStep = 1;
            while (true) {
                const nx = cx - dx * bStep;
                const ny = cy - dy * bStep;
                if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE || board[nx][ny] !== color) break;
                chain++;
                bStep++;
            }

            if (chain >= 5) {
                clearedBalls += chain;
                continue;
            }

            let corridor = chain;
            let openEnds = 0;
            let matchingHintsOnEnds = 0;
            let blockingHintsOnEnds = 0;

            let step = fStep;
            while (true) {
                const nx = cx + dx * step;
                const ny = cy + dy * step;
                if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
                if (board[nx][ny] === 0 || board[nx][ny] === color) {
                    if (step === fStep) {
                        openEnds++;
                        if (hints[nx][ny] === color) matchingHintsOnEnds++;
                        else if (hints[nx][ny] !== 0) blockingHintsOnEnds++;
                    }
                    corridor++;
                    step++;
                } else {
                    break;
                }
            }

            step = bStep;
            while (true) {
                const nx = cx - dx * step;
                const ny = cy - dy * step;
                if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) break;
                if (board[nx][ny] === 0 || board[nx][ny] === color) {
                    if (step === bStep) {
                        openEnds++;
                        if (hints[nx][ny] === color) matchingHintsOnEnds++;
                        else if (hints[nx][ny] !== 0) blockingHintsOnEnds++;
                    }
                    corridor++;
                    step++;
                } else {
                    break;
                }
            }

            if (corridor < 5 || openEnds === 0) continue;

            if (chain >= 2) activeDirections++;

            const availableOfColor = (colorCounts[color] || 0);
            const scarcityPenalty = availableOfColor < 5 ? 0.55 : 1.0;

            let base = 0;
            if (chain === 4) base = w.w4;
            else if (chain === 3) base = w.w3;
            else if (chain === 2) base = w.w2;

            const openBonus = openEnds * w.wOpen;
            const hintBonus = matchingHintsOnEnds * w.wHintMatch - blockingHintsOnEnds * w.wHintBlock;
            const roomBonus = Math.min(corridor - 5, 3) * 14;

            linePotential += (base + openBonus + hintBonus + roomBonus) * scarcityPenalty;
        }

        if (activeDirections >= 2) {
            linePotential += w.wFork * (activeDirections - 1);
        }

        return { clearedBalls, linePotential };
    }

    function evaluateMove(board, hints, colorCounts, occupiedCount, fromX, fromY, toX, toY, w) {
        const color = board[fromX][fromY];
        const beforeFrom = scoreCellLines(board, hints, colorCounts, fromX, fromY, color, w);

        board[fromX][fromY] = 0;
        board[toX][toY] = color;
        const afterTo = scoreCellLines(board, hints, colorCounts, toX, toY, color, w);
        board[toX][toY] = 0;
        board[fromX][fromY] = color;

        if (afterTo.clearedBalls >= 5) {
            if (afterTo.clearedBalls >= 6) {
                return 25000 + afterTo.clearedBalls * 2500;
            }
            if (occupiedCount < w.greedThreshold && beforeFrom.linePotential < w.w4) {
                return 8500;
            }
            return 15000;
        }

        let hintDisplaceBonus = 0;
        if (hints[toX][toY] !== 0) {
            hintDisplaceBonus = hints[toX][toY] === color ? -Math.round(w.wHintMatch * 0.45) : w.wDisplace;
        }

        const isEdgeFrom = (fromX === 0 || fromX === 9 || fromY === 0 || fromY === 9);
        const isEdgeTo = (toX === 0 || toX === 9 || toY === 0 || toY === 9);
        const isCornerTo = (toX === 0 || toX === 9) && (toY === 0 || toY === 9);

        const isCenterFrom = (fromX >= 3 && fromX <= 6 && fromY >= 3 && fromY <= 6);
        const isCenterTo = (toX >= 3 && toX <= 6 && toY >= 3 && toY <= 6);

        const edgeDelta = (isEdgeTo ? w.wEdge : 0) + (isCornerTo ? Math.round(w.wEdge * 0.5) : 0) - (isEdgeFrom ? Math.round(w.wEdge * 0.7) : 0);
        const centerMultiplier = occupiedCount > 52 ? 1.8 : 1.0;
        const centerDelta = Math.round(((isCenterFrom ? w.wCenter : 0) - (isCenterTo ? w.wCenter : 0)) * centerMultiplier);

        return (afterTo.linePotential - beforeFrom.linePotential * 0.85) + hintDisplaceBonus + edgeDelta + centerDelta;
    }

    function findBestMove(state, w) {
        const { board, hints, colorCounts, occupiedCount } = state;
        const { compId, compCells } = buildEmptyComponents(board);

        let bestMove = null;
        let bestScore = -Infinity;

        for (let x = 0; x < SIZE; x++) {
            for (let y = 0; y < SIZE; y++) {
                if (board[x][y] === 0) continue;

                const reachableCompIds = new Set();
                for (let d = 0; d < 4; d++) {
                    const nx = x + DX_4[d];
                    const ny = y + DY_4[d];
                    if (nx >= 0 && nx < SIZE && ny >= 0 && ny < SIZE && board[nx][ny] === 0) {
                        reachableCompIds.add(compId[nx][ny]);
                    }
                }

                if (reachableCompIds.size === 0) continue;

                for (const cId of reachableCompIds) {
                    for (const target of compCells[cId]) {
                        const tx = target.x;
                        const ty = target.y;
                        const score = evaluateMove(board, hints, colorCounts, occupiedCount, x, y, tx, ty, w);
                        const jitter = Math.random() * 1.2;
                        if (score + jitter > bestScore) {
                            bestScore = score + jitter;
                            bestMove = {
                                fromX: x,
                                fromY: y,
                                toX: tx,
                                toY: ty,
                                fromIdx: x + y * SIZE,
                                toIdx: tx + ty * SIZE,
                                isLineClear: score >= 8500
                            };
                        }
                    }
                }
            }
        }
        return bestMove;
    }
    function recordGameResult(finalScore, movesCount, playedCandidate) {
        aiState.history.push({
            ts: Date.now(),
            score: finalScore,
            moves: movesCount,
            gen: aiState.generation,
            isCandidate: playedCandidate
        });
        if (aiState.history.length > 40) {
            aiState.history = aiState.history.slice(-40);
        }

        if (playedCandidate) {
            aiState.candidateScores.push(finalScore);
        } else {
            aiState.championScores.push(finalScore);
        }

        if (aiState.championScores.length >= 2 && aiState.candidateScores.length >= 2) {
            const champAvg = aiState.championScores.reduce((a, b) => a + b, 0) / aiState.championScores.length;
            const candAvg = aiState.candidateScores.reduce((a, b) => a + b, 0) / aiState.candidateScores.length;

            if (candAvg > champAvg && aiState.candidateWeights) {
                aiState.bestWeights = { ...aiState.candidateWeights };
                aiState.generation++;
            }
            aiState.championScores = [];
            aiState.candidateScores = [];
            aiState.candidateWeights = mutateWeights(aiState.bestWeights);
        } else if (!aiState.candidateWeights) {
            aiState.candidateWeights = mutateWeights(aiState.bestWeights);
        }

        saveAIState(aiState);
        updateStatsUI();
    }

    function simulateVirtualGame(weights) {
        const board = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
        const hints = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
        let score = 0;

        const calcScore = (n) => (n <= 5 ? 5 : calcScore(n - 1) + (n - 2) * 5);

        const spawnHints = () => {
            const empty = [];
            for (let x = 0; x < SIZE; x++) {
                for (let y = 0; y < SIZE; y++) {
                    if (board[x][y] === 0 && hints[x][y] === 0) empty.push({ x, y });
                }
            }
            for (let i = 0; i < 3 && empty.length > 0; i++) {
                const r = Math.floor(Math.random() * empty.length);
                const cell = empty.splice(r, 1).pop();
                hints[cell.x][cell.y] = Math.floor(Math.random() * 6) + 1;
            }
        };

        const applyHints = () => {
            for (let x = 0; x < SIZE; x++) {
                for (let y = 0; y < SIZE; y++) {
                    if (hints[x][y] !== 0) {
                        const color = hints[x][y];
                        hints[x][y] = 0;
                        if (board[x][y] === 0) {
                            board[x][y] = color;
                        } else {
                            const empty = [];
                            for (let ex = 0; ex < SIZE; ex++) {
                                for (let ey = 0; ey < SIZE; ey++) {
                                    if (board[ex][ey] === 0) empty.push({ x: ex, y: ey });
                                }
                            }
                            if (empty.length > 0) {
                                const rndCell = empty[Math.floor(Math.random() * empty.length)];
                                board[rndCell.x][rndCell.y] = color;
                            }
                        }
                    }
                }
            }
        };

        const clearLines = () => {
            const toClear = new Set();
            for (let x = 0; x < SIZE; x++) {
                for (let y = 0; y < SIZE; y++) {
                    const c = board[x][y];
                    if (c === 0) continue;
                    for (let d = 0; d < 4; d++) {
                        const dx = AX_4[d];
                        const dy = AY_4[d];
                        let cnt = 1;
                        while (x + dx * cnt >= 0 && x + dx * cnt < SIZE && y + dy * cnt >= 0 && y + dy * cnt < SIZE && board[x + dx * cnt][y + dy * cnt] === c) {
                            cnt++;
                        }
                        if (cnt >= 5) {
                            for (let k = 0; k < cnt; k++) {
                                toClear.add(`${x + dx * k}:${y + dy * k}`);
                            }
                        }
                    }
                }
            }
            if (toClear.size > 0) {
                score += calcScore(toClear.size);
                toClear.forEach(key => {
                    const sep = key.indexOf(':');
                    const cx = Number(key.slice(0, sep));
                    const cy = Number(key.slice(sep + 1));
                    board[cx][cy] = 0;
                });
                return true;
            }
            return false;
        };

        spawnHints();
        applyHints();
        spawnHints();

        for (let turn = 0; turn < 140; turn++) {
            const colorCounts = {};
            let occupiedCount = 0;
            for (let x = 0; x < SIZE; x++) {
                for (let y = 0; y < SIZE; y++) {
                    const c = board[x][y];
                    if (c !== 0) {
                        colorCounts[c] = (colorCounts[c] || 0) + 1;
                        occupiedCount++;
                    }
                }
            }
            if (occupiedCount >= 98) break;

            const move = findBestMove({ board, hints, colorCounts, occupiedCount }, weights);
            if (!move) break;

            board[move.toX][move.toY] = board[move.fromX][move.fromY];
            board[move.fromX][move.fromY] = 0;

            if (!clearLines()) {
                applyHints();
                clearLines();
                spawnHints();
            }
        }
        return score;
    }
    _('#xan-lines-train-btn')?.on('click', async () => {
        if (isRunning) return;
        const trainBtn = _('#xan-lines-train-btn');
        if (trainBtn) trainBtn.disabled = true;
        ui.setStatus('Офлайн-тренировка ИИ (40 игр)...', '#58a6ff');

        await sleep(30);
        let improvedCount = 0;

        for (let round = 0; round < 10; round++) {
            const candidate = mutateWeights(aiState.bestWeights);
            let champSum = 0;
            let candSum = 0;

            for (let g = 0; g < 2; g++) {
                champSum += simulateVirtualGame(aiState.bestWeights);
                candSum += simulateVirtualGame(candidate);
            }

            if (candSum > champSum) {
                aiState.bestWeights = candidate;
                aiState.generation++;
                improvedCount++;
            }
            if (round % 3 === 0) await sleep(10);
        }

        aiState.candidateWeights = mutateWeights(aiState.bestWeights);
        saveAIState(aiState);
        updateStatsUI();

        if (trainBtn) trainBtn.disabled = false;
        ui.setStatus(`Обучение завершено! Улучшений: +${improvedCount} (Поколение #${aiState.generation})`, '#3fb950');
    });

    function getBoardSignature() {
        let sig = '';
        for (let i = 0; i < 100; i++) {
            const div = cells[i].firstElementChild;
            if (!div) sig += '0;';
            else sig += `${div.style.backgroundPositionX}:${div.style.transform};`;
        }
        return sig;
    }

    async function startLinesSolving() {
        if (isRunning || isMinigameOver()) return;
        isRunning = true;
        stopRequested = false;
        ui.setRunningUI(true);

        const playCandidate = Boolean(aiState.candidateWeights && aiState.championScores.length >= 2);
        const activeWeights = playCandidate ? aiState.candidateWeights : aiState.bestWeights;
        const profileLabel = playCandidate ? `Кандидат #${aiState.generation}` : `Чемпион #${aiState.generation}`;

        ui.setStatus(`Играем (${profileLabel})...`, '#58a6ff');
        let movesCount = 0;

        try {
            while (!stopRequested && !isMinigameOver()) {
                const state = readStateFromDOM();
                const move = findBestMove(state, activeWeights);

                if (!move) {
                    ui.setStatus('Нет доступных ходов', '#d29922');
                    break;
                }

                const beforeSig = getBoardSignature();
                const speedKey = _('#xan-lines-speed')?.value || localStorage.getItem(SPEED_STORAGE_KEY) || 'normal';
                const sp = SPEED_PROFILES[speedKey] || SPEED_PROFILES.normal;

                cells[move.fromIdx].click();
                await sleep(getRandomInt(sp.clickMin, sp.clickMax));

                if (stopRequested || isMinigameOver()) break;

                cells[move.toIdx].click();
                movesCount++;

                const currentPoints = (_('#score')?.textContent || '0').trim();
                ui.setStatus(`Ход #${movesCount} | Очков: ${currentPoints} (${profileLabel})`, move.isLineClear ? '#3fb950' : '#58a6ff');

                const waitStart = Date.now();
                while (Date.now() - waitStart < 3000) {
                    if (stopRequested || isMinigameOver()) break;
                    if (getBoardSignature() !== beforeSig) break;
                    await sleep(40);
                }

                const thinkDelay = movesCount % getRandomInt(6, 9) === 0
                    ? getRandomInt(sp.longMin, sp.longMax)
                    : getRandomInt(sp.thinkMin, sp.thinkMax);
                await sleep(thinkDelay);
            }

            const finalPoints = parseInt((_('#score')?.textContent || '0').trim(), 10) || 0;

            if (stopRequested) {
                ui.setStatus(`Остановлено | Очков: ${finalPoints}`, '#d29922');
            } else {
                if (movesCount > 0) {
                    recordGameResult(finalPoints, movesCount, playCandidate);
                }
                ui.setStatus(`Финиш! Очков: ${finalPoints} (${profileLabel})`, '#3fb950');
            }
        } finally {
            isRunning = false;
            ui.setRunningUI(false);
        }
    }
}
