// js/main.js — Полная безопасная версия с защитой от инвалидации контекста

// === ИМПОРТЫ СИСТЕМНЫХ УТИЛИТ И МОДУЛЯ МЕНЮ ===
import { CURRENT_PAGE, CURRENT_UNIVERSE, isScriptActive } from './utils.js';
import { _ } from './query.js';
// ВНЕДРЕНО: Импортируем нашу единую фабрику навигации
import { initCustomMenu } from './menu.js';

console.log(`[Game Guard] Скрипт успешно запущен во вселенной: ${CURRENT_UNIVERSE}`);

// Функция проверки валидности контекста расширения
function isContextValid() {
    return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;
}

// Вспомогательный безопасный импортер модулей
async function safeImport(path) {
    if (!isContextValid()) {
        console.warn(`[Game Guard] Импорт модуля '${path}' отменен: контекст расширения недействителен (возможно, было обновление).`);
        return null;
    }
    try {
        const url = chrome.runtime.getURL(path);
        return await import(url);
    } catch (err) {
        if (err.message && err.message.includes("Extension context invalidated")) {
            console.log(`[Game Guard] Контекст потерян во время загрузки модуля: ${path}`);
            return null;
        }
        throw err; // Пробрасываем реальные синтаксические или сетевые ошибки кода
    }
}

// === ОБЩАЯ ЛОГИКА ДЛЯ ВСЕХ СТРАНИЦ ===

// 1. Очистка интерфейса от мусорных ссылок донатов
const DONATE_LINKS = _('[href*="donate.php"]', true);
if (DONATE_LINKS.length > 0) {
    DONATE_LINKS.forEach(link => {
        if (!link.closest('.quids')) {
            link.href = '#null';
        }
    });
}

// 2. Выделение лун в селекторе выбора планет
const PLANET_SELECT = _('select');
if (PLANET_SELECT && PLANET_SELECT.options) {
    Array.from(PLANET_SELECT.options).forEach(option => {
        option.style.fontWeight = 'bold';
        if (option.textContent.includes('*')) {
            option.style.color = 'lightsteelblue'; // Луна
        } else {
            option.style.color = 'wheat'; // Планета
        }
    });
}

// Применение общих кастомных классов расширения XAN
function applyGlobalStyles() {
    const elements = _('input, select', true);
    elements.forEach(elem => {
        if (!elem.classList.contains('xan-custom-input-select')) {
            elem.classList.add('xan-custom-input-select');
        }
    });
}
applyGlobalStyles();

_('#times')
  ?.replaceCls('username', 'times')
  .closestAddCls('div', 'times-container');

// ВНЕДРЕНО: Centralized запуск кастомного меню XAN для абсолютно любой страницы игры!
// Скрипт ищет главную таблицу игры 'table' и монтирует туда навигацию.
initCustomMenu('table');

// === РАЗДЕЛЕНИЕ ЛОГИКИ ПО СТРАНИЦАМ ИГРЫ ===
switch (CURRENT_PAGE) {

    // ==========================================
    // БЕЗУСЛОВНОЕ ЯДРО (Работает всегда)
    // ==========================================
    case 'overview':
        console.log("[Game Guard] Активирован модуль 'Обзор'. Запуск цепочки скриптов...");
        Promise.all([
            safeImport('js/overview_ui.js'),
            safeImport('js/overview_defense.js'),
            safeImport('js/overview_stealth.js'),
            safeImport('js/event_harvester.js') // ВНЕДРЕНО: Безопасный импорт Тыквенного Комбайна
        ]).then(([uiModule, defenseModule, stealthModule, harvesterModule]) => {
            // Если хотя бы один модуль вернул null из-за инвалидации — не инициализируем
            if (!uiModule || !defenseModule || !stealthModule || !harvesterModule) return;
            
            uiModule.initOverviewUI();
            defenseModule.checkEnemyAttack();
            stealthModule.initStealthNavigation();
            harvesterModule.initEventHarvester(); // ВНЕДРЕНО: Безопасный пуск Комбайна на Обзоре
        }).catch(err => {
            console.error("[Game Guard] Критическая ошибка при инициализации модулей Обзора:", err);
        });
        break;

    // ==========================================
    // КАСКАД СТРАНИЦ С ПРОВЕРКОЙ АКТИВНОСТИ (По алфавиту)
    // ==========================================
    case 'buildings':
        if (isScriptActive('buildings')) {
            console.log("[Game Guard] Скрипт 'buildings' включен. Запуск модуля...");
            safeImport('js/buildings.js').then(module => {
                if (module) module.initBuildingsPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Сооружения:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Сооружения' отключен в настройках XAN.");
        }
        break;

    case 'fleet':
    case 'floten1':
    case 'floten2':
        if (isScriptActive('fleet')) {
            console.log("[Game Guard] Скрипт 'fleet' включен. Запуск модуля...");
            safeImport('js/fleet.js').then(module => {
                if (module) module.initFleetModule(CURRENT_PAGE);
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Флот:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Флот' отключен в настройках XAN.");
        }
        break;

    case 'galaxy':
        if (isScriptActive('galaxy')) {
            console.log("[XAN Galaxy] Модуль 'galaxy' включен. Запуск инициализации...");
            safeImport('js/galaxy.js').then(module => {
                if (module) module.initGalaxyModule();
            }).catch(err => {
                console.error("[XAN Galaxy] Критическая ошибка загрузки модуля Галактики:", err);
            });
        } else {
            console.log("[XAN Galaxy] Модуль 'Галактика' отключен пользователем в настройках XAN.");
        }
        break;
	
	case 'game':
        if (isScriptActive('mini_games')) {
            console.log("[Game Guard] Скрипт 'mini_games' включен. Запуск модуля...");
            safeImport('js/mini_games.js').then(module => {
                if (module) module.initMinigamesPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Мини-игры:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Мини-игры' отключен в настройках XAN.");
        }
        break;

    case 'imperium':
        if (isScriptActive('imperium')) {
            console.log("[Game Guard] Скрипт 'imperium' включен. Запуск модуля...");
            safeImport('js/imperium.js').then(module => {
                if (module) module.initImperiumPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Империя:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Империя' отключен в настройках XAN.");
        }
        break;
	
	case 'messages':
        if (isScriptActive('messages')) {
            console.log("[Game Guard] Скрипт 'messages' включен. Запуск модуля...");
            safeImport('js/messages.js').then(module => {
                if (module) module.initMessagesPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Сообщения:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Сообщения' отключен в настройках XAN.");
        }
        break;
	
    case 'notes':
        if (isScriptActive('notes')) {
            console.log("[Game Guard] Скрипт 'notes' включен. Запуск модуля...");
            safeImport('js/notes.js').then(module => {
                if (module) module.initNotesPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Заметки:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Заметки' отключен in настройках XAN.");
        }
        break;
	
    case 'phalanx':
        if (isScriptActive('phalanx')) {
            console.log("[Game Guard] Скрипт 'phalanx' включен. Запуск модуля...");
            safeImport('js/phalanx.js').then(module => {
                if (module) module.initPhalanxPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Фаланга:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Фаланга' отключен в настройках XAN.");
        }
        break;
	
	case 'questions':
        if (isScriptActive('questions')) {
            console.log("[Game Guard] Скрипт 'questions' включен. Запуск модуля...");
            safeImport('js/questions.js').then(module => {
                if (module) module.initQuestionsPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Вопросы:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Вопросы' отключен в настройках XAN.");
        }
        break;

    case 'user':
        if (isScriptActive('user')) {
            console.log("[Game Guard] Скрипт 'user' включен. Запуск модуля...");
            safeImport('js/user.js').then(module => {
                if (module) module.initUserPage();
            }).catch(err => {
                console.error("[Game Guard] Ошибка загрузки модуля Профиль:", err);
            });
        } else {
            console.log("[Game Guard] Модуль 'Профиль' отключен в настройках XAN.");
        }
        break;			
}
