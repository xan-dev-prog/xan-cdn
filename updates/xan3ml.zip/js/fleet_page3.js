// js/fleet_page3.js — Подмодуль для третьей страницы флота (Отправка флота)
// ЧАСТЬ 1 ИЗ 3

import { _ } from './query.js';
import { spaces, nsn } from './utils.js';

export function initPage3() {
    // 1. Кастомизация текстовых полей ввода и кнопок отправки (через глобальный класс)
    _('[type="text"], [type="submit"]', true)?.addCls('xan-custom-input-select');

    // 2. Находим все ячейки td, внутри которых лежат текстовые инпуты, меняем класс фонов
    _('td:has([type="text"])', true)
        ?.removeCls('c')
        ?.addCls('xan-input-bg-container');

    // 3. Модернизация кнопки отправки флота и инжекция перезагрузки [♻]
    const submitBtn = _('#submit') || _('[value="[ Отправить ]"]') || _('[type="submit"]');
    const submitTd = submitBtn?.closest('td');
    const cntDwnTh = submitBtn?.closest('tr').previousElementSibling.querySelector('th');
    const hlpTh = _('tr[style="display: none"]')?.previousElementSibling.querySelector('th');

    if (submitTd && !submitTd.querySelector('.xan-submit-flex-wrapper')) {
        if (submitBtn) {
            submitBtn.value = t('f3_submit_val');
        }

        const wrapper = document.createElement('div');
        wrapper.classList.add('xan-submit-flex-wrapper');

        submitTd.insertBefore(wrapper, submitBtn);
        wrapper.insertAdjacentHTML('afterbegin', `<input type="button" id="rfr" title="${t('f3_refresh_title')}" value="[♻]">`);
        wrapper.appendChild(submitBtn);

        submitTd.classList.add('xan-submit-td-cell');
        
        _('#rfr')?.addCls('xan-btn-refresh')
                 ?.on('click', () => location.reload());
    }

    /* В ЭЛЕМЕНТЕ cntDwnTh СОБИРАЕМ ТАЙМЕР И УПРАВЛЕНИЕ ИМ */
    if (cntDwnTh) {
        initDelayedStartTimer(cntDwnTh, submitBtn);
    }

    /* В ЭЛЕМЕНТЕ hlpTh ИНЖЕКТИРУЕМ УМНЫЙ ГАЙД ПОД СПОЙЛЕРОМ */
    if (hlpTh) {
        initFleetPage3Help(hlpTh);
    }

    // 4. Автоматический клик по миссии "Оставить" / "Залишити" (мультиязычная поддержка)
    try {
        const labels = document.querySelectorAll('label');
        const leaveLabel = Array.from(labels).find(el => 
            el.textContent.includes('Оставить') || el.textContent.includes('Залишити')
        );
        if (leaveLabel) leaveLabel.click();
    } catch (e) {
        console.error("XAN: Ошибка автовыбора миссии", e);
    }

    // 5. Логика удержания ресурсов на Луне
    if (_('[selected="selected"]')?.innerText.includes('*')) {
        initMoonLeaveResources(submitBtn);
    }
}
// js/fleet_page3.js — Подмодуль для третьей страницы флота (Отправка флота)
// ЧАСТЬ 2 ИЗ 3

/**
 * Умная система автоматического отложенного старта флота по времени прибытия (со спойлером)
 */
function initDelayedStartTimer(container, submitBtn) {
    const savedPing = Number(localStorage.getItem('xan3_delayed_ping_ms')) || 0;
    const savedTarget = localStorage.getItem('xan3_delayed_target_time');
    
    const isSavedOpened = localStorage.getItem('xan3_timer_opened') === '1' || savedTarget;

    let pingOptions = '';
    for (let ms = 0; ms <= 1500; ms += 100) {
        const selected = ms === savedPing ? 'selected' : '';
        pingOptions += `<option value="${ms}" ${selected}>-${ms} мс</option>`;
    }

    container.classList.add('xan-timer-th-container');

    const isOpenedClass = isSavedOpened ? 'open' : '';
    const toggleChar = isSavedOpened ? '−' : '+';

    container.innerHTML = `
        <div id="xan_timer_toggle" class="xan-timer-circle-toggle" title="Открыть/скрыть таймер старта">${toggleChar}</div>
        <div id="xan_timer_content_wrapper" class="xan-timer-animate-wrapper ${isOpenedClass}">
            <div class="xan-timer-inner-body">
                <div class="xan-timer-title-lbl">${t('f3_timer_title')}</div>
                <div class="xan-timer-row-controls">
                    <button type="button" id="xan_delayed_start" class="xan-custom-input-select xan-timer-btn-act">${t('f3_timer_start')}</button>
                    <input type="text" id="xan_delayed_time" placeholder="ЧЧ:ММ:СС" class="xan-timer-input-time" maxlength="8" />
                    <select id="xan_delayed_ping" class="xan-custom-input-select xan-timer-select-ping">
                        ${pingOptions}
                    </select>
                    <button type="button" id="xan_delayed_reset" class="xan-custom-input-select xan-timer-btn-act xan-salmon-color">${t('f3_timer_reset')}</button>
                </div>
                <div id="xan_delayed_status" class="xan-timer-status-div"></div>
            </div>
        </div>
    `;

    const toggleBtn = document.getElementById('xan_timer_toggle');
    const contentWrapper = document.getElementById('xan_timer_content_wrapper');
    const timeInput = document.getElementById('xan_delayed_time');
    const pingSelect = document.getElementById('xan_delayed_ping');
    const startBtn = document.getElementById('xan_delayed_start');
    const resetBtn = document.getElementById('xan_delayed_reset');
    const statusDiv = document.getElementById('xan_delayed_status');

    // ХИРУРГИЧЕСКАЯ УТИЛИТА: Умная маска ввода ЧЧ:ММ:СС с защитой от копипаста
    timeInput.addEventListener('input', function(e) {
        // Если это копипаст (вставка), полностью игнорируем маску и ничего не форматируем
        if (e.inputType === 'insertFromPaste') return;

        let val = this.value.replace(/[^0-9]/g, ''); // Разрешаем только цифры для ручного ввода
        let formatted = '';

        if (val.length > 0) {
            formatted += val.substring(0, 2);
        }
        if (val.length > 2) {
            formatted += ':' + val.substring(2, 4);
        }
        if (val.length > 4) {
            formatted += ':' + val.substring(4, 6);
        }

        this.value = formatted;
    });

    toggleBtn.addEventListener('click', () => {
        if (contentWrapper.classList.contains('open')) {
            contentWrapper.classList.remove('open');
            toggleBtn.textContent = '+';
            localStorage.setItem('xan3_timer_opened', '0');
        } else {
            contentWrapper.classList.add('open');
            toggleBtn.textContent = '−';
            localStorage.setItem('xan3_timer_opened', '1');
        }
    });

    pingSelect.addEventListener('change', () => {
        localStorage.setItem('xan3_delayed_ping_ms', pingSelect.value);
    });

    if (savedTarget) {
        timeInput.value = savedTarget;
        statusDiv.innerHTML = t('f3_timer_status_wait').replace('{time}', savedTarget);
    }

    startBtn.addEventListener('click', () => {
        const timeVal = timeInput.value.trim();
        if (!/^([0-1]?\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(timeVal)) {
            statusDiv.innerHTML = t('f3_timer_status_err');
            return;
        }
        localStorage.setItem('xan3_delayed_target_time', timeVal);
        statusDiv.innerHTML = t('f3_timer_status_run').replace('{time}', timeVal);
        setTimeout(() => location.reload(), 500);
    });

    resetBtn.addEventListener('click', () => {
        localStorage.removeItem('xan3_delayed_target_time');
        timeInput.value = '';
        statusDiv.innerHTML = t('f3_timer_status_reset');
    });

    if (!savedTarget) return;

    const timerInterval = setInterval(() => {
        const dateFleetEl = document.getElementById('date_fleet1');
        if (!dateFleetEl) return;

        const currentStr = dateFleetEl.textContent.trim();
        const matches = currentStr.match(/(\d{2}):(\d{2}):(\d{2})/);
        if (!matches) return;

        const currentSeconds = (parseInt(matches[1], 10) * 3600) + (parseInt(matches[2], 10) * 60) + parseInt(matches[3], 10);
        
        const targetParts = savedTarget.split(':');
        const targetSeconds = (parseInt(targetParts[0], 10) * 3600) + (parseInt(targetParts[1], 10) * 60) + parseInt(targetParts[2], 10);

        let diff = targetSeconds - currentSeconds;
        if (diff < 0) diff += 86400; 

        if (diff <= 0) {
            clearInterval(timerInterval);
            localStorage.removeItem('xan3_delayed_target_time');
            statusDiv.innerHTML = t('f3_timer_status_go');
            if (submitBtn) submitBtn.click();
            return;
        }

        if (diff <= 20) {
            clearInterval(timerInterval);
            statusDiv.innerHTML = t('f3_timer_status_boost').replace('{num}', diff);
            
            const fastTimer = setInterval(() => {
                const innerDateFleet = document.getElementById('date_fleet1');
                if (!innerDateFleet) return;
                
                const innerMatches = innerDateFleet.textContent.trim().match(/(\d{2}):(\d{2}):(\d{2})/);
                if (!innerMatches) return;
                
                const curSec = (parseInt(innerMatches[1], 10) * 3600) + (parseInt(innerMatches[2], 10) * 60) + parseInt(innerMatches[3], 10);
                let currentDiff = targetSeconds - curSec;
                if (currentDiff < 0) currentDiff += 86400;

                if (currentDiff <= 1) {
                    clearInterval(fastTimer);
                    localStorage.removeItem('xan3_delayed_target_time');
                    
                    const userPingMs = Number(localStorage.getItem('xan3_delayed_ping_ms')) || 0;
                    const delayTime = Math.max(0, 1000 - userPingMs);
                    
                    statusDiv.innerHTML = t('f3_timer_status_pre').replace('{num}', userPingMs);
                    setTimeout(() => {
                        if (submitBtn) submitBtn.click();
                    }, delayTime);
                } else {
                    statusDiv.innerHTML = t('f3_timer_status_fine').replace('{num}', currentDiff);
                    const rfrBtn = document.getElementById('rfr');
                    if (rfrBtn) rfrBtn.click();
                }
            }, 1000);
            
        } else {
            statusDiv.innerHTML = `⏳ Ожидание... Осталось примерно ${Math.floor(diff / 60)} мин`;
        }
    }, 1000);

    if (savedTarget && !window.xanDelayedReloadSetup) {
        window.xanDelayedReloadSetup = true;
        setTimeout(() => {
            const currentTarget = localStorage.getItem('xan3_delayed_target_time');
            if (currentTarget) location.reload();
        }, 60000);
    }
}

// js/fleet_page3.js — Подмодуль для третьей страницы флота (Отправка флота)
// ЧАСТЬ 3 ИЗ 3

/**
 * Инициализация интерактивного гайда по функциям 3-й страницы флота
 */
function initFleetPage3Help(container) {
    container.classList.add('xan-help-th-container');
    
    container.innerHTML = `
        <div id="xan_guide_toggle" class="xan-guide-circle-toggle" title="Открыть руководство пользователя">?</div>
        <div id="xan_guide_content_wrapper" class="xan-guide-animate-wrapper">
            <div class="xan-guide-inner-body">
                <div class="xan-guide-header-title">${t('f3_guide_title')}</div>
                
                <div class="xan-guide-section">
                    <span class="xan-guide-tag">${t('f3_guide_s1_tag')}</span> 
                    ${t('f3_guide_s1_desc')}
                </div>

                <div class="xan-guide-section">
                    <span class="xan-guide-tag">${t('f3_guide_s2_tag')}</span> 
                    ${t('f3_guide_s2_desc')}
                </div>

                <div class="xan-guide-section">
                    <span class="xan-guide-tag">${t('f3_guide_s3_tag')}</span> 
                    ${t('f3_guide_s3_desc')}
                </div>

                <div class="xan-guide-section">
                    <span class="xan-guide-tag">${t('f3_guide_s4_tag')}</span> 
                    ${t('f3_guide_s4_desc')}
                </div>
            </div>
        </div>
    `;

    const guideToggle = document.getElementById('xan_guide_toggle');
    const guideWrapper = document.getElementById('xan_guide_content_wrapper');

    guideToggle.addEventListener('click', () => {
        if (guideWrapper.classList.contains('open')) {
            guideWrapper.classList.remove('open');
            guideToggle.style.borderColor = '#00ffff';
            guideToggle.style.color = '#00ffff';
        } else {
            guideWrapper.classList.add('open');
            guideToggle.style.borderColor = '#ffcc00';
            guideToggle.style.color = '#ffcc00';
        }
    });
}

/**
 * Логика удержания ресурсов на Луне (Ctrl+Клик)
 */
function initMoonLeaveResources(submitBtn) {
    // ПРАВИЛО ВЫСШЕГО ПРИОРИТЕТА v3.0: Изолированный префикс xan3_
    const leave = [
        Number(localStorage.xan3_leaveM) || 0, 
        Number(localStorage.xan3_leaveA) || 0, 
        Number(localStorage.xan3_leaveU) || 0
    ];

    const _M = _('[onclick="maxResource(\'1\');"]')?.closest('tr')?.querySelector('th');
    const _A = _('[onclick="maxResource(\'2\');"]')?.closest('tr')?.querySelector('th');
    const _U = _('[onclick="maxResource(\'3\');"]')?.closest('tr')?.querySelector('th');

    [_M, _A, _U].forEach((cell, i) => {
        if (!cell || cell.querySelector(`#res_${i + 1}`)) return;
        
        cell.classList.add('xan-resource-th-left');
        const isChecked = leave[i] !== 0 ? 'checked' : '';
        const titleText = t('f3_checkbox_title').replace('{num}', spaces(leave[i]));
        
        cell.insertAdjacentHTML('beforeend', 
            `<input ${isChecked} value="${leave[i]}" title="${titleText}" type="checkbox" id="res_${i + 1}" class="xan-leave-checkbox" />`
        );
    });

    const checkboxes = document.querySelectorAll('[type="checkbox"][id^="res_"]');
    checkboxes.forEach(checkbox => {
        if (checkbox.dataset.xanCtrlAttached) return;
        checkbox.dataset.xanCtrlAttached = 'true';

        checkbox.addEventListener('click', function(e) {
            if (!e.ctrlKey) return;
            e.preventDefault();
            _('#tip')?.remove();

            const idx = Number(this.id.replace('res_', '')) - 1;
            const resNames = [t('f3_metal'), t('f3_crystal'), t('f3_uran')];
            const storageKeys = ['M', 'A', 'U'];

            const tipTitle = t('f3_tip_title').replace('{res}', resNames[idx]);

            document.body.insertAdjacentHTML('beforeend', `
                <div id="tip" class="xan-tooltip-panel">
                    <span id="close_tip" class="xan-tooltip-close">✖</span>
                    <h4 align="center">${tipTitle}</h4>
                    <input type="text" value="${leave[idx]}" id="xan3_leave${storageKeys[idx]}" class="xan-custom-input-select" style="text-align:center;" />
                </div>
            `);

            const tipEl = _('#tip');
            if (tipEl) {
                tipEl.style.top = `${e.pageY + 10}px`;
                tipEl.style.left = `${e.pageX + 10}px`;
            }

            const tipInput = document.querySelector('#tip input');
            tipInput?.addEventListener('change', function(evt) {
                const trg = evt.target;
                const val = trg.value.trim();
                if (!val || Number(val) === 0) {
                    localStorage.removeItem(trg.id);
                } else {
                    localStorage.setItem(trg.id, val);
                }
                setTimeout(() => location.reload(), 500);
            });

            const closeBtn = document.querySelector('#close_tip');
            closeBtn?.addEventListener('click', () => _('#tip')?.remove());
        });
    });

    if (submitBtn && !submitBtn.dataset.handlerAttached) {
        submitBtn.dataset.handlerAttached = 'true';
        let reduced = 0;

        submitBtn.addEventListener('mouseover', () => {
            if (reduced !== 0) return;
            
            const resInputs = document.querySelectorAll('[name^=resource]');
            resInputs.forEach(resInput => {
                const currentVal = nsn(resInput.value);
                const checkbox = resInput.closest('tr')?.querySelector('[type="checkbox"]');
                const leaveLimit = checkbox ? Number(checkbox.value) : 0;

                if (checkbox && checkbox.checked && currentVal > leaveLimit) {
                    resInput.value = spaces(currentVal - leaveLimit);
                    reduced++;
                }
            });
        });
    }
}
