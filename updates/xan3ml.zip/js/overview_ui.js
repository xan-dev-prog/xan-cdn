import { _ } from './query.js';
import { MENU_LINKS, MENU_ALLOWED_PAGES, WARNINGS, MELODIES, AVAILABLE_SCRIPTS } from './game_data.js';
import { isScriptActive } from './utils.js'; 

export function initOverviewUI() {
    console.log("[Game Guard] Инициализация интерфейса Обзора...");
	const isStealthActive = localStorage.getItem('xan3_stealth_active') !== '0'; // true по дефолту
	const isSirenActive = localStorage.getItem('xan3_siren_active') !== '0';     // <-- НАША НОВАЯ ПЕРЕМЕННАЯ (true по дефолту)
	// --- ВОТ ЭТИ ДВЕ СТРОКИ ДОЛЖНЫ СТОЯТЬ ЗДЕСЬ РЯДОМ ---
    const pumpMaxSlots = parseInt(localStorage.xan3_pump_max_slots, 10) || 22; // Твой максимум (например, 22)
    const pumpReserved = parseInt(localStorage.xan3_pump_reserved, 10) || 5;  // Твой резерв (например, 2)
    // ----------------------------------------------------
    const melody = localStorage.xan3_melody || '1.mp3';
    const lsFrom = parseInt(localStorage.xan3_intfrom, 10) || 15;
    const lsTo = parseInt(localStorage.xan3_intto, 10) || 45;
    const menuViewMode = localStorage.xan3_menu_view_mode || 'text';
    const menuPagesStr = localStorage.xan3_menu_pages || '';
    const menuPages = menuPagesStr ? menuPagesStr.split(';') : [];

    const userFormedMenu = localStorage.xan3_UserFormedMenu 
        ? localStorage.xan3_UserFormedMenu.split(';').map(Number) 
        : [];

    const availableScripts = AVAILABLE_SCRIPTS;
    const mainTable = _('table');
    if (!mainTable) return;

    const planetSelect = _('.menu-item');
    let planetParams = '';
    if (planetSelect) {
        const selectedValue = planetSelect.value || '';
        if (selectedValue.includes('&')) {
            planetParams = selectedValue.substring(selectedValue.indexOf('&'));
        }
    }
    const row = mainTable.insertRow(0);
    const isPumpActive = localStorage.getItem('xan3_pump_active') !== '0';
    const btnText = isPumpActive ? t('ui_pump_btn_stop') : t('ui_pump_btn_start');

    row.insertAdjacentHTML('beforebegin', `
        <tr>
            <th colspan="11" class="c" id="menu-holder">
                <div id="attack-notifier" class="gg-attack-box">
                    <b class="gg-attack-title">${t('ui_attack_title')}</b><br /><br />
                    <button id="ntfbtn">${t('ui_btn_close')}</button>
                </div>
                <!-- Обновленный инфо-бар статуса с интерактивной кнопкой управления -->
                <div id="xan-pump-status-bar" style="display: none; padding: 6px 10px; margin: 5px auto 10px auto; border: 1px solid #344566; background: #1b2838; border-radius: 4px; font-size: 11px; text-align: left; width: 95%;">
                    <button id="xan-pump-toggle-btn" style="float: right; cursor: pointer; padding: 1px 6px; font-size: 10px; background: #2a3f5a; color: #fff; border: 1px solid #4a658a; border-radius: 3px; margin-top: -2px;">
                        ${btnText}
                    </button>
                    <b style="color: #ff6600;">🎃 ${t('ui_pump_status_lbl')}</b> 
                    <span id="xan-pump-status-text" style="color: #fff; margin-left: 5px;">-</span>
                </div>
            </th>
        </tr>
    `);



    const descText = t('ui_descr').replace('{from}', lsFrom).replace('{to}', lsTo);
	
	const isHarvesterEnabled = isScriptActive('harvester');
    //const pumpSlots = localStorage.xan3_pump_slots || 3;
    const pumpCoords = localStorage.xan3_pump_coords || '';
    const pumpCount = localStorage.xan3_pump_count || 1;
    const pumpMode = localStorage.xan3_pump_mode || 'target';

        const harvesterSettingsHtml = isHarvesterEnabled ? `
        <div id="xan-pump-container" style="border: 1px dashed #ffcc00; padding: 15px; margin: 15px 0; background: rgba(255, 102, 0, 0.05); border-radius: 4px;">
            <h2 class="gg-settings-title" style="color: #ff6600 !important; margin-top:0;">
                ${t('ui_pump_title')}
                <div id="xanPumpHelpBtn" style="display: inline-block; margin-left: 10px; cursor: pointer; color: #6495ED; font-weight: bold; font-size: 13px; padding: 0 4px;" title="${t('ui_pump_help_title')}">[ ? ]</div>
            </h2>
            
            <div style="margin-bottom: 12px;">
                <span style="color: orange; font-weight: bold; margin-right: 15px;">${t('ui_pump_mode')}</span>
                <label style="cursor:pointer; margin-right: 15px;">
                    <input type="radio" name="xan_pump_mode" value="target" ${pumpMode === 'target' ? 'checked' : ''} /> ${t('ui_pump_mode_fixed')}
                </label>
                <label style="cursor:pointer;">
                    <input type="radio" name="xan_pump_mode" value="system" ${pumpMode === 'system' ? 'checked' : ''} /> ${t('ui_pump_mode_sys')}
                </label>
            </div>
			<label style="display:block; margin-bottom: 10px;">
				${t('ui_pump_max_slots')} 
				<input type="number" id="xan-pump-max-slots" value="${pumpMaxSlots}" min="1" max="100" style="width: 50px; background:#1b2838; color:#fff; border:1px solid #344566; padding:2px; text-align:center;" />
			</label>
			<label style="display:block; margin-bottom: 10px;">
                ${t('ui_pump_slots')} 
                <input type="number" id="xan-pump-reserved" value="${pumpReserved}" min="0" max="50" style="width: 50px; background:#1b2838; color:#fff; border:1px solid #344566; padding:2px; text-align:center;" />
            </label>
            
            <label id="xan-pump-coords-row" style="display:${pumpMode === 'target' ? 'block' : 'none'}; margin-bottom: 10px;">
                ${t('ui_pump_target')} 
                <input type="text" id="xan-pump-coords" value="${pumpCoords}" placeholder="1:234:5" style="width: 90px; background:#1b2838; color:#fff; border:1px solid #344566; padding:2px; text-align:center;" />
            </label>
            
            <label style="display:block; margin-bottom: 5px;">
                ${t('ui_pump_count')} 
                <input type="number" id="xan-pump-count" value="${pumpCount}" min="1" style="width: 50px; background:#1b2838; color:#fff; border:1px solid #344566; padding:2px; text-align:center;" />
            </label>

            <!-- Полная копия красивого дизайна инструкции из модуля сообщений -->
            <div id="xan-pump-help-guide" style="display: none; background: #15171e; border: 1px solid #34495e; border-radius: 5px; padding: 15px; margin-top: 15px; text-align: left; color: #e0e0e0; font-family: sans-serif; font-size: 11px; line-height: 1.5;">
                <h3 style="margin-top:0; color: #6495ED; border-bottom: 1px solid #34495e; padding-bottom: 5px; font-size: 13px;">📖 ${t('ui_pump_help_guide_hdr')}</h3>
                
                <p style="color: #4db8ff; font-weight: bold; margin: 10px 0 5px 0;">📊 ${t('ui_pump_help_cat_slots')}:</p>
                <ul style="margin: 0; padding-left: 20px; list-style-type: square;">
                    <li style="margin-bottom: 4px;"><b>${t('ui_pump_help_step1_title')}:</b> ${t('ui_pump_help_step1_desc')}</li>
                    <li style="margin-bottom: 4px;"><b>${t('ui_pump_help_step2_title')}:</b> ${t('ui_pump_help_step2_desc')}</li>
                </ul>

                <p style="color: #ff944d; font-weight: bold; margin: 12px 0 5px 0;">🚀 ${t('ui_pump_help_cat_target')}:</p>
                <ul style="margin: 0; padding-left: 20px; list-style-type: square;">
                    <li style="margin-bottom: 4px;"><b>${t('ui_pump_help_step3_title')}:</b> ${t('ui_pump_help_step3_desc')}</li>
                    <li style="margin-bottom: 4px;"><b>${t('ui_pump_help_step4_title')}:</b> ${t('ui_pump_help_step4_desc')}</li>
                </ul>

                <p style="color: #cc66ff; font-weight: bold; margin: 12px 0 5px 0;">🛡️ ${t('ui_pump_help_cat_stealth')}:</p>
                <ul style="margin: 0; padding-left: 20px; list-style-type: square;">
                    <li style="margin-bottom: 0; color: #ff4d4d;"><b>${t('ui_pump_help_step5_title')}:</b> ${t('ui_pump_help_step5_desc')}</li>
                </ul>
            </div>
        </div>
    ` : '';

    const menuContainer = _('#menu-holder');
    menuContainer.insertAdjacentHTML('beforeend', `
        <div id="xan-settings" class="gg-settings-panel">
            <form id="userdata" onsubmit="return false;">
                <h2 class="gg-settings-title">${t('ui_lang_title')}</h2>
                <select id="xan-app-lang-select" class="xan-custom-input-select">
                    <option value="ru" ${window.currentLang === 'ru' ? 'selected' : ''}>${t('ui_lang_ru')}</option>
                    <option value="uk" ${window.currentLang === 'uk' ? 'selected' : ''}>${t('ui_lang_uk')}</option>
                </select>
                <br /><br />
				<label class="gg-script-label full-width custom-checkbox-label" style="display: inline !important;">
					<input type="checkbox" id="xan-stealth-toggle" ${isStealthActive ? 'checked' : ''} />
					<span class="checkbox-circle"></span>
					<span class="checkbox-text">${t('ui_stealth_enable')}</span>
				</label>
				<br />
				<label class="gg-script-label full-width custom-checkbox-label" style="display: inline !important;">
					<input type="checkbox" id="xan-siren-toggle" ${isSirenActive ? 'checked' : ''} />
					<span class="checkbox-circle"></span>
					<span class="checkbox-text">${t('ui_siren_enable')}</span>
				</label>
                <h2 class="gg-settings-title">${t('ui_interval_title')}</h2>
                <label>${t('ui_from')} <select id="interval-from"></select></label>
                <label class="gg-margin-left">${t('ui_to')} <select id="interval-to"></select></label>
                <br /><br />
                <div id="descr" class="gg-settings-descr">${descText}</div>
				
				<h2 class="gg-settings-title">${t('ui_melody_title')}</h2>
                <span id="alert-stop" class="gg-btn-stop">${t('ui_btn_stop')}</span>
                <select id="alert-melody"></select>
                <span id="alert-save" class="gg-btn-save">${t('ui_btn_save_track')}</span>
                
                <h2 class="gg-settings-title">${t('ui_scripts_title')}</h2>
                <div id="actScr">
                    <button id="clear-scripts-btn" class="gg-btn-clear">${t('ui_btn_clear_scripts')}</button><br />
                </div>			
                
                <br />
				${harvesterSettingsHtml}
                <div id="formaction">
                    <input type="button" id="submit-settings" value="${t('ui_btn_save_all')}" class="gg-btn-submit" />
                    <div id="success" class="gg-success-msg">${t('ui_success_msg')}</div>
                </div>
            </form>
            <br />
            <center>
                <table id="temp_menu" class="gg-settings-table">
                    <tbody>
                        <tr>
                            <th class="hdr" colspan="3" style="background-color: transparent; border: none; padding-bottom: 10px;">
                                ${t('ui_table_hdr')}
                            </th>
                        </tr>
                        <tr class="nosee" style="background: transparent;">
                            <th colspan="3" style="padding: 8px; text-align: center; border-bottom: 1px solid #344566; background: transparent; border: none;">
                                <span style="color: orange; font-weight: bold; margin-right: 15px;">${t('ui_view_mode_label')}</span>
                                <label style="cursor:pointer; margin-right: 15px;">
                                    <input type="radio" name="xan_menu_mode" value="text" ${menuViewMode === 'text' ? 'checked' : ''} /> ${t('ui_mode_text')}
                                </label>
                                <label style="cursor:pointer;">
                                    <input type="radio" name="xan_menu_mode" value="icon" ${menuViewMode === 'icon' ? 'checked' : ''} /> ${t('ui_mode_icon')}
                                </label>
                            </th>
                        </tr>
						<tr class="nosee" style="background: transparent;">
                            <th colspan="3" style="padding: 8px; text-align: center; border-bottom: 1px solid #344566; background: transparent; border: none;">
                                <h2 class="gg-settings-title">${t('ui_show_menu_pages')}</h2>
                                <div id="menu-pages-wrap">
                                    <label class="gg-script-label" style="opacity: 0.6; cursor: not-allowed;">
                                        <input type="checkbox" checked disabled /> ${t('ui_always_active')}
                                    </label>
                                    ${MENU_ALLOWED_PAGES.map(page => {
    const isChecked = menuPages.includes(page.id) ? 'checked' : '';
    return `
        <label class="gg-script-label short custom-checkbox-label">
            <input type="checkbox" data-menu-page="${page.id}" ${isChecked} />
            <span class="checkbox-circle"></span>
            <span class="checkbox-text">${_t(page.name)}</span>
        </label>
    `;
}).join('')}

                                </div>
                            </th>
                        </tr>
                    </tbody>
                </table>
            </center>
        </div>
    `);
	
	if (isHarvesterEnabled) {
    _('input[name="xan_pump_mode"]', true).forEach(radio => {
        radio.addEventListener('change', function() {
            const coordsRow = _('#xan-pump-coords-row');
            if (coordsRow) {
                coordsRow.style.display = this.value === 'target' ? 'block' : 'none';
            }
        });
    });
	}


    const ifr = _('#interval-from');
    const ito = _('#interval-to');

    const rebuildIto = (minVal) => {
        ito.innerHTML = '';
        for (let i = minVal + 5; i < 241; i++) {
            const opt = new Option(`${i} min`, i);
            if (i === lsTo) opt.selected = true;
            ito.add(opt);
        }
    };

    for (let i = 1; i < 151; i++) {
        const opt = new Option(`${i} min`, i);
        if (i === lsFrom) opt.selected = true;
        ifr.add(opt);
    }
    rebuildIto(lsFrom);

    ifr.addEventListener('change', function() {
        const val = parseInt(this.value, 10);
        rebuildIto(val);
        const descDiv = _('#descr');
        if (descDiv) {
            descDiv.innerHTML = t('ui_descr').replace('{from}', this.value).replace('{to}', ito.value);
        }
    });

    ito.addEventListener('change', function() {
        const descDiv = _('#descr');
        if (descDiv) {
            descDiv.innerHTML = t('ui_descr').replace('{from}', ifr.value).replace('{to}', this.value);
        }
    });
    const almel = _('#alert-melody');
    MELODIES.forEach((track, i) => {
        const ext = track.split('.').pop();
        const labelText = t('ui_melody_label').replace('{num}', i + 1).replace('{ext}', ext);
        const opt = new Option(labelText, track);
        if (track === melody) opt.selected = true;
        almel.add(opt);
    });

    let previewSnd = new Audio();
    previewSnd.loop = true;

    almel.addEventListener('change', function() {
        previewSnd.pause();
        previewSnd.src = chrome.runtime.getURL('sound/' + this.value);
        previewSnd.play().catch(e => console.log("Ожидание клика для аудио"));
    });

    _('#alert-stop').addEventListener('click', () => previewSnd.pause());
    _('#alert-save').addEventListener('click', () => {
        localStorage.xan3_melody = almel.value;
        showSuccessLabel();
    });

    const tempMenuTable = _('#temp_menu');
    const tempMenuTbody = _('#temp_menu tbody');
    
    if (tempMenuTable) {
        const spriteUrl = chrome.runtime.getURL('images/icons_20.png');
        tempMenuTable.style.setProperty('--xan-menu-sprite', `url(${spriteUrl})`);
    }

    MENU_LINKS.forEach((link, i) => {
        const isShown = userFormedMenu.length > 0 ? userFormedMenu[i] : 1;
        const visibilityClass = isShown === 0 ? 'gg-row-hidden' : 'gg-row-visible';
        const iconHtml = link.icon ? `<span class="xan-menu-icon ${link.icon}"></span>` : `<span style="display:inline-block; width:26px; text-align:center;">-</span>`;
        
        tempMenuTbody.insertAdjacentHTML('beforeend', `
            <tr class="nosee ${visibilityClass}">
                <th style="width: 60px; text-align: center;">
                    <select class="menu-visibility-select" data-index="${i}">
                        <option value="1" ${isShown === 1 ? 'selected' : ''}>${t('ui_yes')}</option>
                        <option value="0" ${isShown === 0 ? 'selected' : ''}>${t('ui_no')}</option>
                    </select>
                </th>
                <th style="width: 40px; text-align: center; padding: 2px 0;">${iconHtml}</th>
                <th class="gg-menu-name-cell">${_t(link.name)}</th>
            </tr>
        `);
    });
	
    tempMenuTbody.insertAdjacentHTML('beforeend', `
        <tr class="nosee">
            <th colspan="3" style="text-align: center; padding: 6px;"><a href="#xan-settings">${t('ui_link_top')}</a></th>
        </tr>
    `);
    _('.menu-visibility-select', true).forEach(select => {
        select.addEventListener('change', function() {
            const tr = this.closest('tr');
            if (tr) {
                if (this.value === '0') {
                    tr.classList.remove('gg-row-visible');
                    tr.classList.add('gg-row-hidden');
                } else {
                    tr.classList.remove('gg-row-hidden');
                    tr.classList.add('gg-row-visible');
                }
            }
        });
    });

    _('#temp_menu th.hdr').addEventListener('click', () => {
        _('#temp_menu .nosee', true).forEach(tr => tr.classList.toggle('see'));
    });

    const actScrContainer = _('#actScr');
    const activeNames = localStorage.xan3_active_modules 
        ? localStorage.xan3_active_modules.split('|').filter(x => x.endsWith(';true')).map(x => x.split(';')[0])
        : [];

    availableScripts.forEach(scr => {
    const isChecked = activeNames.includes(scr[0]) ? 'checked' : '';
    actScrContainer.insertAdjacentHTML('beforeend', `
        <label class="gg-script-label short custom-checkbox-label" title="${_t(scr[2])}">
            <input data-script="${scr[0]}" ${isChecked} type="checkbox" />
            <span class="checkbox-circle"></span>
            <span class="checkbox-text">${_t(scr[1])}</span>
        </label>
    `);
});


    _('#clear-scripts-btn').addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('xan3_active_modules');
        localStorage.removeItem('xan3_menu_pages'); 
        localStorage.removeItem('xan3_menu_view_mode');
        showSuccessLabel(() => location.reload());
    });

    _('#submit-settings').addEventListener('click', () => {
    if (parseInt(ito.value, 10) - parseInt(ifr.value, 10) < 5) {
        alert(t('ui_alert_interval_err'));
        return;
    }
    
	if (document.getElementById('xan-pump-max-slots')) {
    localStorage.xan3_pump_max_slots = _('#xan-pump-max-slots').value;
	}

	
    if (document.getElementById('xan-pump-reserved')) {
        localStorage.xan3_pump_reserved = _('#xan-pump-reserved').value;
        localStorage.xan3_pump_count = _('#xan-pump-count').value;
        
        const activeMode = document.querySelector('input[name="xan_pump_mode"]:checked');
        if (activeMode) localStorage.xan3_pump_mode = activeMode.value;
    
        const coordsInput = _('#xan-pump-coords');
        if (coordsInput) localStorage.xan3_pump_coords = coordsInput.value;
    }
    
    // Внутри обработчика #submit-settings добавляем:
    const stealthToggle = _('#xan-stealth-toggle');
    if (stealthToggle) {
        localStorage.setItem('xan3_stealth_active', stealthToggle.checked ? '1' : '0');
    }
	
	const sirenToggle = _('#xan-siren-toggle'); // <-- НАШ БЛОК СОХРАНЕНИЯ
	if (sirenToggle) {
		localStorage.setItem('xan3_siren_active', sirenToggle.checked ? '1' : '0');
	}

    const langSelect = document.getElementById('xan-app-lang-select');
    if (langSelect) {
        localStorage.setItem('xan3_app_lang', langSelect.value);
    }
    
    localStorage.xan3_active_modules = [..._('#actScr input', true)]
        .map(el => el.dataset.script + ';' + el.checked)
        .join('|');

    const selectedModeEl = document.querySelector('input[name="xan_menu_mode"]:checked');
    if (selectedModeEl) {
        localStorage.xan3_menu_view_mode = selectedModeEl.value;
    }

    const selectedPages = [...document.querySelectorAll('#menu-pages-wrap input[data-menu-page]:checked')]
        .map(el => el.dataset.menuPage);
    localStorage.xan3_menu_pages = selectedPages.join(';');

    localStorage.xan3_intfrom = ifr.value;
    localStorage.xan3_intto = ito.value;

    const menuStates = [..._('.menu-visibility-select', true)].map(el => el.value);
    localStorage.xan3_UserFormedMenu = menuStates.join(';');

    previewSnd.pause();
    showSuccessLabel(() => location.reload());
});

    // js/overview_ui.js — Часть 6 из 6 (ФИНАЛ МОДУЛЯ)

    _('#xan-lnk').addEventListener('click', (e) => {
        e.preventDefault();
        const settingsBlock = _('#xan-settings');
        if (settingsBlock) settingsBlock.classList.toggle('gg-panel-open');
    });

    function showSuccessLabel(callback = null) {
        const successDiv = _('#success');
        if (!successDiv) return;
        successDiv.classList.add('gg-show-block');
        setTimeout(() => {
            successDiv.classList.remove('gg-show-block');
            if (callback) callback();
        }, 1500);
    }

    _('.destroy', true).forEach(el => el.classList.add('gg-danger-mission'));
    _('[style="color:#8B0000"]', true).forEach(x => {
        x.classList.add('gg-danger-mission');
        const siblingDiv = x.closest('th')?.querySelector('div:nth-child(2)');
        if (siblingDiv) siblingDiv.classList.add('gg-danger-mission');
    });

    const currentIndex = planetSelect?.selectedIndex;
    const selectedOption = (currentIndex !== undefined && currentIndex >= 0) ? planetSelect.options[currentIndex] : null;
    const isMoon = selectedOption?.text?.includes('*') || false;

    if (isMoon) {
        const sims = [..._('[title="Открыть в симуляторе"]', true)]
            .filter(x => x.closest('th')?.querySelector('div[style="color:lime"]'));

        sims.forEach(x => {
            const thText = x.closest('th')?.textContent || '';
            if (thText.includes('[') && thText.includes(']')) {
                const coordsString = thText.substring(thText.lastIndexOf('[') + 1, thText.lastIndexOf(']'));
                const cory = coordsString.split(':');
                if (cory.length === 3) {
                    x.insertAdjacentHTML('afterend', `
                        <div title="${t('ui_phalanx_title')}" class="gg-phalanx-wrapper">
                            <a href="#" class="gg-phalanx-lnk" data-g="${cory[0]}" data-s="${cory[1]}" data-p="${cory[2]}">🔎</a>
                        </div>
                    `);
                }
            }
            x.remove();
        });

        _('#menu-holder')?.addEventListener('click', function(e) {
            const phalanxLink = e.target.closest('.gg-phalanx-lnk');
            if (!phalanxLink) return;
            e.preventDefault();
            window.location.href = `javascript:fenster('phalanx.php?galaxy=${phalanxLink.dataset.g}&system=${phalanxLink.dataset.s}&planet=${phalanxLink.dataset.p}')`;
        });
    }

    const mrq = _('marquee');
    if (mrq) {
        const STORAGE_KEY = "weekly_features_data";

        function getLastMonday9AM() {
            const now = new Date();
            const result = new Date(now);
            const currentDay = now.getDay();
            const daysToSubtract = currentDay === 0 ? 6 : currentDay - 1;
            result.setDate(now.getDate() - daysToSubtract);
            result.setHours(9, 0, 0, 0);
            if (now < result) result.setDate(result.getDate() - 7);
            return result.getTime();
        }
		
        mrq.closest('tr').insertAdjacentHTML('beforebegin', `<tr><td class="c" colspan="11"><div id="features_of_the_week" class="gg-features-btn">${t('ui_features_loading')}</div></td></tr>`);
		
        const featBtn = _('#features_of_the_week');
        let activeFeatures = [t('ui_features_loading'), t('ui_features_loading')];

        async function refreshFeatures() {
            const savedDataString = localStorage.getItem(STORAGE_KEY);
            const lastDeadline = getLastMonday9AM();
            
            if (savedDataString) {
                try {
                    const savedData = JSON.parse(savedDataString);
                    if (savedData && savedData.timestamp && savedData.timestamp >= lastDeadline) {
                        activeFeatures = [savedData.feature1, savedData.feature2];
                        featBtn.textContent = t('ui_features_loaded');
                        featBtn.classList.add('gg-loaded');
                        return;
                    }
                } catch (e) {}
            }

            try {
                const response = await fetch('user.php?info=1');
                const text = await response.text();
                const doc = new DOMParser().parseFromString(text, 'text/html');
                const lastSpans = Array.from(doc.querySelectorAll('th[colspan="10"] span')).slice(-2);
                
                const cleanText = (element) => {
                    const mainText = element.textContent || "";
                    const siblingText = element.nextSibling?.nodeType === 3 ? element.nextSibling.textContent : "";
                    return `${mainText} ${siblingText}`.replace(/\s+/g, ' ').trim();
                };

                const f1 = cleanText(lastSpans[0]);
                const f2 = cleanText(lastSpans[1]);
                
                localStorage.setItem(STORAGE_KEY, JSON.stringify({ timestamp: Date.now(), feature1: f1, feature2: f2 }));
                activeFeatures = [f1, f2];
            } catch (error) {
                activeFeatures = [t('ui_features_fallback1'), t('ui_features_fallback2')];
            } finally {
                featBtn.textContent = t('ui_features_loaded');
                featBtn.classList.add('gg-loaded');
            }
        }

        refreshFeatures();

        featBtn.addEventListener('click', () => {
            localStorage.removeItem(STORAGE_KEY);
            location.reload();
        });

        featBtn.addEventListener('mouseover', (e) => {
            if (_('#gg-xan-tip')) return;
            document.body.insertAdjacentHTML('beforeend', `
                <div id="gg-xan-tip">
                    <h4 align="center" class="gg-tip-title">${t('ui_features_tip_title')}</h4>
                    ${activeFeatures.map(x => `<div class="gg-tip-row">• ${x.trim()}</div>`).join('')}
                </div>
            `);
        });

        featBtn.addEventListener('mousemove', (e) => {
            const tip = _('#gg-xan-tip');
            if (tip) {
                tip.style.top = (e.pageY - 100) + 'px';
                tip.style.left = (e.pageX + 30) + 'px';
            }
        });

        featBtn.addEventListener('mouseout', () => _('#gg-xan-tip')?.remove());
    }
	
	    // Красивое интерактивное руководство Тыквенного Комбайна (копия логики сообщений)
    if (isHarvesterEnabled) {
        const pumpHelpBtn = document.getElementById('xanPumpHelpBtn');
        if (pumpHelpBtn) {
            pumpHelpBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const helpGuide = document.getElementById('xan-pump-help-guide');
                if (helpGuide) {
                    if (helpGuide.style.display === 'none') {
                        helpGuide.style.display = 'block';
                    } else {
                        helpGuide.style.display = 'none';
                    }
                }
            });
        }
    }

}
