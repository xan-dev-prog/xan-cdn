// js/notes.js — Заметки XAN v3.0

import { _ } from './query.js';

/**
 * Инициализация модуля заметок на странице заметок игры
 */
export function initNotesPage() {
	const ttl = _('[name="title"]');
	// Мультиязычный поиск плейсхолдера текстового поля игры
	const tArea = document.querySelector('[placeholder="Текст заметки"]') || document.querySelector('[placeholder="Текст нотатки"]') || _('textarea');
	const leftCell = _('[src\$="zametki.png"]')?.closest('th');
	const simLinks = _('[href*=".com/sim/?v="]', 1);
	const coordsLinks = _('[href*="galaxy.php"]', 1);

	// 1. Автоисправление раскладки клавиатуры в заголовке (строго в ВЕРХНИЙ РЕГИСТР)
	if (ttl) {
		// Динамические правила автозамены в зависимости от активного языка приложения
		const correctionRules = window.currentLang === 'uk' ? [
			{ regex: /cujy/gi, replacement: 'ЗГІН' },
			{ regex: /jnpsd/gi, replacement: 'ВІДГУК' },
			{ regex: /gjlkjd/gi, replacement: 'ПІДЛОВ' },
			{ regex: /згін/gi, replacement: 'ЗГІН' },
			{ regex: /відгук/gi, replacement: 'ВІДГУК' },
			{ regex: /підлов/gi, replacement: 'ПІДЛОВ' }
		] : [
			{ regex: /cujy/gi, replacement: 'СГОН' },
			{ regex: /jnpsd/gi, replacement: 'ОТЗЫВ' },
			{ regex: /gjlkjd/gi, replacement: 'ПОДЛОВ' },
			{ regex: /сгон/gi, replacement: 'СГОН' },
			{ regex: /отзыв/gi, replacement: 'ОТЗЫВ' },
			{ regex: /подлов/gi, replacement: 'ПОДЛОВ' }
		];

		ttl.addEventListener('blur', function() {
			let val = this.value;
			let changed = false;

			correctionRules.forEach(rule => {
				if (rule.regex.test(val)) {
					val = val.replace(rule.regex, rule.replacement);
					changed = true;
				}
			});

			if (changed) {
				this.value = val;
			}
		});
	}

	// 2. Стилизация левой ячейки (замена изображения на фирменный фоновый ассет XAN)
	if (leftCell) {
		leftCell.innerHTML = '';
		Object.assign(leftCell.style, {
			'background': `var(--xan-notes-bg, #344566 url("${chrome.runtime.getURL('images/alien1-128-128.png')}") center center no-repeat)`
		});
	}

	// 3. Установка дефолтного шаблона рапорта в текстовое поле заметок
	if (tArea && !tArea.value.trim()) {
		tArea.value = t('n_template');
	}

	// 4. Открытие координат в новой вкладке и фильтрация ссылок галактики
	if (coordsLinks && coordsLinks.length) {
		Array.from(coordsLinks)
			.filter(link => link.textContent.trim().indexOf('[') === 0)
			.forEach(link => {
				link.target = '_blank';
			});
	}

	// 5. Форматирование и кастомизация ссылок на симулятор
	if (simLinks && simLinks.length) {
		simLinks.forEach(link => {
			link.classList.add('simlink');
			link.textContent = t('n_sim_link');
		});
	}
	
			// 6. Защита и подсветка заметок, начинающихся с символа #, от случайного удаления
	const noteLinks = document.querySelectorAll('form[name="notes"] a[href*="notes.php?a=2"]');
	if (noteLinks.length) {
		noteLinks.forEach(link => {
			if (link.textContent.trim().startsWith('#')) {
				link.style.color = '#ff8a80';
				const row = link.closest('tr');
				const checkbox = row?.querySelector('input[name="delmes[]"]');
				if (checkbox) {
					const cell = checkbox.parentElement;
					checkbox.remove();
					if (cell) {
						cell.textContent = '🔒';
					}
				}
			}
		});
	}


}

/* Взаимодействие Блока Заметки с Симулятором (Мультиязычный парсинг текстовых узлов) */
try { 
	const searchTerm = t('n_search_term');
	[..._('body').fndDpst(searchTerm).childNodes]
	.filter(x => x.nodeType === 3 && x.textContent.trim() !== '') 
	.forEach((x, i) => {
		const div = document.createElement('div');
		div.textContent = x.textContent; 
		x.replaceWith(div); 	
		div.id = 'notes-div-' + i;
		Object.assign(div.style, {
			'display' : 'inline'
		});
	});
} catch(e){}
