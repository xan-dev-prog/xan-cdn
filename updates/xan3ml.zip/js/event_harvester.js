// js/event_harvester.js — Хеллоуин Комбайн с удержанием резерва слотов

import { _ } from './query.js';
import { getRandomInt, isScriptActive } from './utils.js';

export function initEventHarvester() {
    const statusBar = _('#xan-pump-status-bar');
    const statusText = _('#xan-pump-status-text');
    const toggleBtn = _('#xan-pump-toggle-btn');

    if (!isScriptActive('harvester')) {
        if (statusBar) statusBar.style.display = 'none';
        return;
    }

    if (statusBar) statusBar.style.display = 'block';

    // Инициализация обработчика кнопки Старт/Стоп (строго 1 раз через dataset)
    if (toggleBtn && !toggleBtn.dataset.clickAttached) {
        toggleBtn.dataset.clickAttached = 'true';
        toggleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const currentActive = localStorage.getItem('xan3_pump_active') !== '0';
            
            if (currentActive) {
                // Ставим на паузу
                localStorage.setItem('xan3_pump_active', '0');
                this.textContent = t('ui_pump_btn_start');
                // Сбрасываем текущие таймеры вылетов, если они тикают
                if (window.xanPumpReloadTimeout) {
                    clearTimeout(window.xanPumpReloadTimeout);
                    window.xanPumpReloadTimeout = null;
                }
                updateStatus(statusText, t('ui_pump_status_paused'));
            } else {
                // Запускаем в работу
                localStorage.setItem('xan3_pump_active', '1');
                localStorage.setItem('xan3_stealth_active', '0'); // Жёстко и навсегда отключаем переходы при старте
                this.textContent = t('ui_pump_btn_stop');
                window.location.reload(); // Перезагружаем для мгновенного включения в цикл
            }

        });
    }

    // Проверяем, не нажал ли юзер "Стоп"
    const isPumpActive = localStorage.getItem('xan3_pump_active') !== '0';
    if (!isPumpActive) {
        updateStatus(statusText, t('ui_pump_status_paused'));
        return;
    }

    console.log("[XAN Комбайн] Анализ воздушного пространства...");
    executeHarvesterLogic(statusText);
}

function executeHarvesterLogic(statusTextEl) {
    const slotsTd = [...document.querySelectorAll('td')].find(x => 
        x.textContent.includes(t('ui_pump_fleet_text'))
    );
    
    if (!slotsTd) {
        console.log("[XAN Комбайн] Текстовый индикатор слотов флота не найден на странице.");
        updateStatus(statusTextEl, "⚠️ Не удалось определить слоты на этой странице");
        setupNextPageReload(statusTextEl);
        return;
    }

    // Очищаем строку от всех НЕ-цифр. Останется только чистая цифра занятых слотов
    const cleanNumbers = slotsTd.textContent.replace(/\D/g, '');
    const occupiedSlots = cleanNumbers ? parseInt(cleanNumbers, 10) : 0;

    // Константы максимума аккаунта и твоего резерва свободных мест
    const totalSlots = parseInt(localStorage.xan3_pump_max_slots, 10) || 22;
    const reservedSlots = parseInt(localStorage.xan3_pump_reserved, 10) || 5; 
    const sendCount = parseInt(localStorage.xan3_pump_count, 10) || 1;
    const mode = localStorage.xan3_pump_mode || 'target';
    const coordsStr = localStorage.xan3_pump_coords || '';

    const parts = coordsStr.split(':').map(Number);
    if (mode === 'target' && (parts.length !== 3 || parts.some(isNaN))) {
        updateStatus(statusTextEl, t('ui_pump_status_no_coords'));
        setupNextPageReload(statusTextEl);
        return;
    }

    // Универсальная формула резерва: из максимума вычитаем занятое и резерв
    const slotsToFill = totalSlots - occupiedSlots - reservedSlots;

    console.log(`[XAN Комбайн] Всего: ${totalSlots}, Занято: ${occupiedSlots}, Резерв: ${reservedSlots}. Доступно к отправке: ${slotsToFill}`);

    if (slotsToFill > 0) {
        updateStatus(statusTextEl, `${t('ui_pump_status_sending')} (${slotsToFill} волн)`);

        const initialDelay = getRandomInt(3000, 6000);
        
        setTimeout(() => {
            // Двойная проверка перед пуском (вдруг юзер нажал Стоп пока шел таймаут реакции)
            if (localStorage.getItem('xan3_pump_active') === '0') return;

            if (mode === 'target') {
                let sentWaves = 0;
                for (let i = 0; i < slotsToFill; i++) {
                    const stepDelay = i * getRandomInt(2000, 4000);
                    
                    setTimeout(async () => {
                        if (localStorage.getItem('xan3_pump_active') === '0') return;

                        // Передаем чистые координаты поиндексно
                        await sendRecyclerRequest(parts[0], parts[1], parts[2], sendCount);
                        sentWaves++;

                        // Синхронный релоад строго после вылета самой последней волны
                        if (sentWaves === slotsToFill) {
                            console.log(`[XAN Комбайн] Цикл завершен. Перезагрузка страницы...`);
                            setTimeout(() => {
                                if (localStorage.getItem('xan3_pump_active') !== '0') {
                                    window.location.reload();
                                }
                            }, 2500);
                        }
                    }, stepDelay);
                }
            }
        }, initialDelay);

    } else {
        // Если места под комбайн нет (удерживается заданный тобой резерв свободных слотов)
        updateStatus(statusTextEl, `${t('ui_pump_status_waiting')}<br>[В полете: ${occupiedSlots}/${totalSlots} | Резерв: ${reservedSlots}]`);
        setupNextPageReload(statusTextEl);
    }
}

function updateStatus(element, text) {
    if (element) {
        element.innerHTML = text;
    }
}

async function sendRecyclerRequest(g, s, p, count) {
    try {
        const url = 'flotenajax.php?action=send';
        const formData = new FormData();
        formData.append('mission', '8');
        formData.append('galaxy', g.toString());
        formData.append('system', s.toString());
        formData.append('planet', p.toString());
        formData.append('planettype', '2');
        formData.append('ship210', '0');
        formData.append('ship209', count.toString());
        formData.append('rndval', Date.now().toString());

        const response = await fetch(url, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const textResponse = await response.text();
            console.log(`[XAN Комбайн] 🎃 Пуск на [${g}:${s}:${p}]. Ответ:`, textResponse);
            return true;
        }
        return false;
    } catch (e) {
        console.error("[XAN Комбайн] Ошибка отправки запроса:", e);
        return false;
    }
}

function setupNextPageReload(statusTextEl) {
    if (window.xanPumpReloadTimeout) return;
    if (localStorage.getItem('xan3_pump_active') === '0') return;

    const lsFrom = parseInt(localStorage.xan3_intfrom, 10) || 15;
    const lsTo = parseInt(localStorage.xan3_intto, 10) || 45;
    
    const reloadMinutes = getRandomInt(lsFrom, lsTo);
    
    // Вычисляем точное время релоада
    const now = new Date();
    const reloadTime = new Date(now.getTime() + reloadMinutes * 60 * 1000);
    const hours = reloadTime.getHours().toString().padStart(2, '0');
    const minutes = reloadTime.getMinutes().toString().padStart(2, '0');
    const exactTimeStr = `${hours}:${minutes}`;

    console.log(`[XAN Комбайн] Следующая проверка через ${reloadMinutes} мин. (в ${exactTimeStr})`);

    // Рендерим локализованную строку на панель
    if (statusTextEl) {
        const currentText = statusTextEl.innerHTML;
        // Загружаем шаблон строки из словаря и подставляем время вместо {time}
        const localizedTimeStr = t('ui_pump_status_next_check').replace('{time}', exactTimeStr);
        
        statusTextEl.innerHTML = `${currentText} <span style="padding-left: 5px; color: #ff9800; font-size: 0.9em;">${localizedTimeStr}</span>`;
    }

    window.xanPumpReloadTimeout = setTimeout(() => {
        if (localStorage.getItem('xan3_stealth_active') === '0' && localStorage.getItem('xan3_pump_active') !== '0') {
            window.location.href = 'overview.php';
        }
    }, reloadMinutes * 60 * 1000);
}
