// js/game_data.js — Централизованная мультиязычная база данных игры XGame-Online

// 1. СПИСОК КОРАБЛЕЙ
export const SHIP_NAMES = {
    MILITARY: {
        204: { ru: "Корвет", uk: "Корвет" },
        205: { ru: "Фрегат", uk: "Фрегат" },
        206: { ru: "Крейсер", uk: "Крейсер" },
        207: { ru: "Линкор", uk: "Лінкор" },
        215: { ru: "Линейный крейсер", uk: "Лінійний крейсер" },
        211: { ru: "Броненосец", uk: "Броненосець" },
        216: { ru: "Эсминец", uk: "Есмінець" },
        213: { ru: "Флагман", uk: "Флагман" },
        217: { ru: "Авианосец", uk: "Авіаносець" },
        214: { ru: "Сверхновая Звезда", uk: "Наднова Зірка" }
    },
    CIVILIAN: {
        202: { ru: "Малый танкер", uk: "Малий танкер" },
        203: { ru: "Большой танкер", uk: "Великий танкер" },
        210: { ru: "Шпионский зонд", uk: "Шпигунський зонд" },
        209: { ru: "Переработчик", uk: "Переробник" },
        208: { ru: "Колонизатор", uk: "Колонізатор" }
    }
};

export const MILITARY_IDS = Object.keys(SHIP_NAMES.MILITARY).map(Number);
export const CIVILIAN_IDS = Object.keys(SHIP_NAMES.CIVILIAN).map(Number);

// 2. СПИСОК ДОСТУПНЫХ МЕЛОДИЙ ДЛЯ СИГНАЛА ОБ АТАКЕ
export const MELODIES = [
    '1.ogg', '2.ogg', '3.ogg', '4.ogg', '5.ogg', '6.ogg', '7.ogg', '8.ogg', '9.ogg',
    '1.mp3', '2.mp3', '3.mp3', '4.mp3', '5.mp3', '6.mp3', '7.mp3', '8.mp3', '9.mp3', '10.mp3'
];

// 3. МАССИВ СООБЩЕНИЙ ДЛЯ ПРИВЛЕЧЕНИЯ ВНИМАНИЯ В ЗАГОЛОВКЕ ВКЛАДКИ
export const WARNINGS = [
    '-------->>> А Т А К А <<<--------',
    '-------->>> Й О П Т А <<<--------',
    '-------->>> А Х Т У Н Г <<<--------',
    '-------->>> Б Л Я <<<--------',
    '-------->>> С У К А <<<--------',
    '-------->>> И З М Е Н А <<<--------',
    '-------->>> НЕ ПРОЩЁЛКАЙ <<<--------'
];

// 4. ПОЛНЫЙ СПИСОК ПУНКТОВ МЕНЮ
export const MENU_LINKS = [
    { url: "vip.php", name: { ru: "VIP", uk: "VIP" }, icon: "xan-ico-vip", target: "" },
    { url: "messages.php?id=admin", name: { ru: "Администрация", uk: "Адміністрація" }, icon: "xan-ico-admin", target: "_blank" },
    { url: "shop.php", name: { ru: "Аккаунты", uk: "Акаунти" }, icon: "xan-ico-accounts", target: "" },
    { url: "alliance.php", name: { ru: "Альянс", uk: "Альянс" }, icon: "xan-ico-alliance", target: "" },
    { url: "auction.php", name: { ru: "Аукцион", uk: "Аукціон" }, icon: "xan-ico-auction", target: "" },
    { url: "banned.php", name: { ru: "Баны", uk: "Бани" }, icon: "xan-ico-banned", target: "" },
    { url: "buildings.php?mode=fleet", name: { ru: "Верфь", uk: "Верф" }, icon: "xan-ico-shipyard", target: "" },
    { url: "questions.php", name: { ru: "Вопросы", uk: "Питання" }, icon: "xan-ico-questions", target: "" },
	{ url: "buildings.php?gid=43", name: { ru: "Врата", uk: "Зоряна брама" }, icon: "xan-ico-jumpgate", target: "" },
    { url: "resources.php", name: { ru: "Выработка", uk: "Виробіток" }, icon: "xan-ico-resources", target: "" },
    { url: "logout.php", name: { ru: "Выход", uk: "Вихід" }, icon: "xan-ico-logout", target: "" },
    { url: "galaxy.php?mode=0", name: { ru: "Галактика", uk: "Галактика" }, icon: "xan-ico-galaxy", target: "" },
    { url: "dock.php", name: { ru: "Док", uk: "Док" }, icon: "xan-ico-dock", target: "" },
    { url: "savekb.php", name: { ru: "Доклады", uk: "Доповіді" }, icon: "xan-ico-reports", target: "" },
    { url: "buddy.php", name: { ru: "Друзья", uk: "Друзі" }, icon: "xan-ico-friends", target: "" },
    { url: "hall.php", name: { ru: "Зал Славы", uk: "Зала Слави" }, icon: "xan-ico-hall", target: "" },
    { url: "notes.php", name: { ru: "Заметки", uk: "Нотатки" }, icon: "xan-ico-notes", target: "" },
    { url: "imperium.php", name: { ru: "Империя", uk: "Імперія" }, icon: "xan-ico-imperium", target: "" },
    { url: "buildings.php?mode=research", name: { ru: "Исследования", uk: "Дослідження" }, icon: "xan-ico-research", target: "" },
    { url: "quest.php", name: { ru: "Квесты", uk: "Квести" }, icon: "xan-ico-quests", target: "" },
    { url: "utf8/sms.php", name: { ru: "Куиды", uk: "Куїди" }, icon: "xan-ico-kuids", target: "" },
    { url: "games.php", name: { ru: "Мини-игры", uk: "Міні-ігри" }, icon: "", target: "" },
    { url: "officier.php", name: { ru: "Наемники", uk: "Найманці" }, icon: "xan-ico-mercenaries", target: "" },
    { url: "referrals.php", name: { ru: "Наставник", uk: "Наставник" }, icon: "xan-ico-mentor", target: "" },
    { url: "options.php", name: { ru: "Настройки", uk: "Налаштування" }, icon: "xan-ico-options", target: "" },
    { url: "overview.php", name: { ru: "Обзор", uk: "Огляд" }, icon: "xan-ico-overview", target: "" },
    { url: "buildings.php?mode=defense", name: { ru: "Оборона", uk: "Оборона" }, icon: "xan-ico-defense", target: "" },
    { url: "user.php", name: { ru: "Профиль", uk: "Профіль" }, icon: "xan-ico-profile", target: "" },
    { url: "https://xgame-online.com", name: { ru: "Симуляторы", uk: "Симулятори" }, icon: "xan-ico-simulators", target: "_blank" },
    { url: "allykasse.php", name: { ru: "Склад альянса", uk: "Склад альянсу" }, icon: "xan-ico-allydeposit", target: "" },
    { url: "stavki.php", name: { ru: "События", uk: "Події" }, icon: "xan-ico-events", target: "" },
    { url: "messages.php", name: { ru: "Сообщения", uk: "Повідомлення" }, icon: "xan-ico-messages", target: "" },
    { url: "buildings.php", name: { ru: "Сооружения", uk: "Споруди" }, icon: "xan-ico-buildings", target: "" },
    { url: "rating.php?us=1&new_pokaz=1", name: { ru: "Статистика", uk: "Статистика" }, icon: "xan-ico-stats", target: "" },
    { url: "techtree.php", name: { ru: "Технологии", uk: "Технології" }, icon: "xan-ico-tech", target: "" },
    { url: "tickets.php", name: { ru: "Тикеты", uk: "Тікети" }, icon: "", target: "_blank" },
    { url: "trade.php?go=2", name: { ru: "Торговля", uk: "Торгівля" }, icon: "xan-ico-trade", target: "" },
    { url: "fleet.php", name: { ru: "Флот", uk: "Флот" }, icon: "xan-ico-fleet", target: "" },
    { url: "http://xgame-online.com", name: { ru: "Форум", uk: "Форум" }, icon: "xan-ico-forum", target: "_blank" },
    { url: "frames.php", name: { ru: "Фреймы", uk: "Фрейми" }, icon: "", target: "" },
    { url: "buildings.php?gid=99", name: { ru: "Хозблок", uk: "Госпблок" }, icon: "xan-ico-hozblock", target: "" }
];

// 5. НЕИЗМЕННЫЙ СКЕЛЕТ ПРИШЕЛЬЦЕВ
export const ALIENS_ORIGIN = {
    'Adorariel': { category: 4, index: 1, defaultCoords: '[1:893:1]' },
    'Akigal': { category: 1, index: 1, defaultCoords: '[1:262:13]' },
    'Alsanius': { category: 5, index: 1, defaultCoords: '[1:947:14]' },
    'Anadred': { category: 5, index: 2, defaultCoords: '[1:301:11]' },
    'Arashiran': { category: 4, index: 2, defaultCoords: '[1:200:6]' },
    'Arirdana': { category: 2, index: 1, defaultCoords: '[1:220:13]' },
    'Ariulsa': { category: 4, index: 3, defaultCoords: '[1:860:7]' },
    'Aur': { category: 1, index: 2, defaultCoords: '[1:808:2]' },
    'Aurigas': { category: 2, index: 2, defaultCoords: '[1:531:14]' },
	'Ballagas': { category: 2, index: 3, defaultCoords: '[1:722:13]' },
    'Basar': { category: 3, index: 1, defaultCoords: '[1:9:7]' },
    'Bloodsmasher': { category: 5, index: 3, defaultCoords: '[1:95:10]' },
    'Bloodterror': { category: 1, index: 3, defaultCoords: '[1:865:4]' },
    'Bludbringer': { category: 5, index: 4, defaultCoords: '[1:833:5]' },
    'Bodora': { category: 2, index: 4, defaultCoords: '[1:335:5]' },
    'Broadwind': { category: 3, index: 2, defaultCoords: '[1:567:13]' },
	'Centrigelv': { category: 4, index: 4, defaultCoords: '[1:24:3]' },
    'Centrinn': { category: 4, index: 5, defaultCoords: '[1:129:14]' },
    'Cerezar': { category: 4, index: 6, defaultCoords: '[1:937:15]' },
    'Chillforge': { category: 1, index: 4, defaultCoords: '[1:329:3]' },
    'Coizan': { category: 5, index: 5, defaultCoords: '[1:715:8]' },
    'Conjudora': { category: 1, index: 5, defaultCoords: '[1:157:15]' },
    'Cordalanim': { category: 5, index: 6, defaultCoords: '[1:104:13]' },
	'Daimuro': { category: 4, index: 7, defaultCoords: '[1:910:14]' },
    'Daizil': { category: 5, index: 7, defaultCoords: '[1:275:11]' },
    'Dianagrinn': { category: 1, index: 6, defaultCoords: '[1:607:1]' },
    'Dotaur': { category: 2, index: 5, defaultCoords: '[1:971:13]' },
    'Doukora': { category: 5, index: 8, defaultCoords: '[1:282:8]' },
    'Dukazahn': { category: 5, index: 9, defaultCoords: '[1:341:14]' },
	'Felmeena': { category: 4, index: 8, defaultCoords: '[1:283:15]' },
    'Felodar': { category: 4, index: 9, defaultCoords: '[1:295:12]' },
    'Fotus': { category: 1, index: 7, defaultCoords: '[1:978:2]' },
    'Frostcaster': { category: 1, index: 8, defaultCoords: '[1:745:11]' },
	'Galkis': { category: 4, index: 10, defaultCoords: '[1:532:5]' },
    'Gavinrahelm': { category: 1, index: 9, defaultCoords: '[1:956:7]' },
    'Gholbibor': { category: 3, index: 3, defaultCoords: '[1:443:7]' },
    'Gholbiril': { category: 2, index: 6, defaultCoords: '[1:867:4]' },
    'Granilhala': { category: 1, index: 10, defaultCoords: '[1:316:2]' },
	'Ianrne': { category: 3, index: 4, defaultCoords: '[1:574:11]' },
	'JoJogami': { category: 3, index: 5, defaultCoords: '[1:271:3]' },
    'JoJolmaran': { category: 3, index: 6, defaultCoords: '[1:82:15]' },
    'Jukinos': { category: 3, index: 7, defaultCoords: '[1:431:6]' },
	'Kagasho': { category: 4, index: 11, defaultCoords: '[1:263:14]' },
    'Kajizil': { category: 2, index: 7, defaultCoords: '[1:968:15]' },
    'Kallador': { category: 5, index: 10, defaultCoords: '[1:810:2]' },
    'Kathrilore': { category: 3, index: 8, defaultCoords: '[1:757:4]' },
    'Kawyn': { category: 2, index: 8, defaultCoords: '[1:472:10]' },
    'Kefym': { category: 4, index: 12, defaultCoords: '[1:172:15]' },
    'Kelehelm': { category: 2, index: 9, defaultCoords: '[1:747:11]' },
    'Kelelis': { category: 3, index: 9, defaultCoords: '[1:211:9]' },
    'Kezragore': { category: 1, index: 11, defaultCoords: '[1:288:1]' },
    'Kirizius': { category: 3, index: 10, defaultCoords: '[1:862:15]' },
	'Lightwing': { category: 5, index: 11, defaultCoords: '[1:897:4]' },
	'Malamand': { category: 3, index: 11, defaultCoords: '[1:778:9]' },
    'Malashicage': { category: 5, index: 12, defaultCoords: '[1:560:7]' },
    'Male': { category: 2, index: 10, defaultCoords: '[1:197:15]' },
    'Mana': { category: 1, index: 12, defaultCoords: '[1:556:2]' },
    'Maubei': { category: 3, index: 12, defaultCoords: '[1:473:13]' },
	'Maule': { category: 3, index: 13, defaultCoords: '[1:885:11]' },
    'Maugrel': { category: 4, index: 13, defaultCoords: '[1:102:7]' },
    'Mavethris': { category: 4, index: 14, defaultCoords: '[1:550:1]' },
    'Mekree': { category: 5, index: 13, defaultCoords: '[1:359:12]' },
    'Mezilrajas': { category: 1, index: 13, defaultCoords: '[1:386:14]' },
    'Mightfont': { category: 4, index: 15, defaultCoords: '[1:389:5]' },
    'Mnemand': { category: 3, index: 14, defaultCoords: '[1:235:9]' },
    'Modiwyn': { category: 2, index: 11, defaultCoords: '[1:640:4]' },
    'Mooncliff': { category: 5, index: 14, defaultCoords: '[1:818:15]' },
    'Morim': { category: 2, index: 12, defaultCoords: '[1:449:13]' },
    'Morlulbine': { category: 4, index: 16, defaultCoords: '[1:250:13]' },
    'Mubor': { category: 5, index: 15, defaultCoords: '[1:831:13]' },
	'Nall': { category: 2, index: 13, defaultCoords: '[1:967:15]' },
    'Nalme': { category: 1, index: 14, defaultCoords: '[1:564:9]' },
    'Ner': { category: 1, index: 15, defaultCoords: '[1:407:1]' },
    'Nuallador': { category: 4, index: 17, defaultCoords: '[1:696:4]' },
	'Opiril': { category: 3, index: 15, defaultCoords: '[1:458:9]' },
	'Rexfire': { category: 5, index: 16, defaultCoords: '[1:724:10]' },
    'Rexkiller': { category: 5, index: 17, defaultCoords: '[1:822:13]' },
    'Rexsinger': { category: 1, index: 16, defaultCoords: '[1:835:11]' },
	'Sagrel': { category: 2, index: 14, defaultCoords: '[1:227:10]' },
    'Saidora': { category: 3, index: 16, defaultCoords: '[1:960:8]' },
    'Sale': { category: 2, index: 15, defaultCoords: '[1:389:8]' },
    'Shaliris': { category: 3, index: 17, defaultCoords: '[1:335:8]' },
    'Sharpdweller': { category: 2, index: 16, defaultCoords: '[1:161:6]' },
    'Siraril': { category: 1, index: 17, defaultCoords: '[1:490:4]' },
	'Starfang': { category: 2, index: 17, defaultCoords: '[1:598:4]' },
	'Tausida': { category: 5, index: 18, defaultCoords: '[1:90:8]' },
	'Teshicage': { category: 3, index: 18, defaultCoords: '[1:191:6]' },
	'Tokora': { category: 4, index: 18, defaultCoords: '[1:959:7]' },
	'Tunos': { category: 2, index: 18, defaultCoords: '[1:532:13]' },
	'Tutilar': { category: 1, index: 18, defaultCoords: '[1:736:4]' },
	'Vigor': { category: 3, index: 19, defaultCoords: '[1:934:14]' },
	'Visho': { category: 1, index: 19, defaultCoords: '[1:379:11]' },
	'Voodoogami': { category: 1, index: 20, defaultCoords: '[1:737:1]' },
	'Vukinos': { category: 5, index: 19, defaultCoords: '[1:34:1]' },
	'Windcrusher': { category: 5, index: 20, defaultCoords: '[1:892:10]' },
	'Yogor': { category: 4, index: 19, defaultCoords: '[1:702:3]' },
	'Zaron': { category: 3, index: 20, defaultCoords: '[1:508:8]' },
	'Zolokus': { category: 2, index: 19, defaultCoords: '[1:514:4]' },
	'Zulkira': { category: 4, index: 20, defaultCoords: '[1:478:4]' },
	'Zulule': { category: 2, index: 20, defaultCoords: '[1:423:10]' }
};

// 6. ТРАНСПОРТНЫЕ ХАРАКТЕРИСТИКИ
export const TRANSPORT_SPECS = {
  MT: {
    name: { ru: "Малый транспорт", uk: "Малий транспорт" },
    capacity: 5000 
  },
  BT: {
    name: { ru: "Большой транспорт", uk: "Великий транспорт" },
    capacity: 25000 
  }
};

// 7. ДЕРЕВО ТЕХНОЛОГИЙ И ПОСТРОЕК
export const TECH_TREE = [
	['1', { ru: 'Шахта металла', uk: 'Шахта металу' }],
	['2', { ru: 'Шахта алмазов', uk: 'Шахта алмазів' }],
	['3', { ru: 'Синтезатор урана', uk: 'Синтезатор урану' }],
	['4', { ru: 'Солнечная электростанция', uk: 'Сонячна електростанція' }],
	['12', { ru: 'Атомная электростанция', uk: 'Атомна електростанція' }],
	['14', { ru: 'Фабрика', uk: 'Фабрика' }],
	['15', { ru: 'Завод', uk: 'Завод' }],
	['21', { ru: 'Верфь', uk: 'Верф' }],
	['22', { ru: 'Склад металла', uk: 'Склад металу' }],
	['23', { ru: 'Склад алмазов', uk: 'Склад алмазів' }],
	['24', { ru: 'Склад урана', uk: 'Склад урану' }],
	['31', { ru: 'Лаборатория', uk: 'Лабораторія' }],
	['32', { ru: 'Док', uk: 'Док' }],
	['33', { ru: 'Терраформер', uk: 'Тераформер' }],
	['34', { ru: 'База альянса', uk: 'База альянсу' }],
	['44', { ru: 'Ракетный комплекс', uk: 'Ракетний комплекс' }],
	['99', { ru: 'Хозблок', uk: 'Госпблок' }],
	['106', { ru: 'Шпионаж', uk: 'Шпигунство' }],
	['108', { ru: 'Навигационная технология', uk: 'Навігаційна технологія' }],
	['109', { ru: 'Оружейная технология', uk: 'Збройова технологія' }],
	['110', { ru: 'Щитовая технология', uk: 'Щитова технологія' }],
	['111', { ru: 'Бронирование кораблей', uk: 'Бронювання кораблів' }],
	['113', { ru: 'Энергетическая технология', uk: 'Енергетична технологія' }],
	['114', { ru: 'Гиперпространство', uk: 'Гіперпростір' }],
	['115', { ru: 'Реактивный двигатель', uk: 'Реактивний двигун' }],
	['117', { ru: 'Ионный двигатель', uk: 'Іонний двигун' }],
	['118', { ru: 'Гипер-двигатель', uk: 'Гіпер-двигун' }],
	['120', { ru: 'Лазерная технология', uk: 'Лазерна технологія' }],
	['121', { ru: 'Термоядерный синтез', uk: 'Термоядерний синтез' }],
	['122', { ru: 'Плазменная технология', uk: 'Плазмова технологія' }],
	['123', { ru: 'Исследовательской сеть', uk: 'Дослідницька мережа' }],
	['199', { ru: 'Квантовая гравитация', uk: 'Квантова гравітація' }],
	['124', { ru: 'Экспедиционная технология', uk: 'Експедиційна технологія' }],
	['139', { ru: 'Сфера геологии', uk: 'Сфера геології' }],
	['140', { ru: 'Научно-технический прогресс', uk: 'Науково-технічний прогрес' }],
	['150', { ru: 'Колонизационная технология', uk: 'Колонізаційна технологія' }],
	['212', { ru: 'Солнечный спутник', uk: 'Сонячний супутник' }],
	['202', { ru: 'Малый танкер', uk: 'Малий танкер' }],
	['203', { ru: 'Большой танкер', uk: 'Великий танкер' }],
	['210', { ru: 'Шпионский зонд', uk: 'Шпигунський знайшов' }],
	['208', { ru: 'Колонизатор', uk: 'Колонізатор' }],
	['209', { ru: 'Переработчик', uk: 'Переробник' }],
	['204', { ru: 'Корвет', uk: 'Корвет' }],
	['205', { ru: 'Фрегат', uk: 'Фрегат' }],
	['206', { ru: 'Крейсер', uk: 'Крейсер' }],
	['207', { ru: 'Линкор', uk: 'Лінкор' }],
	['215', { ru: 'Линейный крейсер', uk: 'Лінійний крейсер' }],
	['211', { ru: 'Броненосец', uk: 'Броненосець' }],
	['216', { ru: 'Эсминец', uk: 'Есмінець' }],
	['213', { ru: 'Флагман', uk: 'Флагман' }],
	['217', { ru: 'Авианосец', uk: 'Авіаносець' }],
	['214', { ru: 'Сверхновая Звезда', uk: 'Наднова Зірка' }],
	['401', { ru: 'Зенитный комплекс', uk: 'Зенітний комплекс' }],
	['402', { ru: 'Лазерная установка', uk: 'Лазерна установка' }],
	['403', { ru: 'Фотонное орудие', uk: 'Фотонне знаряддя' }],
	['405', { ru: 'Излучатель Тесла', uk: 'Випромінювач Тесла' }],
	['404', { ru: 'Пушка Гаусса', uk: 'Гармата Гаусса' }],
	['406', { ru: 'Плазменное орудие', uk: 'Плазмове знаряддя' }],
	['407', { ru: 'Силовое поле', uk: 'Силове поле' }],
	['408', { ru: 'Щитовой купол', uk: 'Щитовий купол' }],
	['502', { ru: 'Ракета-перехватчик', uk: 'Ракета-перехоплювач' }],
	['503', { ru: 'Ядерная ракета', uk: 'Ядерна ракета' }],
	['41', { ru: 'Лунная база', uk: 'Місячна база' }],
	['42', { ru: 'Сенсорная станция', uk: 'Сенсорна станція' }],
	['43', { ru: 'Звездные врата', uk: 'Зоряна брама' }],
	['90', { ru: 'Адронный коллайдер', uk: 'Адронний колайдер' }]
];

// 8. ДОСТУПНЫЕ МОДУЛИ АВТОМАТИЗАЦИИ ДЛЯ НАСТРОЕК XAN
export const AVAILABLE_SCRIPTS = [
    ["imperium", { ru: "Модуль «Империя»", uk: "Модуль «Імперія»" }, { ru: "Всякие фичи страницы Империя", uk: "Усілякі фічі сторінки Імперія" }],
    ["fleet", { ru: "Модуль «Флот»", uk: "Модуль «Флот»" }, { ru: "Всякие фичи страниц Флот", uk: "Усілякі фічі сторінок Флот" }],
    ["galaxy", { ru: "Модуль «Галактика»", uk: "Модуль «Галактика»" }, { ru: "Список ботов, обновление списка и т.п.", uk: "Список ботів, оновлення списку тощо" }],
    ["buildings", { ru: "Модуль «Сооружения»", uk: "Модуль «Споруди»" }, { ru: "Скрытие/показ Сооружений, Исследований, Обороны и Флотов на Верфи", uk: "Приховування/показ Споруд, Досліджень, Оборони та Флотів на Верфі" }],
    ["cargo", { ru: "Модуль «Грузы»", uk: "Модуль «Вантажі»" }, { ru: "Сохранение, удаление и быстрая погрузка ресурсов", uk: "Збереження, видалення та швидке завантаження ресурсів" }],
	["phalanx", { ru: "Модуль «Фаланга»", uk: "Модуль «Фаланга»" }, { ru: "Инструменты Фаланги", uk: "Інструменти Фаланги" }],
	["user", { ru: "Модуль «Профиль»", uk: "Модуль «Профіль»" }, { ru: "Небольшой тюнинг страницы Профиль", uk: "Невеликий тюнінг сторінки Профіль" }],
	["notes", { ru: "Модуль «Заметки»", uk: "Модуль «Нотатки»" }, { ru: "Тюнинг страницы Заметки", uk: "Тюнінг сторінки Нотатки" }],
	["messages", { ru: "Модуль «Сообщения»", uk: "Модуль «Повідомлення»" }, { ru: "Тюнинг страницы Сообщения", uk: "Тюнінг сторінки Повідомлення" }],
	["harvester", { ru: "Тыквенный Комбайн", uk: "Гарбузовий Комбайн" },  { ru: "Автоматический запуск переработчиков для сбора ивентовых тыкв", uk: "Автоматичний запуск переробників для збору івентових гарбузів"}],
	["auto_expa", { ru: "Автоэкспа", uk: "Автоекспа" },  { ru: "Автоматический запуск Экспедиции", uk: "Автоматичний запуск Експедиції"}]
];

export const MENU_ALLOWED_PAGES = [
    { id: 'buildings', name: { ru: 'Сооружения, Исследования, Верфь, Оборона', uk: 'Споруди, Дослідження, Верф, Оборона' } },
    { id: 'fleet',     name: { ru: 'Флот, первая страница', uk: 'Флот, перша сторінка' } }
];

// ... для messages.js ...
// Справочники выработки шахт для расчетных формул

export const U_MINES = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1332,1544,1784,2055,2364,2712,3109,3557,4063,4635,5281,5863,6664,7567,8583.93,9728.42,11016.05,12463.81,14091.11,15919.13,17971.95,20276.05,22861.24,25760.84,29011.61,32654.93,36736.8,41308.49,46427.15,52155.3,58565.92,65737.43,73757.58,82724.36,92746.91,103946.71,116458.99,130434.24,146039.94,163462.42];
export const A_MINES = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3581,4118,4726,5417,6197,7079,8075,9200,10470,11900,13513,15328.56,17372.36,19671.67,22257.07,25162.87,28427.3,32092.87,36207.4,40823.84,46001.5,51806.45,58312.38,65601.43,73765.16,82905.63,93136.54,104584.57,117390.85,131712.53,147724.64,165622.05,185621.7,207965.05];
export const M_MINES = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7091,8125,9296,10619,12112,13800,15704,17850,20269,22991,26059,29507,33386,37744.29,42640.9,48139.29,54311.09,61235.77,69002.26,77709.68,87468.58,98402.15,110647.75,124358.45,139704.81,156876.87,176086.28,197568.8,221586.97,248433.08,278432.55,311947.58,349381.29,391182.27,437849.63,489938.63,548066.95,612921.54,685266.37,765950.96];
