// js/galaxy.js — Модуль страницы «Галактика» и трекинга Пришельцев
// ЧАСТЬ 1 ИЗ 3

import { _ } from './query.js';
import { nsn, spaces, isScriptActive } from './utils.js';
import { ALIENS_ORIGIN } from './game_data.js';

let HIDE_OTHERS, LIST_AUTOSCROLL, HIDE_OTHER_GALAXIES, LIST_AUTO_OPEN;
let LIST_SHOW_NUMBERS, COUNT_SCAN, SPIES, PHALANX_RANGE, UPD_PERIOD, CATEGORY_HLITE;
let MIN_STAT_POS, CURR_COORDS, CURR_SYS, CURR_PL, ALREADY_SCANNED;
let PHLANX_DIAPASON = 0, CCT = '';

// Переменные для хранения кастомных размеров окна
let SAVED_WIDTH, SAVED_HEIGHT;

export function initGalaxyModule() {
	const selectElem = document.querySelector('select');
	if (!selectElem) return;
	// Безопасный мультиязычный парсинг Луны (проверка по символу звёздочки)
	const isMoon = selectElem.options[selectElem.selectedIndex].textContent.endsWith('*');
	initSettings();
	
	if (!isMoon) {
		console.log('[XAN Galaxy] Вы находитесь не на Луне');
		return;
	}
	const container = _('#galaxy_form, .galaxy-table-selector');
	if (!container || container.data('xanGalaxyChecked')) return;
	container.data('xanGalaxyChecked', 'true');
	markAliensInGalaxyTable();
	showList();
}

function initSettings() {
	HIDE_OTHERS = parseInt(localStorage.xan3_aliensHideOthers || '0');
	LIST_AUTOSCROLL = parseInt(localStorage.xan3_aliensListAutoscroll || '1');
	HIDE_OTHER_GALAXIES = parseInt(localStorage.xan3_aliensHideOtherGalaxies || '1');
	LIST_AUTO_OPEN = parseInt(localStorage.xan3_aliensListAutoOpen || '0');
	LIST_SHOW_NUMBERS = parseInt(localStorage.xan3_aliensShowNumbers || '0');
	COUNT_SCAN = parseInt(localStorage.xan3_aliensCountScan || '0');
	CATEGORY_HLITE = localStorage.xan3_alienCategoryHlite || '0';
	UPD_PERIOD = parseInt(localStorage.xan3_aliensUpdatePeriod || '1');
	MIN_STAT_POS = parseInt(localStorage.xan3_IshkaMinStatPos || '1000');
	//const spiesRaw = localStorage.xan3_aliensSpies || '100';
	//SPIES = !spiesRaw.match(/[\d]{1,3}/g) ? 100 : parseInt(spiesRaw);
	//ALREADY_SCANNED = localStorage.xan3_aliensAlreadyScanned ? localStorage.xan3_aliensAlreadyScanned.split('|') : [];
	const spiesRaw = localStorage.xan3_aliensSpies || '100';
	SPIES = !spiesRaw.match(/[\d]{1,3}/g) ? 100 : parseInt(spiesRaw);
	const scanStorageKey = `xan3_aliensAlreadyScanned_${CATEGORY_HLITE}`;
	ALREADY_SCANNED = localStorage[scanStorageKey] ? localStorage[scanStorageKey].split('|') : [];


	SAVED_WIDTH = localStorage.xan3_panelWidth || '';
	SAVED_HEIGHT = localStorage.xan3_panelHeight || '';

	const currCoordsElem = document.querySelector('[title="Текущие координаты"], [title*="координат"]');
	if (currCoordsElem) {
		const rawText = currCoordsElem.textContent;
		const match = rawText.match(/\[(.*?)\]/);
		if (match && match[1]) {
			CURR_COORDS = match[1];
			const coordsParts = CURR_COORDS.split(':');
			if (coordsParts.length >= 2) CURR_SYS = parseInt(coordsParts[1]);
			CURR_PL = `${coordsParts[0]}_${coordsParts[1]}`;
		}
	}
	if (!CURR_COORDS) {
		CURR_COORDS = "1:1:1";
		CURR_SYS = 1;
		CURR_PL = "1_1";
	}

	const localRangeKey = 'xan3_phalanxRange_' + CURR_PL;
	PHALANX_RANGE = parseInt(localStorage[localRangeKey] || '50');
}

function coordsToVal(coords) {
	let raw = coords.substring(0, coords.lastIndexOf(':')).split(':');
	if (!raw || raw.length < 2) return 0;
	if (raw[1].length === 1) raw[1] = '00' + raw[1];
	else if (raw[1].length === 2) raw[1] = '0' + raw[1];
	return parseInt(raw.join(''));
}

function markAliensInGalaxyTable() {
	const players = _('[href^="user.php"]', true);
	if (!players || !players.length) return;
	const items = Object.entries(ALIENS_ORIGIN);
	players.forEach(x => {
		const txt = x.textContent.trim();
		const fnd = items.find(([name, data]) => name === txt);
		if (fnd) {
			const [name, data] = fnd;
			x.textContent = `[${data.category}] ${x.textContent}`;
		}
	});
}

function showList() {
	const body = document.body;
	if (!body) return;
	const headerMobile = document.querySelector('.header-mobile');
	const offsetLeft = headerMobile ? headerMobile.offsetLeft : 0;
	
	const defaultWidth = offsetLeft > 40 ? (offsetLeft - 20) : 310;
	const finalWidth = SAVED_WIDTH ? `${SAVED_WIDTH}px` : `${defaultWidth}px`;
	const finalHeight = SAVED_HEIGHT ? `${SAVED_HEIGHT}px` : '555px';

	let updPeriodOptionsHtml = '';
	for (let i = 1; i <= 24; i++) {
		const isSelected = (i === UPD_PERIOD) ? 'selected' : '';
		updPeriodOptionsHtml += `<option value="${i}" ${isSelected}>${i}</option>`;
	}
	const htmlSettings = `
		<span id="calc_phalanx_trigger" style="cursor:pointer;" title="${t('g_range_title')}">${t('g_range_systems')}</span> 
		<input type="text" id="diap" size="3" value="${PHALANX_RANGE}" class="xan-custom-input-select" /><br>
		<span title="${t('g_upd_title')}">${t('g_upd_period')}</span>
		<select id="update_period" class="xan-custom-input-select">${updPeriodOptionsHtml}</select><br>
		<span title="${t('g_hide_others_title')}">${t('g_hide_others')}</span> 
		<select id="hide_others" class="xan-custom-input-select">
			<option value="0" ${HIDE_OTHERS === 0 ? 'selected' : ''}>${t('g_no')}</option>
			<option value="1" ${HIDE_OTHERS === 1 ? 'selected' : ''}>${t('g_yes')}</option>
		</select><br>
		<span title="${t('g_autoscroll_title')}">${t('g_autoscroll')}</span> 
		<select id="list_autoscroll" class="xan-custom-input-select">
			<option value="0" ${LIST_AUTOSCROLL === 0 ? 'selected' : ''}>${t('g_no')}</option>
			<option value="1" ${LIST_AUTOSCROLL === 1 ? 'selected' : ''}>${t('g_yes')}</option>
		</select><br>
		<span title="${t('g_other_galaxies_title')}">${t('g_other_galaxies')}</span> 
		<select id="hide_other_galaxies" class="xan-custom-input-select">
			<option value="0" ${HIDE_OTHER_GALAXIES === 0 ? 'selected' : ''}>${t('g_no')}</option>
			<option value="1" ${HIDE_OTHER_GALAXIES === 1 ? 'selected' : ''}>${t('g_yes')}</option>
		</select><br>
		<span title="${t('g_category_title')}">${t('g_category')}</span> 
		<select id="category_hlite" class="xan-custom-input-select">
			<option value="0" ${CATEGORY_HLITE === '0' ? 'selected' : ''}>${t('g_all')}</option>
			<option value="1" ${CATEGORY_HLITE === '1' ? 'selected' : ''}>1</option>
			<option value="2" ${CATEGORY_HLITE === '2' ? 'selected' : ''}>2</option>
			<option value="3" ${CATEGORY_HLITE === '3' ? 'selected' : ''}>3</option>
			<option value="4" ${CATEGORY_HLITE === '4' ? 'selected' : ''}>4</option>
			<option value="5" ${CATEGORY_HLITE === '5' ? 'selected' : ''}>5</option>
		</select><br>
		<span title="${t('g_auto_open_title')}">${t('g_auto_open')}</span> 
		<select id="auto_open" class="xan-custom-input-select">
			<option value="0" ${LIST_AUTO_OPEN === 0 ? 'selected' : ''}>${t('g_no')}</option>
			<option value="1" ${LIST_AUTO_OPEN === 1 ? 'selected' : ''}>${t('g_yes')}</option>
		</select><br>
		<span title="${t('g_show_numbers_title')}">${t('g_show_numbers')}</span> 
		<select id="show_numbers" class="xan-custom-input-select">
			<option value="0" ${LIST_SHOW_NUMBERS === 0 ? 'selected' : ''}>${t('g_no')}</option>
			<option value="1" ${LIST_SHOW_NUMBERS === 1 ? 'selected' : ''}>${t('g_yes')}</option>
		</select><br>
		<span title="${t('g_count_scan_title')}">${t('g_count_scan')}</span> 
		<select id="count_scan" class="xan-custom-input-select">
			<option value="0" ${COUNT_SCAN === 0 ? 'selected' : ''}>${t('g_no')}</option>
			<option value="1" ${COUNT_SCAN === 1 ? 'selected' : ''}>${t('g_yes')}</option>
		</select><br>
		<span title="${t('g_spies_title')}">${t('g_spies')}</span> 
		<input id="spies" type="text" min="1" size="3" value="${SPIES}" class="xan-custom-input-select" /><br>
		<span title="${t('g_ishka_title')}">${t('g_ishka')}</span> 
		<input id="minStatPos" type="text" size="4" value="${MIN_STAT_POS}" class="xan-custom-input-select" /><br><br>
		<div id="forced_update" class="xan-btn-update" title="${t('g_btn_forced_update_title')}">${t('g_btn_forced_update')}</div>
		<input type="button" value="${t('g_btn_save')}" id="save_list_settings" title="${t('g_btn_save_title')}" class="xan-custom-input-select" />
	`;
  // js/galaxy.js — ЧАСТЬ 2 ИЗ 3

	const alienBgUrl = chrome.runtime.getURL('images/alien-128-128.png');
	const alien1BgUrl = chrome.runtime.getURL('images/alien1-128-128.png');
	body.insertAdjacentHTML('beforeend', `
		<input id="go" type="button" value="${t('g_show_aliens')}" class="xan-custom-input-select" />
		<input id="set_but" type="button" value="${t('g_settings')}" class="xan-custom-input-select" />
		<div id="result" style="width: ${finalWidth}; height: ${finalHeight}; background-image: url('${alienBgUrl}');" class="xan-aliens-result-panel">
			<div id="outdated" class="xan-outdated-alert">
				${t('g_outdated_msg')}<br><br>
				<input id="refresh" type="button" value="${t('g_btn_refresh')}" class="xan-custom-input-select" />
				<div id="tempdiv"></div><br><br>
			</div>
			<div id="list" style="width: 100%;"></div>
		</div>
		<div id="list_settings" style="background-image: url('${alien1BgUrl}');" class="xan-aliens-settings-panel">${htmlSettings}</div>
	`);
	
	const resultPanelNode = document.getElementById('result');
	if (resultPanelNode) {
		let resizeTimeout;
		const resizeObserver = new ResizeObserver(entries => {
			for (let entry of entries) {
				clearTimeout(resizeTimeout);
				resizeTimeout = setTimeout(() => {
					const width = Math.round(entry.contentRect.width);
					const height = Math.round(entry.contentRect.height);
					if (width > 0 && height > 0 && resultPanelNode.style.display !== 'none') {
						localStorage.xan3_panelWidth = width;
						localStorage.xan3_panelHeight = height;
					}
				}, 150);
			}
		});
		resizeObserver.observe(resultPanelNode);
	}

	_('#forced_update')?.on('click', () => {
		const outdatedBlockNode = document.getElementById('outdated');
		if (outdatedBlockNode) {
			const currentDisp = outdatedBlockNode.style.display || 'none';
			outdatedBlockNode.style.display = currentDisp === 'none' ? 'block' : 'none';
		}
	});
	const setButNode = document.getElementById('set_but');
	const listSettingsNode = document.getElementById('list_settings');
	if (setButNode && listSettingsNode) {
		setButNode.addEventListener('click', () => {
			listSettingsNode.style.display = listSettingsNode.style.display === 'block' ? 'none' : 'block';
		});
	}
	_('#refresh')?.on('click', () => {
		localStorage.xan3_aliensList = '';
		syncAlienCoordinates('tempdiv');
	});
	_('#save_list_settings')?.on('click', () => {
		const localRangeKey = 'xan3_phalanxRange_' + CURR_PL;
		localStorage[localRangeKey] = document.getElementById('diap')?.value || '50';
		localStorage.xan3_aliensHideOthers = document.getElementById('hide_others')?.value || '0';
		localStorage.xan3_aliensUpdatePeriod = document.getElementById('update_period')?.value || '1';
		localStorage.xan3_aliensListAutoscroll = document.getElementById('list_autoscroll')?.value || '1';
		localStorage.xan3_aliensHideOtherGalaxies = document.getElementById('hide_other_galaxies')?.value || '1';
		localStorage.xan3_alienCategoryHlite = document.getElementById('category_hlite')?.value || '0';
		localStorage.xan3_IshkaMinStatPos = document.getElementById('minStatPos')?.value || '1000';
		localStorage.xan3_aliensListAutoOpen = document.getElementById('auto_open')?.value || '0';
		localStorage.xan3_aliensShowNumbers = document.getElementById('show_numbers')?.value || '0';
		localStorage.xan3_aliensSpies = document.getElementById('spies')?.value || '100';
		localStorage.xan3_aliensCountScan = document.getElementById('count_scan')?.value || '0';
		setTimeout(() => location.reload(), 500);
	});

	_('#calc_phalanx_trigger')?.on('click', () => {
		console.log('[XAN Phalanx] Ручной сбор охвата фаланги по селекторам XGame...');
		fetch('buildings.php?gid=42')
			.then(res => res.text())
			.then(html => {
				const parser = new DOMParser();
				const doc = parser.parseFromString(html, 'text/html');
				const yellowElems = doc.querySelectorAll('[style="color: yellow"]');
				const baseRangeText = yellowElems.length > 1 ? yellowElems[1].textContent : '0';
				const baseRange = nsn(baseRangeText);
				const allSpans = Array.from(doc.querySelectorAll('span'));
				const planetarkaSpan = allSpans.find(x => (x.textContent || '').includes('+'));
				let planetarka = 0;
				if (planetarkaSpan) {
					const cleanPlanetarkaText = planetarkaSpan.textContent.replace('+', '').trim();
					planetarka = nsn(cleanPlanetarkaText);
				}
				const calculatedRange = baseRange + planetarka;
				if (calculatedRange > 0) {
					const diapInput = document.getElementById('diap');
					if (diapInput) {
						diapInput.value = calculatedRange;
						PHALANX_RANGE = calculatedRange;
						localStorage['xan3_phalanxRange_' + CURR_PL] = calculatedRange; 
						console.log(`[XAN Galaxy] Охват фаланги успешно обновлен для луны ${CURR_PL}: ${calculatedRange} сист.`);
						initiateAliensStat();
					}
				} else {
					alert(t('g_range_err'));
				}
			})
			.catch(err => {
				console.error('[XAN Phalanx] Ошибка сбора данных фаланги:', err);
				alert(t('g_conn_err'));
			});
	});

	initiateAliensStat();
}
// js/galaxy.js — ЧАСТЬ 3.1 (Продолжение функции initiateAliensStat)

function initiateAliensStat() {
	let aliens = [];
	if (!localStorage.xan3_aliensList) {
		const now = new Date();
		let temp = Object.entries(ALIENS_ORIGIN).map(([name, data]) => {
			return `${name},${data.defaultCoords},${data.category},${data.index}`;
		}).join(';') + ';';
		temp += now.getTime();
		localStorage.xan3_aliensList = temp;
		initiateAliensStat();
		return;
	}
	const rawData = localStorage.xan3_aliensList;
	const lastSemi = rawData.lastIndexOf(';');
	if (lastSemi === -1) {
		localStorage.removeItem('xan3_aliensList');
		setTimeout(() => location.reload(), 100);
		return;
	}
	const timestamp = parseInt(rawData.substring(lastSemi + 1)) || 0;
	const arr = rawData.substring(0, lastSemi).split(';');
	const now = new Date();
	const timediff = Math.round((now.getTime() - timestamp) / 1000 / 60 / 60);
	if (timediff > UPD_PERIOD) {
		_('#outdated')?.show('block');
	}
	arr.forEach(str => {
		if (str) aliens.push(str.split(','));
	});
	const listContainer = document.getElementById('list');
	if (!listContainer) return;
	listContainer.innerHTML = '';
	aliens.forEach(alien => {
		if (alien.length < 4) return;
		const name = alien[0];
		const coordsStr = alien[1];
		const cat = alien[2];
		const botNum = alien[3];
		const gal = coordsStr.substring(1, coordsStr.indexOf(':'));
		const sys = coordsStr.substring(coordsStr.indexOf(':') + 1, coordsStr.lastIndexOf(':'));
		const pl = coordsStr.substring(coordsStr.lastIndexOf(':') + 1, coordsStr.lastIndexOf(']'));
		const diff = coordsToVal(`${gal}:${sys}:${pl}`) - coordsToVal(CURR_COORDS);
		const distance = Math.abs(diff);
		const isNear = distance <= PHALANX_RANGE;

		if (HIDE_OTHER_GALAXIES === 1 && gal.trim() !== CURR_COORDS.split(':')[0].trim()) return;
		if (CATEGORY_HLITE !== '0' && cat !== CATEGORY_HLITE) return;
		if (HIDE_OTHERS === 1 && !isNear) return;

		const showNumbersText = LIST_SHOW_NUMBERS !== 0 ? botNum : '';
		const isInPhalanxRange = distance <= PHLANX_DIAPASON;
		const phalanxTitleSubtitle = isInPhalanxRange ? t('g_distance_title').replace('{dist}', distance).replace('{phalanx}', `\nОхват данной фалы ${PHLANX_DIAPASON} систем(ы)`) : ` Расстояние: ${distance} систем(ы) `;
		const itemHtml = `
			<div class="xan-alien-row" data-distance="${distance}" title="${phalanxTitleSubtitle}">
				${ isNear ? `<img class="xan-alien-marker" src="${chrome.runtime.getURL('images/near.png')}" title="${t('g_near_title').replace('{range}', PHALANX_RANGE)}" />` : '' } 
				<span class="inact xan-alien-name"> ${name} </span>
				<a href="galaxy.php?mode=3&galaxy=${gal}&system=${sys}&planet=${pl}&player=${encodeURIComponent(name)}" class="xan-alien-coords-link"> ${coordsStr} </a>
				<span class="xan-alien-action xan-action-phalanx" data-gal="${gal}" data-sys="${sys}" data-pl="${pl}" title="${t('g_scan_title')}">⍟</span>
				<span class="xan-alien-category-badge" data-cat="${cat}" title="${t('g_cat_title').replace('{cat}', cat)}">[ ${cat} ]</span>
				<span class="xan-alien-action xan-action-spy-planet" data-gal="${gal}" data-sys="${sys}" data-pl="${pl}" title="${t('g_spy_planet_title')}">☆</span>
				<span class="xan-alien-action xan-action-spy-moon" data-gal="${gal}" data-sys="${sys}" data-pl="${pl}" title="${t('g_spy_moon_title')}">★</span>
				<span class="xan-alien-bot-number" title="${t('g_bot_num_title')}"> ${showNumbersText} </span>
			</div>
		`;
		listContainer.insertAdjacentHTML('beforeend', itemHtml);
	});
	if (HIDE_OTHERS === 0 && CATEGORY_HLITE !== '0') {
		const totalInCat = aliens.filter(n => n[2] === CATEGORY_HLITE).length;
		const shownInCat = document.querySelectorAll(`[data-cat="${CATEGORY_HLITE}"]`).length;
		listContainer.insertAdjacentHTML('beforeend', `
			<div class="xan-category-counter">${t('g_total_aliens').replace('{total}', totalInCat).replace('{shown}', shownInCat)}</div>
		`);
	}
	bindAlienActions(listContainer);
	const goBtnNode = document.getElementById('go');
	const resultNode = document.getElementById('result');
	if (goBtnNode && resultNode && !goBtnNode.dataset.xanClickAttached) {
		goBtnNode.dataset.xanClickAttached = 'true';
		goBtnNode.addEventListener('click', () => {
			const currentDisp = resultNode.style.display;
			if (currentDisp === 'none' || !currentDisp) {
				resultNode.style.display = 'block';
				goBtnNode.value = t('g_hide_aliens');
				if (LIST_AUTOSCROLL === 1) {
					setTimeout(() => {
						const chosenNode = document.getElementById('chosen');
						if (chosenNode) chosenNode.scrollIntoView({ behavior: 'smooth', block: 'center' });
					}, 100);
				}
			} else {
				resultNode.style.display = 'none';
				goBtnNode.value = t('g_show_aliens');
			}
		});
	}
	handleUrlPlayerHighlight();
	handleScanMonitoring();
}
// js/galaxy.js — ЧАСТЬ 3.2

function bindAlienActions(el) {
	if (!el || el.dataset.xanActionsAttached) return;
	el.dataset.xanActionsAttached = 'true';
	
	el.addEventListener('click', (e) => {
		const target = e.target;
		if (!target || !target.classList.contains('xan-alien-action')) return;
		const gal = target.dataset.gal;
		const sys = target.dataset.sys;
		const pl = target.dataset.pl;
		
		if (target.classList.contains('xan-action-phalanx')) {
			const targetUrl = `phalanx.php?galaxy=${gal}&system=${sys}&planet=${pl}`;
			const winName = `xan_phalanx_${gal}_${sys}_${pl}`;
			const newWin = window.open(targetUrl, winName, 'resizable=yes,scrollbars=yes,menubar=no,toolbar=no,width=600,height=330,top=0,left=0');
			if (newWin) {
				newWin.focus();
				target.style.color = '#ffcc00';
				target.style.textShadow = '0 0 5px #ffcc00';
			}
		} else if (target.classList.contains('xan-action-spy-planet') || target.classList.contains('xan-action-spy-moon')) {
			const planetType = target.classList.contains('xan-action-spy-planet') ? 1 : 3;
			const formData = new URLSearchParams();
			formData.append('mission', '6');
			formData.append('galaxy', gal);
			formData.append('system', sys);
			formData.append('planet', pl);
			formData.append('planettype', planetType);
			formData.append('ship210', SPIES.toString());
			
			console.log(`[XAN Spy] Нативная отправка ${SPIES} шпиков на [${gal}:${sys}:${pl}] тип ${planetType}`);
			
			fetch('flotenajax.php?action=send', {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: formData.toString()
			})
			.then(res => res.text())
			.then(responseHtml => {
				console.log('[XAN Spy] Ответ сервера получен:', responseHtml);
				target.style.color = '#00ffcc';
				target.style.textShadow = '0 0 5px #00ffcc';
			})
			.catch(err => console.error('[XAN Spy] Ошибка сети при шпионаже:', err));
		}
	});
}

function handleUrlPlayerHighlight() {
	const urlParams = new URLSearchParams(location.search);
	const playerParam = urlParams.get('player');
	if (!playerParam) {
		if (LIST_AUTO_OPEN === 1) {
            const goBtn = document.getElementById('go');
            if (goBtn) goBtn.click();
        }
		return;
	}
	const decodedPlayer = decodeURIComponent(playerParam);
	const allNames = document.querySelectorAll('#list .xan-alien-name');
	allNames.forEach(el => {
		el.classList.remove('act');
		el.classList.add('inact');
	});
	let targetFound = false;
	allNames.forEach(el => {
		if (el.textContent.trim() === decodedPlayer) {
			el.classList.remove('inact');
			el.classList.add('act');
			el.setAttribute('id', 'chosen');
			targetFound = true;
		}
	});
	if (targetFound && LIST_AUTO_OPEN === 0) {
		setTimeout(() => {
			const goBtn = document.getElementById('go');
			if (goBtn) goBtn.click();
		}, 300);
	} else if (LIST_AUTO_OPEN === 1) {
		const goBtn = document.getElementById('go');
		if (goBtn) goBtn.click();
	}
}

function handleScanMonitoring() {
	if (COUNT_SCAN === 0 || CATEGORY_HLITE === '0') return;
	const scanStorageKey = `xan3_aliensAlreadyScanned_${CATEGORY_HLITE}`;
	let alreadyScanned = new Set(ALREADY_SCANNED);
	const phalanxButtons = Array.from(document.querySelectorAll('#list .xan-action-phalanx'))
		.filter(btn => btn.closest('.xan-alien-row').style.display !== 'none');
	const listContainer = document.getElementById('list');
	if (!listContainer) return;

	const attachDelHandler = () => {
		const delBtn = document.getElementById('del_scans');
		if (delBtn && !delBtn.dataset.xanDelAttached) {
			delBtn.dataset.xanDelAttached = 'true';
			delBtn.addEventListener('click', () => {
				localStorage.removeItem(scanStorageKey);
				location.reload();
			});
		}
	};

	const delButtonHtml = alreadyScanned.size > 0 
		? `&nbsp;&nbsp;<input type="button" id="del_scans" value="Del" class="xan-custom-input-select xan-btn-del" title="${t('g_btn_del_title')}">` 
		: '';
	listContainer.insertAdjacentHTML('beforeend', `<br><br><span id="count_scan_disp" title="${phalanxButtons.length}">${t('g_scanned_count').replace('{count}', alreadyScanned.size)}</span>${delButtonHtml}`);
	attachDelHandler();

	const rows = document.querySelectorAll('#list .xan-alien-row');
	rows.forEach(row => {
		const nameElem = row.querySelector('.xan-alien-name');
		if (nameElem && alreadyScanned.has(nameElem.textContent.trim())) {
			_(nameElem).removeCls('inact').addCls('act');
		}
	});
	phalanxButtons.forEach(btn => {
		if (btn.dataset.xanMouseupAttached) return;
		btn.dataset.xanMouseupAttached = 'true';
		_(btn).on('mouseup', function(e) {
			if (e && e.button !== 0) return;
			const row = this.closest('.xan-alien-row');
			const nameElem = row?.querySelector('.xan-alien-name');
			if (nameElem) {
				const botName = nameElem.textContent.trim();
				alreadyScanned.add(botName);
				localStorage[scanStorageKey] = Array.from(alreadyScanned).join('|');
				_(nameElem).removeCls('inact').addCls('act');
				const dispCounter = _('#count_scan_disp');
				if (dispCounter) {
					dispCounter.html(`${t('g_scanned_count').replace('{count}', alreadyScanned.size)}`);
					if (alreadyScanned.size > 0 && !document.getElementById('del_scans')) {
						//dispCounter.after(`&nbsp;&nbsp;<input type="button" id="del_scans" value="Del" class="xan-custom-input-select xan-btn-del" title="${t('g_btn_del_title')}">`);
						document.getElementById('count_scan_disp')?.insertAdjacentHTML('afterend', `&nbsp;&nbsp;<input type="button" id="del_scans" value="Del" class="xan-custom-input-select xan-btn-del" title="${t('g_btn_del_title')}">`);
						attachDelHandler();
					}
				}
			}
		});
	});
}

// js/galaxy.js — ЧАСТЬ 3.3 (ФИНАЛ МОДУЛЯ)

export async function syncAlienCoordinates(targid) {
	const outputElem = _('#' + targid);
	if (!outputElem) return;
	console.log(`[XAN Galaxy] Запущена синхронизация координат. Всего ботов: ${Object.keys(ALIENS_ORIGIN).length}`);
	let updateBuffer = '';
	const items = Object.entries(ALIENS_ORIGIN);
	const parser = new DOMParser();
	for (let i = 0; i < items.length; i++) {
		const [username, data] = items[i];
		const category = data.category;
		const botId = data.index;
		const defaultCoords = data.defaultCoords;
		outputElem.html(`<div class="xan-sync-progress"><span class="xan-sync-counter">${items.length - i}</span><br><br><span class="xan-sync-warn">${t('g_sync_warn')}</span></div>`);
		let retry = true;
		let attempts = 0;
		let coordsSaved = false;
		while (retry && attempts < 3) {
			try {
				attempts++;
				const response = await fetch('rating.php', {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: `type=playername&searchtext=${encodeURIComponent(username)}`
				});
				if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
				const htmlText = await response.text();
				const doc = parser.parseFromString(htmlText, 'text/html');
				const headers = Array.from(doc.querySelectorAll('th'));
				const foundTh = headers.find(th => th.textContent.trim() === username);
				if (foundTh) {
					let targetTd = foundTh.nextElementSibling;
					for (let step = 0; step < 3; step++) {
						if (targetTd) targetTd = targetTd.nextElementSibling;
					}
					if (targetTd && targetTd.textContent.trim()) {
						const extractedCoords = targetTd.textContent.trim();
						updateBuffer += `${username},${extractedCoords},${category},${botId};`;
						coordsSaved = true;
					}
				}
				retry = false;
			} catch (err) {
				console.error(`[XAN Sync] Ошибка запроса для ${username}:`, err);
				await new Promise(resolve => setTimeout(resolve, 1000));
			}
		}
		if (!coordsSaved) {
			console.warn(`[XAN Sync] Используются дефолтные координаты для игрока ${username}.`);
			updateBuffer += `${username},${defaultCoords},${category},${botId};`;
		}
		await new Promise(resolve => setTimeout(resolve, 300));
	}
	const now = new Date();
	updateBuffer += now.getTime();
	localStorage.xan3_aliensList = updateBuffer;
	outputElem.html(`<span class="xan-sync-complete">${t('g_sync_complete')}</span>`);
	setTimeout(() => location.reload(), 800);
}
