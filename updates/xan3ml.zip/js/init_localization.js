// js/init_localization.js — Синхронная инициализация языка и глобальных хелперов перевода

(function() {
    // 1. Получаем выбранный язык из изолированного LocalStorage XAN v3.0 (по умолчанию 'ru')
    const savedLang = localStorage.getItem('xan3_app_lang');
    window.currentLang = savedLang === 'uk' ? 'uk' : 'ru';

    // 2. Инициализируем пустой словарь для статических строк (он наполнится в js/lang_dict.js)
    window.LANG_DICT = window.LANG_DICT || {};

    /**
     * t("key") — Синхронный перевод статических строк интерфейса расширения
     * @param {string} key - Ключ строки из словаря LANG_DICT
     * @returns {string} - Переведенная строка или сам ключ, если перевод не найден
     */
    window.t = function(key) {
        return window.LANG_DICT?.[window.currentLang]?.[key] || key;
    };

    /**
     * _t(obj) — Синхронный перевод динамических объектов игры из game_data.js
     * @param {Object} textObj - Объект вида { ru: "Строка", uk: "Рядок" }
     * @returns {string} - Строка на текущем языке, либо откат на 'ru', либо пустая строка
     */
    window._t = function(textObj) {
        if (!textObj) return '';
        return textObj[window.currentLang] || textObj['ru'] || '';
    };
})();
