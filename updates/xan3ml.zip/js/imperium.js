// js/imperium.js — фичи страницы Империя

import { _ } from './query.js';

export function initImperiumPage() {
    console.log("[Game Guard] Модуль 'Империя' удачно запущен");

    // ==========================================
    // 1. СОРТИРОВКА ИССЛЕДОВАНИЙ (ТАБЛИЦА №2)
    // ==========================================
    const allCellsInTable = _('table tr td, table tr th', true);
    const allTargetedCells = Array.from(allCellsInTable).filter(cell => {
        const hasLink = cell.querySelector('a[href*="mode=research"]') !== null;
        const isHeader = cell.getAttribute('colspan') && parseInt(cell.getAttribute('colspan'), 10) > 1;
        return hasLink && !isHeader;
    });

    if (allTargetedCells.length > 0) {
        const parserContainer = document.createElement('div');

        const globalSortedHTMLs = allTargetedCells
            .map(cell => cell.innerHTML)
            .sort((a, b) => {
                parserContainer.innerHTML = a;
                const textA = parserContainer.textContent.trim();
                
                parserContainer.innerHTML = b;
                const textB = parserContainer.textContent.trim();
                
                return textA.localeCompare(textB);
            });

        parserContainer.innerHTML = '';

        allTargetedCells.forEach((cell, index) => {
            cell.innerHTML = globalSortedHTMLs[index];
        });
        console.log("[Game Guard] Сортировка исследований успешно выполнена");
    }

    // ==========================================
    // 2. ПОДСВЕТКА КОЛОНКИ И ТАЙТЛЫ (ТАБЛИЦА №1)
    // ==========================================
    
    // Ищем оранжевую ссылку на активную планету
    const allLinks = document.querySelectorAll('table a');
    const currentPlanetLink = Array.from(allLinks).find(link => {
        const color = link.style.color || '';
        return color.toLowerCase() === 'orange';
    });
    
    if (currentPlanetLink) {
        const mainTable = currentPlanetLink.closest('table');
        
        if (mainTable) {
            const cell = currentPlanetLink.closest('td, th');
            const headerRow = cell.parentNode;
            
            // Находим точный индекс колонки текущей планеты
            const columnIndex = Array.from(headerRow.children).indexOf(cell);
            
            // Собираем имена планет для тайтлов
            const planetNames = Array.from(headerRow.children).map(el => {
                const link = el.querySelector('a');
                return link ? link.textContent.trim() : '';
            });

            const mainRows = mainTable.querySelectorAll('tr');
            
            // Флаг-триггер для тайтлов
            let canSetTitles = false;

            mainRows.forEach(row => {
                // Проверяем, является ли строка разделителем или шапкой (имеет ли хоть одна ячейка colspan)
                const hasColspan = Array.from(row.children).some(el => el.hasAttribute('colspan'));

                // А. Подсветка колонки — красим ТОЛЬКО обычные строки данных (без colspan)
                if (!hasColspan) {
                    const targetCell = row.children[columnIndex];
                    if (targetCell) {
                        targetCell.classList.add('xan-current-planet-col');
                        // Железобетонный инлайн-окрас (перебьет любые стили игры и css-баги)
                        targetCell.style.backgroundColor = '#456181'; 
                    }
                }

                // Б. Проверка на строку-разделитель "Флот" для переключения триггера тайтлов
                const fleetLink = row.querySelector('a[href*="mode=fleet"]');
                if (hasColspan && fleetLink) {
                    canSetTitles = true; 
                    return; // Саму строку-разделитель "Флот" пропускаем
                }

                // В. Если триггер активен — обрабатываем тайтлы для строк без colspan
                if (canSetTitles && !hasColspan) {
                    const firstCell = row.children[0];
                    if (!firstCell) return;

                    const rowTitle = firstCell.textContent.trim();
                    const linksInRow = row.querySelectorAll('a');

                    linksInRow.forEach(link => {
                        const linkText = link.textContent.trim();
                        
                        if (/\d+/g.test(linkText)) {
                            const parentCell = link.closest('td, th');
                            if (parentCell) {
                                const currentCellIndex = Array.from(parentCell.parentNode.children).indexOf(parentCell);
                                const planetName = planetNames[currentCellIndex] || '';
                                
                                if (planetName && rowTitle !== planetName) {
                                    link.setAttribute('title', `${rowTitle} (${planetName})`);
                                }
                            }
                        } else {
                            link.removeAttribute('title');
                        }
                    });
                }
            });
            console.log("[Game Guard] Подсветка колонки планеты и точечные тайтлы успешно применены");
        }
    } else {
        console.log("[Game Guard] Оранжевая ссылка текущей планеты в Таблице №1 не найдена");
    }
}
