// js/user.js — Страница Профиль

import { _ } from './query.js';

export function initUserPage() {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => initUserPage());
        return;
    }

    const userLink = document.querySelector('[href*="user.php"]');
    if (!userLink) return;
    
    const cell = userLink.textContent.trim();
    const researchImages = document.querySelectorAll('.research-img');

    researchImages.forEach(el => {
        if (el.querySelector('[src*="/medals/"]')) return;

        const anchor = el.querySelector('a');
        if (!anchor) return;

        let tt = anchor.getAttribute('onmouseover') || anchor.getAttribute('title') || '';
        
        if (!tt && anchor.onmouseover) {
            tt = anchor.onmouseover.toString();
        }

        if (typeof tt !== 'string' || !tt) return;

        if (tt.includes(cell)) {
            el.setAttribute('data-icon', '2');

            const innerImg = el.querySelector('img');
            if (innerImg) {
                const targetSrc = innerImg.getAttribute('src');
                const fixedTable = document.querySelector('table.fixed');
                
                if (fixedTable) {
                    const tableImg = fixedTable.querySelector(`[src="${targetSrc}"]`);
                    if (tableImg) {
                        tableImg.setAttribute('data-icon', '1');
                    }
                }
            }
        }

        // Внедрено: Мультиязычный поиск ключевых токенов тултипа игры
        const wordAmount = t('u_amount');
        const wordEach = t('u_each');

        if (tt.includes(wordAmount)) {
            const startIdx = tt.indexOf(wordAmount);
            const endIdx = tt.indexOf(wordEach);
            
            if (startIdx !== -1 && endIdx !== -1) {
                const subStr = tt.substring(startIdx, endIdx);
                const stt = subStr.replace(/[^\d]+/ig, '');

                if (stt) {
                    if (!el.querySelector('.inf')) {
                        const span = document.createElement('span');
                        span.className = 'inf';
                        span.textContent = stt;

                        if (parseInt(stt, 10) === 9) {
                            span.classList.add('inf-max');
                        }

                        el.appendChild(span);
                    }
                }
            }
        }
    });
}
