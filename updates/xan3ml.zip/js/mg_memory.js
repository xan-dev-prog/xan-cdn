// js/mg_memory.js — Автоматическое решение мини-игры «Память» (4x4)

import { getRandomInt } from './utils.js';
import { createMinigameControlBar, isMinigameOver, sleep } from './mini_games.js';

export function initMemoryGame(form) {
    const cells = Array.from(form.querySelectorAll('.space th.cell'));
    if (cells.length !== 16 || isMinigameOver()) return;

    let isRunning = false;
    let stopRequested = false;

    const ui = createMinigameControlBar(
        form,
        () => startSolving(),
        () => { stopRequested = true; }
    );

    const isCellClosed = (cell) => !cell.getAttribute('opened');

    const getCellImage = (cell) => {
        const bg = (cell.style.backgroundImage || '').trim();
        return bg && bg !== 'none' ? bg : '';
    };

    async function clickAndWaitReveal(cell) {
        if (stopRequested || isMinigameOver()) return null;

        const existingImg = getCellImage(cell);
        if (existingImg) return existingImg;

        let waitUnlock = 0;
        while (cell.getAttribute('opened') && !getCellImage(cell) && waitUnlock < 1200) {
            await sleep(40);
            waitUnlock += 40;
        }

        cell.click();

        const start = Date.now();
        while (Date.now() - start < 5000) {
            if (stopRequested || isMinigameOver()) return null;
            const img = getCellImage(cell);
            if (img) return img;
            await sleep(35);
        }
        return null;
    }

    async function startSolving() {
        if (isRunning || isMinigameOver()) return;
        isRunning = true;
        stopRequested = false;
        ui.setRunningUI(true);
        ui.setStatus('Анализ поля...', '#58a6ff');

        const knownMap = new Map();
        const solvedIndices = new Set();

        const rememberCell = (idx, img) => {
            if (!img) return;
            if (!knownMap.has(img)) knownMap.set(img, new Set());
            knownMap.get(img).add(idx);
        };

        const findReadyPair = () => {
            for (const [, idxSet] of knownMap.entries()) {
                const unsolved = Array.from(idxSet).filter(i => !solvedIndices.has(i));
                if (unsolved.length >= 2) return [unsolved, unsolved];
            }
            return null;
        };

        const findNextUnknownIndex = () => {
            for (let i = 0; i < cells.length; i++) {
                if (solvedIndices.has(i) || !isCellClosed(cells[i])) continue;
                let alreadyKnown = false;
                for (const idxSet of knownMap.values()) {
                    if (idxSet.has(i)) {
                        alreadyKnown = true;
                        break;
                    }
                }
                if (!alreadyKnown) return i;
            }
            return -1;
        };

        try {
            let preOpenedIdx = -1;
            let preOpenedImg = '';

            cells.forEach((cell, idx) => {
                const img = getCellImage(cell);
                if (img) rememberCell(idx, img);
            });

            for (const [, idxSet] of knownMap.entries()) {
                if (idxSet.size === 2) {
                    idxSet.forEach(i => solvedIndices.add(i));
                } else if (idxSet.size === 1) {
                    const onlyIdx = Array.from(idxSet);
                    if (!isCellClosed(cells[onlyIdx])) {
                        preOpenedIdx = onlyIdx;
                        preOpenedImg = getCellImage(cells[onlyIdx]);
                    }
                }
            }

            while (!stopRequested && !isMinigameOver() && solvedIndices.size < 16) {
                if (preOpenedIdx !== -1) {
                    const pairSet = knownMap.get(preOpenedImg);
                    const partnerIdx = pairSet
                        ? Array.from(pairSet).find(i => i !== preOpenedIdx && !solvedIndices.has(i))
                        : undefined;

                    const secondIdx = partnerIdx !== undefined ? partnerIdx : findNextUnknownIndex();
                    if (secondIdx === -1) break;

                    await sleep(getRandomInt(140, 260));
                    const secondImg = await clickAndWaitReveal(cells[secondIdx]);
                    if (!secondImg) break;
                    rememberCell(secondIdx, secondImg);

                    if (secondImg === preOpenedImg) {
                        solvedIndices.add(preOpenedIdx);
                        solvedIndices.add(secondIdx);
                        ui.setStatus(`Найдено пар: ${solvedIndices.size / 2} / 8`, '#3fb950');
                    }
                    preOpenedIdx = -1;
                    preOpenedImg = '';
                    continue;
                }

                const readyPair = findReadyPair();
                if (readyPair) {
                    const [idxA, idxB] = readyPair;
                    ui.setStatus(`Собираем пару (${solvedIndices.size / 2 + 1}/8)...`, '#3fb950');

                    await sleep(getRandomInt(140, 250));
                    const imgA = await clickAndWaitReveal(cells[idxA]);
                    if (!imgA) break;

                    await sleep(getRandomInt(120, 220));
                    const imgB = await clickAndWaitReveal(cells[idxB]);
                    if (!imgB) break;

                    if (imgA === imgB) {
                        solvedIndices.add(idxA);
                        solvedIndices.add(idxB);
                        ui.setStatus(`Найдено пар: ${solvedIndices.size / 2} / 8`, '#3fb950');
                    }
                    continue;
                }

                const firstIdx = findNextUnknownIndex();
                if (firstIdx === -1) break;

                ui.setStatus(`Разведка поля (${solvedIndices.size / 2}/8)...`, '#58a6ff');
                await sleep(getRandomInt(150, 280));
                const firstImg = await clickAndWaitReveal(cells[firstIdx]);
                if (!firstImg) break;
                rememberCell(firstIdx, firstImg);

                const knownForFirst = Array.from(knownMap.get(firstImg) || [])
                    .find(i => i !== firstIdx && !solvedIndices.has(i));

                const secondIdx = knownForFirst !== undefined ? knownForFirst : findNextUnknownIndex();
                if (secondIdx === -1) break;

                await sleep(getRandomInt(130, 240));
                const secondImg = await clickAndWaitReveal(cells[secondIdx]);
                if (!secondImg) break;
                rememberCell(secondIdx, secondImg);

                if (firstImg === secondImg) {
                    solvedIndices.add(firstIdx);
                    solvedIndices.add(secondIdx);
                    ui.setStatus(`Найдено пар: ${solvedIndices.size / 2} / 8`, '#3fb950');
                }
            }

            if (stopRequested) {
                ui.setStatus('Остановлено пользователем', '#d29922');
            } else if (solvedIndices.size === 16 || isMinigameOver()) {
                ui.setStatus('Готово! Все пары открыты', '#3fb950');
            }
        } finally {
            isRunning = false;
            ui.setRunningUI(false);
        }
    }
}
