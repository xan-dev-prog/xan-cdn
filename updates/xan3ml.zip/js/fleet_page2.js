// js/fleet_page2.js — Подмодуль для второй страницы флота (Выбор координат)

import { _ } from './query.js';

export function initPage2() {
	// 1. Настраиваем поля координат (галактика, система, планета)
	const coordInputs = _('[name="galaxy"], [name="system"], [name="planet"]', true);
	coordInputs.forEach(input => {
		input.removeAttribute('size');
		input.classList.add('xan-coordinate-input'); // Ограничение ширины 25px из fleet.css
	});

	// 2. Автоматический выбор Луны (тип 3), если летим с планеты
	const firstSelect = _('select');
	if (firstSelect && !firstSelect.dataset.xanTargetChecked) {
		firstSelect.dataset.xanTargetChecked = 'true'; // Защита от Out of Memory

		const selectedOption = firstSelect.options[firstSelect.selectedIndex];
		if (selectedOption) {
			// Если в названии текущей локации НЕТ звездочки (*), значит это планета.
			// Автоматически целимся на Луну (значение 3)
			const isPlanet = selectedOption.text.indexOf('*') === -1;
			
			if (isPlanet) {
				const planetTypeSelect = _('select[name="planettype"]');
				if (planetTypeSelect) {
					planetTypeSelect.value = '3';
				}
			}
		}
	}
}
