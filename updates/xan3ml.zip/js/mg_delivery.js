// Таблицы трансформаций дорожных тайлов (7..13) по реальному спрайту mines.png:
// 7 (-280px): L+R (─)
// 8 (-320px): U+D (│)
// 9 (-360px): Cross (┼)
// 10 (-400px): D+L (┐) — вниз-влево
// 11 (-440px): U+L (┘) — вверх-влево
// 12 (-480px): U+R (└) — вверх-вправо
// 13 (-520px): D+R (┌) — вниз-вправо
const DB_TO_SPRITE = { 10: 11, 11: 10, 12: 13, 13: 12 };
const ROTATE_90    = { 7: 8, 8: 7, 9: 9, 10: 11, 11: 12, 12: 13, 13: 10 };
const FLIP_H       = { 7: 7, 8: 8, 9: 9, 10: 13, 11: 12, 12: 11, 13: 10 };


const TILE_DIRS_STR = {
    7: '0101',  // L+R
    8: '1010',  // U+D
    9: '1111',  // Cross
    10: '0011', // D+L (┐)
    11: '1001', // U+L (┘)
    12: '1100', // U+R (└)
    13: '0110'  // D+R (┌)
};

const DX = [0, 1, 0, -1];
const DY = [-1, 0, 1, 0];

let cachedBaseDb = null;

async function loadBaseDb() {
    if (cachedBaseDb) return cachedBaseDb;
    try {
        const url = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
            ? chrome.runtime.getURL('js/delivery_db.json')
            : 'js/delivery_db.json';
        const resp = await fetch(url);
        let raw = (await resp.text()).trim();
        if (!raw.startsWith('[')) raw = '[' + raw.replace(/,\s*$/, '') + ']';
        cachedBaseDb = JSON.parse(raw);
    } catch (e) {
        console.warn('[Delivery Helper] Не удалось загрузить delivery_db.json:', e);
        cachedBaseDb = [];
    }
    return cachedBaseDb;
}

function getCustomDb() {
    return new Promise((resolve) => {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['delivery_custom_db'], (res) => {
                resolve(Array.isArray(res.delivery_custom_db) ? res.delivery_custom_db : []);
            });
        } else {
            try {
                const local = JSON.parse(localStorage.getItem('delivery_custom_db') || '[]');
                resolve(Array.isArray(local) ? local : []);
            } catch (_) {
                resolve([]);
            }
        }
    });
}

function saveCustomDb(list) {
    return new Promise((resolve) => {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ delivery_custom_db: list }, resolve);
        } else {
            localStorage.setItem('delivery_custom_db', JSON.stringify(list));
            resolve();
        }
    });
}

function parseEntries(arr) {
    return (arr || []).map((str) => {
        const [x, y, id] = str.split(',').map(Number);
        return { x, y, id };
    });
}

function transformTemplate(tpl, symIndex, W, H, swapST) {
    const rot = symIndex % 4;
    const flip = symIndex >= 4;

    let curW = W;
    let curH = H;

    const transformPoint = (x, y, id, isTile) => {
        let nx = x, ny = y, nid = id;
		if (isTile && DB_TO_SPRITE[nid]) nid = DB_TO_SPRITE[nid];

        let w = W, h = H;

        if (flip) {
            nx = w - 1 - nx;
            if (isTile && FLIP_H[nid]) nid = FLIP_H[nid];
        }

        for (let r = 0; r < rot; r++) {
            const tx = h - 1 - ny;
            const ty = nx;
            nx = tx;
            ny = ty;
            const tmp = w;
            w = h;
            h = tmp;
            if (isTile && ROTATE_90[nid]) nid = ROTATE_90[nid];
        }

        if (!isTile && swapST) {
            if (nid === 4) nid = 5;
            else if (nid === 5) nid = 4;
        }

        return { x: nx, y: ny, id: nid, w, h };
    };

    const statics = parseEntries(tpl.static).map((p) => transformPoint(p.x, p.y, p.id, false));
    const tiles   = parseEntries(tpl.tiles).map((p) => transformPoint(p.x, p.y, p.id, true));

    if (statics.length > 0) {
        curW = statics[0].w;
        curH = statics[0].h;
    }

    return { statics, tiles, W: curW, H: curH };
}

function findTemplateMatch(boardStatic, W, H, db) {
    const targetMap = new Map();
    for (const s of boardStatic) {
        targetMap.set(`${s.x},${s.y}`, s.id);
    }

    for (const tpl of db) {
        const rawStatic = parseEntries(tpl.static);
        if (rawStatic.length !== boardStatic.length) continue;

        let tplW = 8, tplH = 8;
        for (const p of [...rawStatic, ...parseEntries(tpl.tiles)]) {
            if (p.x >= 8) tplW = 9;
            if (p.y >= 8) tplH = 9;
        }

        for (let sym = 0; sym < 8; sym++) {
            for (const swapST of [false, true]) {
                const tr = transformTemplate(tpl, sym, tplW, tplH, swapST);
                if (tr.W !== W || tr.H !== H) continue;

                let ok = true;
                for (const p of tr.statics) {
                    if (targetMap.get(`${p.x},${p.y}`) !== p.id) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    return {
                        name: tpl.name + (sym > 0 ? `_sym${sym}` : '') + (swapST ? '_inv' : ''),
                        tiles: tr.tiles
                    };
                }
            }
        }
    }
    return null;
}

function solveFallback(boardStatic, W, H, inventoryCounts) {
    const grid = Array.from({ length: H }, () => Array(W).fill(0));
    const mines = [];
    const solars = [];
    const transports = [];

    for (const s of boardStatic) {
        grid[s.y][s.x] = s.id;
        if (s.id >= 1 && s.id <= 3) mines.push(s);
        else if (s.id === 4) solars.push(s);
        else if (s.id === 5) transports.push(s);
    }

    if (!mines.length || !solars.length || !transports.length) return null;

    const inv = { ...inventoryCounts };
    const placed = [];

    function bfsPath(start, targets) {
        const q = [{ x: start.x, y: start.y }];
        const parent = new Map();
        const key = (x, y) => `${x},${y}`;
        parent.set(key(start.x, start.y), null);
        const targetKeys = new Set(targets.map((t) => key(t.x, t.y)));

        while (q.length) {
            const cur = q.shift();
            const ck = key(cur.x, cur.y);
            if (targetKeys.has(ck) && ck !== key(start.x, start.y)) {
                const path = [];
                let step = ck;
                while (step) {
                    const [px, py] = step.split(',').map(Number);
                    path.push({ x: px, y: py });
                    step = parent.get(step);
                }
                return path.reverse();
            }

            for (let d = 0; d < 4; d++) {
                const nx = cur.x + DX[d];
                const ny = cur.y + DY[d];
                if (nx < 0 || nx >= W || ny < 0 || ny >= H) continue;
                const nk = key(nx, ny);
                if (parent.has(nk)) continue;
                const cell = grid[ny][nx];
                if (cell === 6) continue;
                if (cell >= 1 && cell <= 5 && !targetKeys.has(nk)) continue;
                parent.set(nk, ck);
                q.push({ x: nx, y: ny });
            }
        }
        return null;
    }

    function dirBetween(a, b) {
        for (let d = 0; d < 4; d++) {
            if (a.x + DX[d] === b.x && a.y + DY[d] === b.y) return d;
        }
        return -1;
    }

    function tileForDirs(dirsNeeded) {
        for (const [idStr, maskStr] of Object.entries(TILE_DIRS_STR)) {
            const id = Number(idStr);
            if ((inv[id] || 0) <= 0) continue;
            let match = true;
            let countMask = 0;
            let countNeed = 0;
            for (let d = 0; d < 4; d++) {
                const mBit = Number(maskStr[d]);
                const nBit = dirsNeeded[d];
                countMask += mBit;
                countNeed += nBit;
                if (nBit && !mBit) { match = false; break; }
            }
            if (match && countNeed === countMask) return id;
        }
        return 0;
    }

    const reqDirs = Array.from({ length: H }, () =>
        Array.from({ length: W }, () => [0, 0, 0, 0])
    );

    for (const m of mines) {
        const p1 = bfsPath(m, solars);
        const p2 = bfsPath(m, transports);
        if (!p1 || !p2) return null;

        for (const path of [p1, p2]) {
            for (let i = 1; i < path.length - 1; i++) {
                const prev = path[i - 1];
                const cur = path[i];
                const next = path[i + 1];
                const d1 = dirBetween(cur, prev);
                const d2 = dirBetween(cur, next);
                if (d1 >= 0) reqDirs[cur.y][cur.x][d1] = 1;
                if (d2 >= 0) reqDirs[cur.y][cur.x][d2] = 1;
            }
        }
    }

    for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
            const mask = reqDirs[y][x];
            if (mask[0] || mask[1] || mask[2] || mask[3]) {
                const tid = tileForDirs(mask);
                if (!tid) return null;
                inv[tid]--;
                placed.push({ x, y, id: tid });
            }
        }
    }

    return placed;
}

function detectCellId(cell) {
    const inner = cell.querySelector('div[style*="mines.png"]') || cell;
    const bgX = (inner.style && inner.style.backgroundPositionX) || getComputedStyle(inner).backgroundPositionX || '';
    const m = String(bgX).match(/-(\d+)px/);
    if (m) return Math.round(Number(m[1]) / 40);
    return 0;
}

export async function initDeliveryGame(form) {
    if (!form || form.dataset.deliveryHelperInit) return;
    form.dataset.deliveryHelperInit = '1';

    const baseDb = await loadBaseDb();
    const customDb = await getCustomDb();

    const panel = document.createElement('div');
    panel.style.cssText = [
        'margin-top: 10px',
        'padding: 8px 10px',
        'background: rgba(16, 24, 38, 0.92)',
        'border: 1px solid #2e4a70',
        'border-radius: 6px',
        'color: #d8e6f8',
        'font-size: 12px',
        'display: flex',
        'flex-wrap: wrap',
        'align-items: center',
        'gap: 8px'
    ].join(';');

    const statusEl = document.createElement('span');
    statusEl.style.cssText = 'flex: 1 1 100%; color: #8ec5ff; font-weight: bold;';
    statusEl.textContent = `🚀 Delivery Helper готов (в базе ${baseDb.length} + ${customDb.length} карт)`;

    const makeBtn = (label, bg) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = label;
        b.style.cssText = [
            `background: ${bg}`,
            'color: #fff',
            'border: none',
            'border-radius: 4px',
            'padding: 5px 10px',
            'cursor: pointer',
            'font-size: 12px',
            'font-weight: bold'
        ].join(';');
        return b;
    };

    const btnSolve    = makeBtn('⚡ Авто-сборка', '#1f7a4c');
    const btnRemember = makeBtn('💾 Запомнить карту', '#2b5c9e');
    const btnExport   = makeBtn('⬇ Скачать .json', '#4b5563');
    const btnImport   = makeBtn('⬆ Загрузить .json', '#4b5563');

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json';
    fileInput.style.display = 'none';

    panel.append(statusEl, btnSolve, btnRemember, btnExport, btnImport, fileInput);
    form.appendChild(panel);

    function getRowsInfo() {
        const spaceRows = Array.from(form.querySelectorAll('tr.space'));
        const boardRows = spaceRows.slice(0, -1);
        const invRow    = spaceRows[spaceRows.length - 1] || null;
        const H = boardRows.length || 8;
        const W = boardRows.length ? boardRows[0].querySelectorAll('th.cell').length : 8;
        return { boardRows, invRow, W, H };
    }

    function readBoardFromDom() {
        const { boardRows, W, H } = getRowsInfo();
        const cells = [];
        const boardStatic = [];
        const boardTiles = [];

        boardRows.forEach((tr, y) => {
            const rowCells = Array.from(tr.querySelectorAll('th.cell'));
            rowCells.forEach((cell, x) => {
                cells.push({ x, y, el: cell });
                const id = detectCellId(cell);
                if (id >= 1 && id <= 6) boardStatic.push({ x, y, id, el: cell });
                else if (id >= 7 && id <= 13) boardTiles.push({ x, y, id, el: cell });
            });
        });

        return { cells, boardStatic, boardTiles, W, H };
    }

    function readInventoryFromDom() {
        const counts = { 7: 0, 8: 0, 9: 0, 10: 0, 11: 0, 12: 0, 13: 0 };
        const slots = {};
        const { invRow } = getRowsInfo();
        if (!invRow) return { counts, slots };

        Array.from(invRow.querySelectorAll('th.cell')).forEach((th) => {
            const id = detectCellId(th);
            if (id >= 7 && id <= 13) {
                slots[id] = th;
                const cntEl = th.querySelector('.cell-counter');
                const num = cntEl ? parseInt(cntEl.textContent.trim(), 10) : 1;
                counts[id] = isNaN(num) ? 1 : num;
            }
        });
        return { counts, slots };
    }

    btnSolve.addEventListener('click', async () => {
        const { cells, boardStatic, W, H } = readBoardFromDom();
        if (!boardStatic.length) {
            statusEl.textContent = '⚠️ Не найдены объекты на поле — нажмите «Начать игру».';
            return;
        }

        const curCustom = await getCustomDb();
        const match = findTemplateMatch(boardStatic, W, H, [...baseDb, ...curCustom]);
        const { counts: inv, slots } = readInventoryFromDom();

        let solutionTiles = null;
        if (match) {
            solutionTiles = match.tiles;
            statusEl.textContent = `✅ Найдено в базе: ${match.name} (${solutionTiles.length} деталей)`;
        } else {
            solutionTiles = solveFallback(boardStatic, W, H, inv);
            if (solutionTiles) {
                statusEl.textContent = `🧠 Решено авто-поиском (${solutionTiles.length} деталей) — нажмите «Запомнить карту»!`;
            } else {
                statusEl.textContent = '❌ Карты нет в базе. Соберите руками и нажмите «Запомнить карту»!';
                return;
            }
        }

        for (const t of solutionTiles) {
    const slotEl = slots[t.id];
    const target = cells.find((c) => c.x === t.x && c.y === t.y);
    if (!slotEl || !target) continue;

    // До 3 попыток, пока в целевой клетке реально не появится нужная деталь
    for (let attempt = 0; attempt < 3; attempt++) {
        if (detectCellId(target.el) === t.id) break;
        (slotEl.querySelector('div') || slotEl).click();
        await new Promise((r) => setTimeout(r, 60));
        (target.el.querySelector('div') || target.el).click();
        await new Promise((r) => setTimeout(r, 60));
    }
}


    });

    btnRemember.addEventListener('click', async () => {
        const { boardStatic, boardTiles } = readBoardFromDom();
        if (!boardStatic.length || !boardTiles.length) {
            statusEl.textContent = '⚠️ На поле нет собранных дорог для сохранения.';
            return;
        }

        const sCount = boardStatic.filter((x) => x.id === 4).length;
        const tCount = boardStatic.filter((x) => x.id === 5).length;
        const curCustom = await getCustomDb();
        const newEntry = {
            name: `${sCount}s${tCount}t_custom_${Date.now().toString().slice(-4)}`,
            static: boardStatic.map((p) => `${p.x},${p.y},${p.id}`),
            tiles: boardTiles.map((p) => `${p.x},${p.y},${p.id}`)
        };

        curCustom.push(newEntry);
        await saveCustomDb(curCustom);
        statusEl.textContent = `💾 Карта сохранена как ${newEntry.name}! Всего своих карт: ${curCustom.length}`;
    });

    btnExport.addEventListener('click', async () => {
        const curCustom = await getCustomDb();
        const merged = [...baseDb, ...curCustom];
        const blob = new Blob([JSON.stringify(merged, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `delivery_db_${merged.length}.json`;
        a.click();
    });

    btnImport.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        try {
            const text = await file.text();
            const parsed = JSON.parse(text);
            if (!Array.isArray(parsed)) throw new Error('Не массив');
            await saveCustomDb(parsed);
            statusEl.textContent = `⬆ Загружено ${parsed.length} карт в локальную память!`;
        } catch (err) {
            statusEl.textContent = '❌ Ошибка чтения JSON-файла.';
        }
    });
}
