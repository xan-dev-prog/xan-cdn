import { WHATSNEW_UI, WHATSNEW_RELEASES } from './whatsnew_data.js';

document.addEventListener("DOMContentLoaded", () => {
    let currentLang = localStorage.getItem("xan3_app_lang") || "ru";
    const installedVersion = chrome.runtime.getManifest().version;

    function render(lang) {
        currentLang = lang;
        localStorage.setItem("xan3_app_lang", lang);
        const ui = WHATSNEW_UI[lang] || WHATSNEW_UI.ru;

        document.getElementById("wn-header-title").textContent = ui.headerTitle;
        document.getElementById("wn-header-sub").textContent = ui.headerSub;
        document.getElementById("wn-btn-guide").textContent = ui.btnGuide;
        document.getElementById("wn-btn-close").textContent = ui.btnClose;

        const container = document.getElementById("releases-container");
        container.innerHTML = WHATSNEW_RELEASES.map((rel, index) => {
            const content = rel[lang] || rel.ru;
            const verLabel = index === 0 ? installedVersion : rel.version;
            const latestTag = index === 0 ? `<span class="badge-new">${ui.latestBadge}</span>` : "";

            return `
                <div class="card">
                    <h2>
                        <span class="badge-ver">v${verLabel}</span>
                        ${latestTag}
                        <span>${content.title}</span>
                    </h2>
                    <p>${content.summary}</p>
                    <div class="info-box" style="margin-bottom: 0;">
                        <ul>
                            ${content.changes.map(item => `<li>${item}</li>`).join("")}
                        </ul>
                    </div>
                </div>
            `;
        }).join("");

        document.querySelectorAll(".lang-btn").forEach(btn => {
            btn.classList.toggle("active", btn.dataset.lang === lang);
        });
    }

    document.querySelectorAll(".lang-btn").forEach(btn => {
        btn.addEventListener("click", () => render(btn.dataset.lang));
    });

    document.getElementById("wn-btn-guide").addEventListener("click", () => {
        chrome.tabs.create({ url: chrome.runtime.getURL("guide/index.html") });
    });

    document.getElementById("wn-btn-close").addEventListener("click", () => window.close());

    render(currentLang);
});
