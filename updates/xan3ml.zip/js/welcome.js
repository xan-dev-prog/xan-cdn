const WELCOME_TEXT = {
    ru: {
        headerTitle: "Добро пожаловать в XAN",
        headerSub: "Первичная настройка помощника XGame-Online",
        cardTitle: "🔥 Расширение успешно установлено!",
        cardDesc: "Чтобы не пропустить важные обновления, обязательно закрепите иконку расширения на верхней панели браузера.",
        stepsTitle: "Как закрепить иконку:",
        steps: [
            "Нажмите на иконку пазла 🧩 в правом верхнем углу браузера.",
            "Найдите в списке <strong>XAN - XGame Attack Notifier</strong>.",
            "Нажмите на иконку булавки 📌 напротив него, чтобы она стала синей.",
            'Теперь вы увидите зелёный индикатор <span class="badge-new">NEW</span>, когда выйдет обновление!'
        ],
        btnClose: "Готово, я закрепил!",
        btnGuide: "📖 Открыть справочник"
    },
    uk: {
        headerTitle: "Ласкаво просимо до XAN",
        headerSub: "Початкове налаштування помічника XGame-Online",
        cardTitle: "🔥 Розширення успішно встановлено!",
        cardDesc: "Щоб не пропустити важливі оновлення, обов'язково закріпіть іконку розширення на верхній панелі браузера.",
        stepsTitle: "Як закріпити іконку:",
        steps: [
            "Натисніть на іконку пазла 🧩 у правому верхньому куті браузера.",
            "Знайдіть у списку <strong>XAN - XGame Attack Notifier</strong>.",
            "Натисніть на іконку шпильки 📌 навпроти нього, щоб вона стала синьою.",
            'Тепер ви побачите зелений індикатор <span class="badge-new">NEW</span>, коли вийде оновлення!'
        ],
        btnClose: "Готово, я закріпив!",
        btnGuide: "📖 Відкрити довідник"
    }
};

document.addEventListener("DOMContentLoaded", () => {
    let currentLang = localStorage.getItem("xan3_app_lang") || "ru";

    function render(lang) {
        currentLang = lang;
        localStorage.setItem("xan3_app_lang", lang);
        const t = WELCOME_TEXT[lang] || WELCOME_TEXT.ru;

        document.getElementById("w-header-title").textContent = t.headerTitle;
        document.getElementById("w-header-sub").textContent = t.headerSub;
        document.getElementById("w-card-title").textContent = t.cardTitle;
        document.getElementById("w-card-desc").textContent = t.cardDesc;
        document.getElementById("w-steps-title").textContent = t.stepsTitle;
        document.getElementById("w-steps-list").innerHTML = t.steps.map(s => `<li>${s}</li>`).join("");
        document.getElementById("btn-close-tab").textContent = t.btnClose;
        document.getElementById("btn-open-guide").textContent = t.btnGuide;

        document.querySelectorAll(".lang-btn").forEach(btn => {
            btn.classList.toggle("active", btn.dataset.lang === lang);
        });
    }

    document.querySelectorAll(".lang-btn").forEach(btn => {
        btn.addEventListener("click", () => render(btn.dataset.lang));
    });

    document.getElementById("btn-close-tab").addEventListener("click", () => window.close());
    document.getElementById("btn-open-guide").addEventListener("click", () => {
        chrome.tabs.create({ url: chrome.runtime.getURL("guide/index.html") });
    });

    render(currentLang);
});
