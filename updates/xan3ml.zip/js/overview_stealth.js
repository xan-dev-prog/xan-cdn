// js/overview_stealth.js — Безопасный случайный переход по планетам на основе первого select на странице

import { _ } from './query.js';
import { getRandomInt } from './utils.js';

export function initStealthNavigation() {
    // Проверяем, включен ли модуль пользователем (по дефолту 1 - включен)
    const isStealthActive = localStorage.getItem('xan3_stealth_active') !== '0';
    
    if (!isStealthActive) {
        console.log("[Game Guard] Стелс-модуль навигации отключен пользователем в настройках.");
        return;
    }

    console.log("[Game Guard] Активация стелс-модуля навигации на базе первого select...");

    // 1. Читаем настройки интервалов из localStorage
    const lsFrom = parseInt(localStorage.xan3_intfrom, 10) || 15;
    const lsTo = parseInt(localStorage.xan3_intto, 10) || 45;

    // Генерируем случайное время перехода (в минутах)
    const randomMinutes = getRandomInt(lsFrom, lsTo);
    // Внедрено: Мультиязычная приписка к тайтлу страницы
    document.title += t('os_title_add').replace('{min}', randomMinutes);

    // 2. Находим самый первый select на странице
    const selectPlanet = _('select');

    if (!selectPlanet) {
        console.warn("[Game Guard] На странице не найден ни один select. Аварийное обновление через часы.");
        fallbackToClock(randomMinutes);
        return;
    }

    // Собираем все варианты (options) и определяем текущую выбранную планету
    const options = Array.from(selectPlanet.querySelectorAll('option'));
    const currentOption = selectPlanet.querySelector('option[selected]') || selectPlanet.options[selectPlanet.selectedIndex];
    const currentPlanetValue = currentOption ? currentOption.value : null;

    // Исключаем из списка текущую планету и пустые элементы
    const validTargets = options.filter(opt => opt.value && opt.value !== currentPlanetValue);

    if (validTargets.length === 0) {
        console.log("[Game Guard] В селекте нет других планет (аккаунт с одной планетой). Включаем клик по часам.");
        fallbackToClock(randomMinutes);
        return;
    }

    // 3. Случайный выбор следующей цели переключения
    const randomTargetOption = validTargets[getRandomInt(0, validTargets.length - 1)];
    const nextPlanetValue = randomTargetOption.value; // Получаем строку вида "?cp=310100&mode=0&info="

    console.log(`[Game Guard] Текущая планета: ${currentPlanetValue}. Цель перехода: ${nextPlanetValue} (${randomTargetOption.textContent.trim()})`);

    // 4. Отрисовка пунктирной рамочки вокруг выбранной цели в боковом меню
    const cpMatch = nextPlanetValue.match(/cp=(\d+)/);
    if (cpMatch && cpMatch[1]) {
        highlightTargetInMenu(cpMatch[1]);
    }

    // 5. Запуск таймера перехода
    setTimeout(() => {
        console.log(`[Game Guard] Время вышло! Переходим на планету/луну: ${nextPlanetValue}`);
        window.location.href = `overview.php${nextPlanetValue}`;
    }, randomMinutes * 60 * 1000);
}

/**
 * Поиск ссылки в боковом меню (планеты или mini-луны) для отрисовки рамки контроля
 */
function highlightTargetInMenu(planetId) {
    const allLinks = _('a.pl, a.mini_moon', true);
    let highlighted = false;

    allLinks.forEach(link => {
        const href = link.getAttribute('href') || '';
        if (href.includes(`cp=${planetId}`)) {
            link.setAttribute('id', `planet_${planetId}`);
            link.classList.add('gg-target-highlight');
            highlighted = true;
        }
    });

    if (!highlighted) {
        console.log(`[Game Guard] Не удалось подсветить ID ${planetId} в меню (ссылка не найдена). Переход выполнится штатно.`);
    }
}

/**
 * Симуляция клика по часам (для аккаунтов с 1 планетой или при сбоях интерфейса)
 */
function fallbackToClock(minutes) {
    const clockLink = _('#times');
    if (clockLink) {
        clockLink.classList.add('gg-target-highlight');
    }

    setTimeout(() => {
        if (clockLink) {
            console.log("[Game Guard] Время вышло! Кликаем по часам #times...");
            clockLink.click();
        } else {
            console.warn("[Game Guard] Часы не найдены, жесткая перезагрузка страницы.");
            window.location.reload();
        }
    }, minutes * 60 * 1000);
}
