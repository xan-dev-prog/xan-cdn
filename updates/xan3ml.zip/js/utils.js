// js/utils.js — Системные константы и инструменты разработки

// Импортируем начальные значения вместимости для МТ и БТ
import { TRANSPORT_SPECS } from './game_data.js'; 

// 1. ОПРЕДЕЛЕНИЕ КОНТЕКСТА СТРАНИЦЫ (НЕИЗМЕННЫЕ В ПРОЦЕССЕ ИГРЫ КОНСТАНТЫ)
const LP = window.location.pathname;

// Текущая страница (например: 'overview', 'galaxy', 'fleet')
export const CURRENT_PAGE = LP === '/sim/' ? 'sim' : LP.substring(LP.lastIndexOf('/') + 1, LP.indexOf('.php') !== -1 ? LP.indexOf('.php') : LP.length);

// Получаем текущий хост (например, "xgame.xgame-online.com")
const host = window.location.hostname;
// Разбиваем по точкам и берем первый элемент (поддомен)
export const CURRENT_UNIVERSE = host ? host.split('.')[0] : 'unknown';

// 2. ТВОЯ ЛЮБИМАЯ ФУНКЦИЯ ДЛЯ СОКРАЩЕНИЯ КОДА DOM
// Убрано в отдельный файл js/query.js

// 3. ПРОВЕРЕННЫЕ УТИЛИТЫ ДЛЯ РАБОТЫ С ЧИСЛАМИ ИГРЫ
// Очистка строки от пробелов и букв "k" (превращает "150k" или "1 500" в чистое число)

// 3. ПРОВЕРЕННЫЕ УТИЛИТЫ ДЛЯ РАБОТЫ С ЧИСЛАМИ ИГРЫ
// Очистка строки от пробелов (включая неразрывные) и букв "k"
// 3. ПРОВЕРЕННЫЕ УТИЛИТЫ ДЛЯ РАБОТЫ С ЧИСЛАМИ ИГРЫ
// Очистка строки от пробелов (включая неразрывные, обычные и HTML-сущности &nbsp;)
export function nsn(str) {
    if (!str) return 0;
    // Сначала удаляем текстовое представление '&nbsp;', а затем любые другие типы пробелов
    let clean = str.toString().replace(/&nbsp;/ig, '').replace(/[\s\u00A0]+/g, '').toLowerCase();
    if (clean.includes('k')) {
        clean = parseFloat(clean.replace('k', '')) * 1000;
    }
    return parseInt(clean, 10) || 0;
}



/*
export function nsn(str) {
    if (!str) return 0;
    let clean = str.toString().replace(/\s+/g, '').toLowerCase();
    if (clean.includes('k')) {
        clean = parseFloat(clean.replace('k', '')) * 1000;
    }
    return parseInt(clean, 10) || 0;
}
*/

// Форматирование числа обратно в красивый вид с пробелами (из 1500000 делает "1 500 000")
export function spaces(num) {
    if (!num) return '0';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

// Безопасный генератор случайных чисел (включая обе границы) для джиттера таймеров
export function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/*
 * Рассчитывает точное количество транспортов с учетом расхода топлива на дальний полет
 * @param {string} shipType - 'MT' или 'BT'
 * @param {number} totalResources - общая сумма ресурсов для вывоза
 * @returns {number} - количество кораблей (округленное вверх)
 */
export function calculateShips(shipType, totalResources) {
  const ship = TRANSPORT_SPECS[shipType];
  if (!ship || totalResources <= 0) return 0;

  // Твои проверенные боевые цифры расхода на максимальную дистанцию
  const fuelPerShip = shipType === 'MT' ? 132 : 330;

  // Полезная вместимость (вместимость минус расход)
  const usefulCapacity = ship.capacity - fuelPerShip;

  // Финальный расчет с округлением вверх
  return Math.ceil(totalResources / usefulCapacity);
}

// Проверка, включен ли конкретный скрипт пользователем в настройках XAN
export function isScriptActive(scriptName) {
    if (!localStorage.xan3_active_modules) return false;
    
    // Разбиваем строку "galaxy;true|buildings;false" на массив подстрок
    const pairs = localStorage.xan3_active_modules.split('|');
    
    // Ищем точное совпадение нужной страницы со статусом true
    return pairs.includes(`${scriptName};true`);
}



