// js/questions.js — Страница вопросов (questions.php)

import { _ } from './query.js';
import { CURRENT_UNIVERSE } from './utils.js';

const DC_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 часа
const DB_STORAGE_KEY = 'xan3_questions_db_state';
const PENDING_SESSION_KEY = 'xan3_pending_question';
const BACKUP_REMINDER_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
const FIRST_BACKUP_MIN_COUNT = 5;

/**
 * Нормализация текста вопроса или ответа для надежного сопоставления
 * @param {string} str
 * @returns {string}
 */
function normalizeText(str) {
    return (str || '').replace(/\s+/g, ' ').trim();
}

/**
 * Чтение состояния базы знаний из chrome.storage.local
 * @returns {Promise<{version: number, lastExportAt: number|null, lastExportCount: number, items: Object}>}
 */
async function loadQuestionsDb() {
    const defaultState = {
        version: 1,
        lastExportAt: null,
        lastExportCount: 0,
        items: {}
    };

    try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            const res = await chrome.storage.local.get(DB_STORAGE_KEY);
            const saved = res[DB_STORAGE_KEY];
            if (saved && typeof saved === 'object' && saved.items && typeof saved.items === 'object') {
                return {
                    version: 1,
                    lastExportAt: typeof saved.lastExportAt === 'number' ? saved.lastExportAt : null,
                    lastExportCount: typeof saved.lastExportCount === 'number' ? saved.lastExportCount : 0,
                    items: saved.items
                };
            }
        }
    } catch (err) {
        console.warn('[XAN Questions] Ошибка чтения базы из chrome.storage.local:', err);
    }

    return defaultState;
}

/**
 * Сохранение состояния базы знаний в chrome.storage.local
 * @param {Object} dbState
 */
async function saveQuestionsDb(dbState) {
    try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            await chrome.storage.local.set({ [DB_STORAGE_KEY]: dbState });
        }
    } catch (err) {
        console.warn('[XAN Questions] Ошибка записи базы в chrome.storage.local:', err);
    }
}

/**
 * Подливает стартовую базу из встроенного файла js/questions_db.json один раз на каждую версию расширения
 */
async function syncBundledQuestionsDb() {
    try {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getURL) return;

        const currentVersion = chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '0';
        const dbState = await loadQuestionsDb();

        // Если для текущей версии расширения база уже синхронизирована — пропускаем fetch
        if (dbState.syncedManifestVersion === currentVersion) {
            return;
        }

        const url = chrome.runtime.getURL('js/questions_db.json');
        if (!url || url.includes('invalid')) {
            console.warn('[XAN Questions] Ресурс js/questions_db.json недоступен. Обновите расширение в chrome://extensions/ и перезагрузите вкладку.');
            return;
        }

        const response = await fetch(url);
        if (!response.ok) return;

        const bundled = await response.json();
        if (!bundled || typeof bundled !== 'object' || !bundled.items || typeof bundled.items !== 'object') {
            return;
        }

        for (const [key, entry] of Object.entries(bundled.items)) {
            if (!entry || typeof entry !== 'object' || typeof entry.q !== 'string' || typeof entry.a !== 'string') {
                continue;
            }
            const normKey = normalizeText(key || entry.q).toLowerCase();
            if (!normKey) continue;

            if (!dbState.items[normKey]) {
                dbState.items[normKey] = {
                    q: normalizeText(entry.q),
                    a: normalizeText(entry.a),
                    addedAt: typeof entry.addedAt === 'number' ? entry.addedAt : Date.now()
                };
            }
        }

        dbState.syncedManifestVersion = currentVersion;
        await saveQuestionsDb(dbState);
    } catch (err) {
        console.warn('[XAN Questions] Ошибка синхронизации встроенной базы:', err);
    }
}


/**
 * Форматирование даты в ДД.ММ.ГГГГ
 * @param {number} ts
 * @returns {string}
 */
function formatDateRu(ts) {
    const d = new Date(ts);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}.${mm}.${yyyy}`;
}

/**
 * Форматирование даты имени файла в YYYY-MM-DD
 * @param {number} ts
 * @returns {string}
 */
function formatFileDate(ts) {
    const d = new Date(ts);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}
/**
 * Расчет базового лимита объявлений войн и союзов по уровню Дипломатического центра
 * @param {number} level 
 * @returns {number}
 */
function getDipCenterLimit(level) {
    if (level >= 30) return 8;
    if (level >= 25) return 7;
    if (level >= 20) return 6;
    if (level >= 15) return 5;
    if (level >= 10) return 4;
    if (level >= 5)  return 3;
    if (level >= 3)  return 2;
    if (level >= 1)  return 1;
    return 0;
}

/**
 * Запрашивает страницу альянса (с кэшированием в localStorage на 24ч) и парсит уровень ДЦ
 * @returns {Promise<number|null>}
 */
async function fetchAllianceDipCenterLevel() {
    const cacheKey = `xan3_dc_level_${CURRENT_UNIVERSE}`;

    try {
        const cachedRaw = localStorage.getItem(cacheKey);
        if (cachedRaw) {
            const cached = JSON.parse(cachedRaw);
            if (cached && typeof cached.level === 'number' && (Date.now() - cached.updatedAt < DC_CACHE_TTL_MS)) {
                return cached.level;
            }
        }
    } catch (e) {
        // Игнорируем ошибки чтения localStorage
    }

    try {
        const response = await fetch('alliance.php');
        if (!response.ok) return null;

        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const cells = Array.from(doc.querySelectorAll('td.c'));

        for (const cell of cells) {
            const text = cell.textContent || '';
            if (text.includes('Дипл. центр')) {
                const match = text.match(/\[(\d+)\]/);
                if (match && match[1]) {
                    const level = parseInt(match[1], 10);
                    try {
                        localStorage.setItem(cacheKey, JSON.stringify({
                            level,
                            updatedAt: Date.now()
                        }));
                    } catch (e) {}
                    return level;
                }
            }
        }
    } catch (err) {
        console.warn('[XAN Questions] Ошибка получения уровня ДЦ из alliance.php:', err);
    }
    return null;
}

/**
 * Решатель для вопросов по лимитам Дипломатического центра
 * @param {string} questionText 
 * @returns {Promise<number|null>}
 */
async function solveDipCenterQuestion(questionText) {
    if (!/дипломатического центра/i.test(questionText) || !/объявлений войн и союзов/i.test(questionText)) {
        return null;
    }

    // 1. Ищем уровень ДЦ в тексте вопроса ("10й уровень" или "5 уровень")
    let dcLevel = null;
    const levelMatch = questionText.match(/(\d+)(?:[-–]?й)?\s+уровень/i);
    if (levelMatch && levelMatch[1]) {
        dcLevel = parseInt(levelMatch[1], 10);
    } else {
        // Если в тексте уровень не указан — берем из кэша или alliance.php
        dcLevel = await fetchAllianceDipCenterLevel();
    }

    if (dcLevel === null || isNaN(dcLevel)) return null;

    // 2. Парсим параметры войн и союзов
    const incomingMatch = questionText.match(/вам объявили\s*[-–—]?\s*войн:\s*(\d+)\s*,\s*союзов:\s*(\d+)/i);
    const outgoingMatch = questionText.match(/вы объявили\s*[-–—]?\s*войн:\s*(\d+)\s*,\s*союзов:\s*(\d+)/i);

    if (!incomingMatch || !outgoingMatch) return null;

    const incomingAlliances = parseInt(incomingMatch[2], 10); // Союзы, объявленные ВАМ
    const outgoingWars      = parseInt(outgoingMatch[1], 10); // Войны, объявленные ВАМИ
    const outgoingAlliances = parseInt(outgoingMatch[2], 10); // Союзы, объявленные ВАМИ

    // Войны, объявленные ВАМ (incomingMatch[1]), не влияют на лимит
    const totalLimit = getDipCenterLimit(dcLevel);
    return totalLimit - incomingAlliances - outgoingWars - outgoingAlliances;
}

/**
 * Подсвечивает ячейку правильного ответа
 * @param {HTMLAnchorElement} linkEl 
 */
function highlightAnswer(linkEl) {
    const cell = linkEl.closest('th') || linkEl;
    _(cell).css({
        outline: '2px solid #2ea043',
        outlineOffset: '-2px',
        backgroundColor: 'rgba(46, 160, 67, 0.25)',
        boxShadow: 'inset 0 0 8px rgba(46, 160, 67, 0.45)'
    });

    const fontEl = linkEl.querySelector('font');
    if (fontEl) {
        fontEl.setAttribute('color', '#ffffff');
    }
}

/**
 * Фаза А: Проверка результата ответа на странице вердикта (questions.php?id=...&otvet=...)
 */
async function handleVerdictPage() {
    let pendingRaw = null;
    try {
        pendingRaw = sessionStorage.getItem(PENDING_SESSION_KEY);
    } catch (e) {
        return;
    }

    if (!pendingRaw) return;

    // Очищаем буфер сразу, чтобы повторное обновление страницы не дублировало запись
    try {
        sessionStorage.removeItem(PENDING_SESSION_KEY);
    } catch (e) {}

    let pending = null;
    try {
        pending = JSON.parse(pendingRaw);
    } catch (e) {
        return;
    }

    if (!pending || pending.isFormula || !pending.questionKey || !pending.answerRaw) {
        return;
    }

    // Проверяем блок вердикта на текущей странице (<td class="c"><font><span style="color: yellow">Ответ правильный</span></font></td>)
    const verdictCells = Array.from(document.querySelectorAll('td.c'));
    const isCorrect = verdictCells.some(cell => normalizeText(cell.textContent).includes('Ответ правильный'));

    if (!isCorrect) return;

    const dbState = await loadQuestionsDb();
    if (!dbState.items[pending.questionKey]) {
        dbState.items[pending.questionKey] = {
            q: pending.questionRaw,
            a: pending.answerRaw,
            addedAt: Date.now()
        };
        await saveQuestionsDb(dbState);
    }
}

/**
 * Фаза Б и В: Обработка страницы активного вопроса (questions.php?id=...)
 * @param {HTMLFormElement} form
 * @param {HTMLAnchorElement[]} answerLinks
 */
async function handleActiveQuestionPage(form, answerLinks) {
    const questionTable = answerLinks[0].closest('table');
    const questionCell = questionTable ? questionTable.querySelector('td.c[colspan="3"]') : null;
    if (!questionCell) return;

    const questionRaw = normalizeText(questionCell.textContent);
    const questionKey = questionRaw.toLowerCase();
    let isFormula = false;

    // 1. Приоритет №1: Проверка математических решателей (динамика)
    const formulaAnswer = await solveDipCenterQuestion(questionRaw);
    if (formulaAnswer !== null && !isNaN(formulaAnswer)) {
        isFormula = true;
        for (const link of answerLinks) {
            const optionValue = parseInt(normalizeText(link.textContent), 10);
            if (!isNaN(optionValue) && optionValue === formulaAnswer) {
                highlightAnswer(link);
                break;
            }
        }
    } else {
        // 2. Приоритет №2: Поиск в базе знаний (статика)
        const dbState = await loadQuestionsDb();
        const savedRecord = dbState.items[questionKey];
        if (savedRecord && savedRecord.a) {
            const savedAnswerNorm = normalizeText(savedRecord.a).toLowerCase();
            for (const link of answerLinks) {
                const optionNorm = normalizeText(link.textContent).toLowerCase();
                if (optionNorm === savedAnswerNorm) {
                    highlightAnswer(link);
                    break;
                }
            }
        }
    }

    // 3. Перехват клика игрока по варианту ответа
    for (const link of answerLinks) {
        link.addEventListener('click', () => {
            const answerRaw = normalizeText(link.textContent);
            try {
                sessionStorage.setItem(PENDING_SESSION_KEY, JSON.stringify({
                    questionKey,
                    questionRaw,
                    answerRaw,
                    isFormula,
                    timestamp: Date.now()
                }));
            } catch (e) {}
        });
    }
}
/**
 * Рендеринг панели управления базой знаний в нижней части таблицы на главной странице questions.php
 * @param {HTMLFormElement} form
 */
async function renderDbControlPanel(form) {
    const tbody = form.querySelector('table tbody') || form.querySelector('table');
    if (!tbody) return;

    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.setAttribute('colspan', '5');
    td.className = 'h';
    td.style.padding = '6px 8px';
    tr.appendChild(td);
    tbody.appendChild(tr);

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json,application/json';
    fileInput.style.display = 'none';
    td.appendChild(fileInput);

    const container = document.createElement('div');
    container.style.cssText = 'display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;font-size:11px;color:#c9d1d9;';
    td.appendChild(container);

    const statusBox = document.createElement('div');
    statusBox.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
    container.appendChild(statusBox);

    const btnBox = document.createElement('div');
    btnBox.style.cssText = 'display:flex;align-items:center;gap:6px;';
    container.appendChild(btnBox);

    const baseBtnStyle = 'cursor:pointer;padding:3px 8px;font-size:11px;border-radius:3px;border:1px solid #30363d;background:#161b22;color:#c9d1d9;transition:all 0.15s ease;';

    const exportBtn = document.createElement('button');
    exportBtn.type = 'button';
    exportBtn.textContent = 'Скачать базу (.json)';
    exportBtn.style.cssText = baseBtnStyle;

    const importBtn = document.createElement('button');
    importBtn.type = 'button';
    importBtn.textContent = 'Загрузить базу (.json)';
    importBtn.style.cssText = baseBtnStyle;

    btnBox.appendChild(exportBtn);
    btnBox.appendChild(importBtn);

    const updateUI = async (flashMessage = '') => {
        const dbState = await loadQuestionsDb();
        const totalCount = Object.keys(dbState.items).length;
        const backupText = dbState.lastExportAt ? formatDateRu(dbState.lastExportAt) : 'не создавался';

        // Условие умного напоминания о бэкапе
        const newSinceExport = Math.max(0, totalCount - (dbState.lastExportCount || 0));
        const isRegularDue = dbState.lastExportAt !== null
            && (Date.now() - dbState.lastExportAt >= BACKUP_REMINDER_DAYS_MS)
            && newSinceExport >= 1;
        const isFirstDue = dbState.lastExportAt === null && totalCount >= FIRST_BACKUP_MIN_COUNT;
        const needBackup = isRegularDue || isFirstDue;

        let reminderHtml = '';
        if (needBackup) {
            const diffBadge = isRegularDue ? ` (+${newSinceExport} новых)` : '';
            reminderHtml = `<span style="color:#f0883e;font-weight:bold;">• пора обновить бэкап${diffBadge}</span>`;
            exportBtn.style.borderColor = '#2ea043';
            exportBtn.style.boxShadow = '0 0 6px rgba(46, 160, 67, 0.45)';
            exportBtn.style.color = '#ffffff';
        } else {
            exportBtn.style.borderColor = '#30363d';
            exportBtn.style.boxShadow = 'none';
            exportBtn.style.color = '#c9d1d9';
        }

        const flashHtml = flashMessage
            ? `<span style="color:#3fb950;font-weight:bold;">${flashMessage}</span>`
            : '';

        statusBox.innerHTML = `
            <span>📚 База вопросов: <b style="color:#58a6ff;">${totalCount}</b></span>
            <span style="color:#8b949e;">|</span>
            <span>Бэкап: <b style="color:#c9d1d9;">${backupText}</b></span>
            ${reminderHtml}
            ${flashHtml}
        `;
    };

    exportBtn.addEventListener('click', async () => {
        const dbState = await loadQuestionsDb();
        const now = Date.now();
        const count = Object.keys(dbState.items).length;

        dbState.lastExportAt = now;
        dbState.lastExportCount = count;
        await saveQuestionsDb(dbState);

        const payload = JSON.stringify(dbState, null, 2);
        const blob = new Blob([payload], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `xan_questions_db_${formatFileDate(now)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        await updateUI('✓ Сохранено');
    });

    importBtn.addEventListener('click', () => {
        fileInput.value = '';
        fileInput.click();
    });

    fileInput.addEventListener('change', async (event) => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;

        try {
            const rawText = await file.text();
            const parsed = JSON.parse(rawText);

            if (!parsed || typeof parsed !== 'object' || !parsed.items || typeof parsed.items !== 'object') {
                await updateUI('⚠ Неверный формат JSON');
                return;
            }

            const dbState = await loadQuestionsDb();
            let addedCount = 0;

            for (const [key, entry] of Object.entries(parsed.items)) {
                if (!entry || typeof entry !== 'object' || typeof entry.q !== 'string' || typeof entry.a !== 'string') {
                    continue;
                }
                const normKey = normalizeText(key || entry.q).toLowerCase();
                if (!normKey) continue;

                if (!dbState.items[normKey]) {
                    dbState.items[normKey] = {
                        q: normalizeText(entry.q),
                        a: normalizeText(entry.a),
                        addedAt: typeof entry.addedAt === 'number' ? entry.addedAt : Date.now()
                    };
                    addedCount++;
                }
            }

            await saveQuestionsDb(dbState);
            await updateUI(`✓ Импорт: +${addedCount} нов.`);
        } catch (err) {
            console.warn('[XAN Questions] Ошибка импорта JSON:', err);
            await updateUI('⚠ Ошибка чтения файла');
        }
    });

    await updateUI();
}

export async function initQuestionsPage() {
	// 0. Синхронизируем встроенную стартовую базу js/questions_db.json (без перезаписи существующих записей)
    await syncBundledQuestionsDb();
	
    // 1. Всегда сначала проверяем, не находимся ли мы на странице результата (questions.php?id=...&otvet=...)
    await handleVerdictPage();

    const form = _('form[action*="questions.php"]');
    if (!form) return;

    const answerLinks = Array.from(form.querySelectorAll('a[href*="otvet="]'));

    // 2. Если на странице есть варианты ответов — работаем как помощник по вопросу
    if (answerLinks.length > 0) {
        await handleActiveQuestionPage(form, answerLinks);
        return;
    }

    // 3. Иначе это главная страница списка вопросов (questions.php) — рендерим панель управления базой
    await renderDbControlPanel(form);
}
