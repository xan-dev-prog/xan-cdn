// js/fleet_page1.js — Подмодуль для первой страницы флота (Выбор кораблей)
// ЧАСТЬ 1 ИЗ 3

import { _ } from './query.js';
import { spaces, nsn } from './utils.js';
import { SHIP_NAMES } from './game_data.js';

export function initPage1() {
  console.log('-> Скрипт XAN: Инициализация Первой страницы флота (Гибридная панель управления)');
  
  // ==========================================
  // БЛОК 1: СТИЛИЗАЦИЯ И МОДЕРНИЗАЦИЯ НИЖНЕЙ ПАНЕЛИ УПРАВЛЕНИЯ
  // ==========================================
  const flt = _('[href *= "buildings.php?mode=fleet&gid="]', true);
  if (!flt || flt.length === 0) return;

  // 1. АДАПТАЦИЯ КНОПКИ "ОБНУЛИТЬ ВСЕ КОРАБЛИ" (Гибкий поиск по ключевым словам локализации игры)
  const nativeResetBtn = [...document.querySelectorAll('input[type="submit"], input[type="button"]')].find(x => 
    x.value.includes('Обнулить') || x.value.includes('Скинути') || x.value.includes('Reset')
  );

  if (nativeResetBtn && !nativeResetBtn.dataset.xanInjected) {
    nativeResetBtn.dataset.xanInjected = "true";
    const cell = nativeResetBtn.closest('td') || nativeResetBtn.closest('th');
    if (cell) {
      nativeResetBtn.className = 'xan-hidden-input-fix'; // Прячем инпут
      cell.insertAdjacentHTML('afterbegin', `<span class="xan-btn-text" data-action="reset">${t('f1_reset_all')}</span>`);
      
      cell.querySelector('[data-action="reset"]')?.addEventListener('click', () => {
        nativeResetBtn.click(); // Симулируем клик по родному инпуту
      });
    }
  }

  // 2. КНОПКУ "ДАЛЕЕ" ОСТАВЛЯЕМ РОДНОЙ И ТРОГАТЬ НЕ БУДЕМ (ДЛЯ СТАБИЛЬНОСТИ СЕССИЙ)
  const nativeNextBtn = [...document.querySelectorAll('input[type="submit"]')].find(x => 
    x.value.includes('Далее') || x.value.includes('Далі') || x.value.includes('Next')
  );

  if (nativeNextBtn) {
    nativeNextBtn.style.margin = '0 auto';
    nativeNextBtn.style.display = 'block';
  }

  // 3. АДАПТАЦИЯ НАШЕЙ ЦЕНТРАЛЬНОЙ КНОПКИ "ВЗЯТЬ ВСЕ" + ИКОНКИ ГРУПП (ОБХОД CSP)
  const nativeBtn = [...document.querySelectorAll('input[type="submit"], input[type="button"]')].find(x => 
    x.value.includes('Взять все') || x.value.includes('Взяти все') || x.value.includes('Select all')
  );

  if (nativeBtn && !nativeBtn.dataset.xanInjected) {
    nativeBtn.dataset.xanInjected = "true";
    const parentCell = nativeBtn.closest('th') || nativeBtn.closest('td');
    
    if (parentCell) {
      nativeBtn.className = 'xan-hidden-input-fix'; // Прячем инпут
      
      const flexWrapper = document.createElement('div');
      flexWrapper.className = 'xan-fleet-flex-container';
      flexWrapper.innerHTML = `
        <span class="xan-group-btn-left" data-type="military" title="${t('f1_title_military')}">
          <a><img src="${chrome.runtime.getURL('images/military.png')}" width="20" /></a>
        </span>
        <span class="xan-take-all-text" data-type="take-all">${t('f1_take_all')}</span>
        <span class="xan-group-btn-right" data-type="civil" title="${t('f1_title_civil')}">
          <a><img src="${chrome.runtime.getURL('images/civil.png')}" width="20" /></a>
        </span>
      `;
      
      flexWrapper.appendChild(nativeBtn);
      parentCell.innerHTML = '';
      parentCell.appendChild(flexWrapper);
      parentCell.setAttribute('data-type', 'varFleet');

      // Размечаем классы флота для ховеров (Проверка совпадений по ru и uk справочникам)
      [...flt].forEach(x => {
        const name = x.textContent.trim();
        const isMilitary = Object.values(SHIP_NAMES.MILITARY).some(obj => obj.ru === name || obj.uk === name);
        x.classList.add(isMilitary ? 'military' : 'civil');
      });

      // Клики по группам боевых и гражданских кораблей
      _('[data-type="military"]')?.addEventListener('click', (e) => {
        e.preventDefault();
        [..._('.military', true)].forEach(x => {
            const rowInp = x.closest('tr')?.querySelector('input[type="button"], input[type="submit"]');
            if (rowInp) rowInp.click();
        });
      });
     
      _('[data-type="civil"]')?.addEventListener('click', (e) => {
        e.preventDefault();
        [..._('.civil', true)].forEach(x => {
            const rowInp = x.closest('tr')?.querySelector('input[type="button"], input[type="submit"]');
            if (rowInp) rowInp.click();
        });
      });

      // 100% Обход CSP через триггер нативного инпута
      _('[data-type="take-all"]')?.addEventListener('click', (e) => {
        e.preventDefault();
        nativeBtn.click(); 
      });
              
      // Желтый ховер названий кораблей при наведении на группы фракций
      _('.xan-group-btn-left, .xan-group-btn-right', true)?.forEach(x => {
        const type = x.dataset.type;
        if (type === 'military' || type === 'civil') {
          x.addEventListener('mouseover', () => {
             [..._(`.${type}`, true)].forEach(z => z.classList.add('hlite'));
          });
          x.addEventListener('mouseout', () => { 
            [..._('.hlite', true)].forEach(m => m.classList.remove('hlite'));
          });
        }
      });
    }
  }
  // js/fleet_page1.js — ЧАСТЬ 2 ИЗ 3

  // ==========================================
  // БЛОК 2: АВТОРАСЧЕТ КОРАБЛЕЙ ДЛЯ ПОГРУЗКИ РЕСУРСОВ
  // ==========================================
  const metalEl = _('#met');
  const crystalEl = _('#cry');
  const uranEl = _('#deu');

  if (metalEl && crystalEl && uranEl) {
    const metal = nsn(metalEl.textContent);
    const crystal = nsn(crystalEl.textContent);
    const uran = nsn(uranEl.textContent);
    const total_res = metal + crystal + uran;
      
    for (let n = 0; n < flt.length; n++) {
      const f = flt[n];
      const Fcell = f.closest('th') || f.closest('td');
      if (!Fcell) continue;

      const Fttl = f.getAttribute('onmouseover') || '';
      
      let Fload = 0; 
      const keywordMatch = Fttl.match(/Вместимость|Місткість|Capacity/);
      
      if (keywordMatch && keywordMatch.index !== undefined) {
        // Отрезаем всё, что ДО ключевого слова, и берем только кусок с цифрами вместимости
        const subStr = Fttl.substring(keywordMatch.index, keywordMatch.index + 150);
        
        // Удаляем только HTML-теги, оставляя текст и пробелы для корректной работы nsn
        const cleanStr = subStr.replace(/<[^>]*>/g, '');
        
        const digits = cleanStr.match(/\d[\d\s]*k?/i); // Находим число вместе с внутренними пробелами и возможным "k"
        if (digits) {
          Fload = nsn(digits[0]); 
        }
      }

      // Если у корабля нет вместимости (спутники, зонды и т.д.), плашку .needed НЕ выводим
      if (Fload <= 0) continue;

      const required_ships = Math.ceil((total_res / Fload)) + 5;
      
      const hrf = f.getAttribute('href') || '';
      const data_id = hrf.substring(hrf.lastIndexOf('=') + 1, hrf.lastIndexOf('.'));
      
      // Ищем доступные корабли через кнопку "Взять все" в текущей строке таблицы
      const parentTr = Fcell.closest('tr');
      const takeAllBtn = parentTr ? parentTr.querySelector('input[title="Взять все"]') : null;
      const total_ships = takeAllBtn ? nsn(takeAllBtn.value) : 0;
      
      // Сравниваем реальное количество на планете с необходимым
      const cls = (total_ships >= required_ships) ? 'ok' : 'notok';
      const clr = (cls == 'ok') ? '#00ff00' : '#ff6467';
      
      if (!Fcell.querySelector('.needed')) {
        Fcell.insertAdjacentHTML('beforeend', `<span class="needed ${cls}" data-capacity="${Fload}" data-id="ship${data_id}" title="${t('f1_needed_title')}" style="color:${clr};float:right;margin-right:10px;cursor:pointer;font-weight:bold">${spaces(required_ships)}</span>`);
      }
    }

    _('.needed', true)?.forEach(btn => {
      if (!btn.dataset.handlerAttached) {
        btn.dataset.handlerAttached = "true";
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id'); 
          const amount = nsn(this.textContent);
          const targetInput = _(`#${id}`) || _(`input[name="${id}"]`);
          if (!targetInput) return;

          const val = nsn(targetInput.value) == 0 ? amount : 0;
          const capacity = (val != 0) ? spaces(val * parseInt(this.getAttribute('data-capacity') || '0', 10)) : '-';
          const bgcol = (val == amount) ? '#415680' : '#344566';
            
          _('[maxlength="11"]', true)?.forEach(inp => {
            inp.value = '0';
            inp.style.backgroundColor = '#344566';
          });

          targetInput.value = val.toString();
          targetInput.style.backgroundColor = bgcol;
          
          const allCapEl = _('#allcapacity');
          if (allCapEl) allCapEl.innerHTML = capacity;
        });
      }
    });
  }

  // js/fleet_page1.js — ЧАСТЬ 3 ИЗ 3

  // ==========================================
  // БЛОК 3: МОНИТОРИНГ СЛОТОВ ФЛОТА И МАРКИРОВКА КРИТИЧЕСКИХ СОСТОЯНИЙ
  // ==========================================
  const allTdC = _('td.c', true);
  // Ищем ячейку слотов по ключевым буквам в зависимости от языка игры
  const fleetSlotTd = [...allTdC].find(x => x.textContent.includes('Флоты') || x.textContent.includes('Флоти') || x.textContent.includes('Fleets'));
  
  if (fleetSlotTd) {
    const fleetSlots = fleetSlotTd.textContent.match(/[0-9]+/g);
    if (fleetSlots && fleetSlots.length >= 2) {
      const fleetSent = parseInt(fleetSlots[0], 10);
      let fleetMax = 0;
      
      if (fleetSlotTd.textContent.indexOf('/') < 0) {
        fleetMax = parseInt(fleetSlots[1], 10);
      } else {
        fleetMax = fleetSlots[2] ? parseInt(fleetSlots[2], 10) : parseInt(fleetSlots[1], 10);
      }
      
      const delta = fleetMax - fleetSent;

      if (delta < 2) {
        const fleetTables = _('table', true);
        [...fleetTables].forEach(tbl => {
          if (tbl.textContent.includes('Флоты') || tbl.textContent.includes('Флоти') || tbl.textContent.includes('Fleets')) {
            tbl.querySelectorAll('th')?.forEach(th => {
              if (th.querySelector('input')) th.classList.add('xan-slot-alert');
            });
            
            if (delta === 1) {
              tbl.querySelector('tbody')?.insertAdjacentHTML('beforeend', `
                <tr><th colspan="8" class="xan-slot-warning-text">${t('f1_slot_warning')}</th></tr>
              `);
            }
          }
        });
      }
    }
  }

  // ==========================================
  // БЛОК 4: АНАЛИЗАТОР СКАНИРОВАНИЯ ФАЛАНГОЙ И ПОДСВЕТКА СБЛИЖЕНИЙ
  // ==========================================
  const selectedPlanka = _('[selected]');
  if (selectedPlanka) {
    const plankaText = selectedPlanka.textContent;
    const coryMatch = plankaText.match(/\[[0-9]+:[0-9]+:[0-9]+\]/);
    
    if (coryMatch) {
      const cory = coryMatch[0];
      
      // Подсвечиваем родные планки в списке вылетов через класс из CSS
      _('a', true)?.forEach(x => {
        if (x.textContent.trim() === cory) {
          x.closest('tr')?.classList.add('xan-own-planet-row');
        }
      });

      // Проверка летящих вражеских атак (Поддержка атаковать/атакувати/attack)
      const attacks = [..._('[id^="fleet_id_"]', true)].filter(x => 
        x.textContent.includes('Атаковать') || x.textContent.includes('Атакувати') || x.textContent.includes('Attack')
      );
      
      if (attacks.length > 0) {
        attacks.forEach(z => {
          const row = z.closest('tr');
          if (!row) return;

          const ths = row.querySelectorAll('th');
          if (ths.length < 5) return;

          const startCoordsStr = ths[3].textContent;
          const endCoordsStr = ths[4].textContent;

          const aMatch = startCoordsStr.match(/\[(\d+):(\d+):(\d+)\]/);
          const bMatch = endCoordsStr.match(/\[(\d+):(\d+):(\d+)\]/);

          if (aMatch && bMatch) {
            const aGal = aMatch[1];
            const aSys = aMatch[2];
            const aPla = aMatch[3];
            
            // Внедряем иконку фаланги рядом с формой
            const nextRow = row.nextSibling;
            if (nextRow && nextRow.nodeType === Node.ELEMENT_NODE) {
              nextRow.querySelector('form')?.insertAdjacentHTML('beforeend', `
                <a class="xan-phalanx-link" href="#" title="${t('f1_phalanx_title')}" 
                   data-phalanx="phalanx.php?galaxy=${aGal}&amp;system=${aSys}&amp;planet=${aPla}">🔎</a>
              `);
            }

            // Анализируем кросс-галактические сближения по системам
            if (aGal !== bMatch[1]) {
              const x = parseInt(aSys, 10) < 100 ? (parseInt(aSys, 10) + 999) : parseInt(aSys, 10);
              const y = parseInt(bMatch[2], 10) < 100 ? (parseInt(bMatch[2], 10) + 999) : parseInt(bMatch[2], 10);

              if (Math.abs(x - y) < 100) {
                const linkA = ths[3].querySelector('a');
                if (linkA) linkA.style.color = 'salmon';
              }
            }
          }
        });

        // Безопасный перехват клика по созданным лупам фаланги (Безопасный MV3 вызов через window.open)
        _('[data-phalanx]', true)?.forEach(btn => {
          if (!btn.dataset.handlerAttached) {
            btn.dataset.handlerAttached = "true";
            btn.addEventListener('click', function(e) {
              e.preventDefault();
              const url = this.getAttribute('data-phalanx');
              window.open(url, 'phalanx', 'width=750,height=550,scrollbars=yes,resizable=yes');
            });
          }
        });
      }
    }
  }

  // Делаем легкую пастельную подсветку пустых разделителей таблиц
  try {
    const emptyThs = [..._('th[colspan="8"]', true)].filter(x => x.classList.length === 0 && x.textContent.trim() === '');
    emptyThs.forEach(th => th.classList.add('xan-pastel-splitter'));
  } catch (e) {
    console.error('[XAN Fleet] Ошибка стилизации пустой th:', e);
  }

  // ==========================================
  // БЛОК 3: ДИНАМИЧЕСКИЙ ТАЙМЕР ОПАСНОГО ВРЕМЕНИ ПОДЛЁТА
  // ==========================================
  const thHoverBlocks = _('.th-hover.shadow-hover', true);
  if (thHoverBlocks && thHoverBlocks.length >= 2) {
    const _th = thHoverBlocks[1].querySelectorAll('th:nth-child(6)');

    if (_th && _th.length > 0) {
      _th.forEach(x => {
        const divEl = x.querySelector('div');
        if (!divEl) return;

        const textParts = x.innerText.split(/[,\s]+/);
        if (textParts.length < 2) return;

        const dat = textParts[0];
        const time = textParts[1];

        const reversedDate = dat.split('.').reverse().join('-');
        const thisTimer = Date.parse(`${reversedDate}T${time}`);

        if (!isNaN(thisTimer)) {
          const deltaMinutes = Math.floor((thisTimer - Date.now()) / 1000 / 60);
          const alertLimit = 3; // Внимание, если до контакта менее 3-х минут

          if (deltaMinutes < alertLimit) {
            divEl.classList.add('xan-time-critical');
          }
        }
      });
    }
  }
}
