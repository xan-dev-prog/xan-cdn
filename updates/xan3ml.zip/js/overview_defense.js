// js/overview_defense.js — Поиск вражеских атак, управление галками и сиреной (Часть 1)

import { _ } from './query.js';
import { WARNINGS } from './game_data.js';

// Флаг, чтобы повесить глобальный слушатель кликов строго один раз за жизнь страницы
let isClickHandlerInitialized = false;

// ГЛАВНАЯ ФУНКЦИЯ МОДУЛЯ
export function checkEnemyAttack() {
    console.log("[Game Guard] Проверка воздушного пространства на наличие атак...");
    
    // Ищем все таймеры, начинающиеся с bxxo (Атака на пользователя)
    const attackElements = _('div[id^=bxxo]', true);
    
    if (attackElements.length === 0) {
        console.log("[Game Guard] Небо чистое. Угроз не обнаружено.");
        return;
    }

	let unreadAttacksCount = 0;
	const melody = localStorage.xan3_melody || '1.mp3';

	attackElements.forEach(el => {
		const parentTh = el.closest('th') || el.parentElement;
		const nextTh = parentTh?.nextElementSibling;
		const missionText = nextTh ? nextTh.textContent : '';

		// Мультиязычный фильтр: Ищем "Атаковать/Атакувати" или "Разрушить/Руйнувати", отсекаем "Дружественный/Дружній"
		const isAttack = missionText.includes(t('od_attack_word'));
		const isDestroy = missionText.includes(t('od_destroy_word'));
		const isFriendly = missionText.includes(t('od_friendly_word'));
		const hasGoldText = parentTh?.closest('tr')?.querySelector('[style="color:gold"]');

		if ((isAttack || isDestroy || !hasGoldText) && !isFriendly) {
            
			const id = el.getAttribute('id');
			const timerText = el.nextElementSibling ? el.nextElementSibling.textContent : '';
            
			const isSeen = localStorage[id] === timerText;
			const picColor = isSeen ? 'green' : 'red';
			const statusAttr = isSeen ? 'seen' : 'notseen';

			if (!isSeen) {
				unreadAttacksCount++;
			}

			// Если галка для этого флота ещё не нарисована — добавляем её
			if (nextTh && !nextTh.querySelector(`.galka[data-id="${id}"]`)) {
				nextTh.insertAdjacentHTML('afterbegin', `
					<div class="galka-wrapper" style="cursor:pointer; width:16px; height:16px; float:right; margin:0px 3px;">
						<img class="galka" 
                             data-status="${statusAttr}" 
                             data-id="${id}" 
                             data-timer="${timerText}" 
                             src="${chrome.runtime.getURL('images/tick-' + picColor + '.png')}" 
                             alt="" 
                             title="id = ${id} timer = ${timerText}" />
					</div>
				`);
			}
		}
	});

	// Безопасный перехват кликов по созданным галкам (Делегирование событий)
	if (!isClickHandlerInitialized) {
		document.addEventListener('click', function(e) {
			const galka = e.target.closest('.galka');
			if (!galka) return;

			e.stopPropagation();
            
			const id = galka.getAttribute('data-id');
			const timer = galka.getAttribute('data-timer');
			const currentStatus = galka.getAttribute('data-status');

			if (currentStatus === 'notseen') {
				localStorage[id] = timer;
				galka.setAttribute('src', chrome.runtime.getURL('images/tick-green.png'));
				galka.setAttribute('data-status', 'seen');
			} else {
				localStorage.removeItem(id);
				galka.setAttribute('src', chrome.runtime.getURL('images/tick-red.png'));
				galka.setAttribute('data-status', 'notseen');
			}

			// Пересчитываем оставшиеся красные галки
			const allGalkas = Array.from(document.querySelectorAll('.galka'));
			const checkUnread = allGalkas.filter(g => g.getAttribute('data-status') === 'notseen');
            
			if (checkUnread.length === 0) {
				window.location.reload(); 
			}
		});
        
		isClickHandlerInitialized = true;
		console.log("[Game Guard] Глобальный слушатель кликов для галок успешно инициализирован.");
	}

		// Если есть хоть одна непрочитанная (красная) атака — включаем боевую тревогу!
	if (unreadAttacksCount > 0) {
		console.warn('[Game Guard] ОБНАРУЖЕНО НЕПРОЧИТАННЫХ АТАК: ' + unreadAttacksCount + '! Врубаем сирену.');
		triggerTitleAlert();
		
		// БЕЗ РЕФАКТОРИНГА: Проверяем, активен ли режим звукового оповещения в настройках
		if (localStorage.getItem('xan3_siren_active') !== '0') {
			triggerAudioAlarm(melody);
		} else {
			console.log("[Game Guard] Звуковое оповещение отключено пользователем в настройках.");
			// Принудительно показываем красный блок атаки, даже если звук выключен
			const notifierBlock = _('#attack-notifier');
			if (notifierBlock) {
				notifierBlock.style.display = 'block';
			}
		} // <-- Закрыли else
	} // <-- Закрыли if (unreadAttacksCount > 0)
} // <-- Закрыли функцию checkEnemyAttack


// js/overview_defense.js — ЧАСТЬ 2 ИЗ 2

// Логика циклической смены заголовка вкладки для привлечения внимания
function triggerTitleAlert() {
    // Защита от двойного запуска интервала, если функция вызвалась повторно
    if (window.titleAlertInterval) return;

    // Запоминаем тот тайтл, который РЕАЛЬНО горит во вкладке прямо сейчас (со случайными минутами от стелс-модуля)
    const baseTitle = document.title;

    window.titleAlertInterval = setInterval(() => {
        // Если сирену уже выключили, а интервал почему-то вызвался — аварийно глушим его
        if (!window.titleAlertInterval) return;

        // Выбираем случайную фразу из нашего массива WARNINGS в game_data.js
        const randomIndex = Math.floor(Math.random() * WARNINGS.length);
        const warningPhrase = WARNINGS[randomIndex];
        
        // Перемигиваем: если сейчас горит базовый тайтл — ставим тревогу, иначе возвращаем базовый
        document.title = document.title === baseTitle ? warningPhrase : baseTitle;
    }, 1000);
}

// Логика зацикленного воспроизведения сирены тревоги
function triggerAudioAlarm(melodyName) {
    const notifierBlock = _('#attack-notifier');
    if (notifierBlock) {
        notifierBlock.style.display = 'block'; // Показываем скрытый красный блок атаки
    }

    // Создаем аудио-объект сирены (Синглтон — создается строго 1 раз)
    if (!window.guardAlarmAudio) {
        window.guardAlarmAudio = new Audio();
        window.guardAlarmAudio.src = chrome.runtime.getURL('sound/' + melodyName);
        window.guardAlarmAudio.loop = true; // Зацикливаем трек
        
        window.guardAlarmAudio.play().catch(err => {
            console.log("[Game Guard] Автоплей звука заблокирован. Ожидаем активности игрока...");
            
            const startOnInteraction = () => {
                if (window.guardAlarmAudio) {
                    window.guardAlarmAudio.play().catch(() => {});
                }
                document.removeEventListener('click', startOnInteraction);
            };
            document.addEventListener('click', startOnInteraction);
        });
    }

    // Защита от накопления слушателей клика на кнопке "Закрыть"
    const closeBtn = _('#ntfbtn');
    if (closeBtn && !closeBtn.hasAttribute('data-handler-attached')) {
        closeBtn.addEventListener('click', () => {
            if (window.guardAlarmAudio) {
                window.guardAlarmAudio.pause(); // Глушим сирену
            }
            if (window.titleAlertInterval) {
                clearInterval(window.titleAlertInterval); // Останавливаем мигание вкладки
                window.titleAlertInterval = null;
            }
            if (notifierBlock) {
                notifierBlock.style.display = 'none'; // Прячем красный блок
            }
            
            // Вместо хардкода возвращаем тот тайтл, который был до включения сирены (с динамическим переводом)
            const currentMinutesInTitle = document.title.match(/\d+/);
            const minutes = currentMinutesInTitle ? currentMinutesInTitle[0] : (localStorage.xan3_intto || 45);
            document.title = t('od_overview_title').replace('{min}', minutes);
        });

        // Помечаем кнопку атрибутом, чтобы повторно не вешать на неё клик при следующем тике таймера
        closeBtn.setAttribute('data-handler-attached', 'true');
    }
}
