// === НАСТРОЙКИ ОБНОВЛЕНИЯ ===
const REMOTE_MANIFEST_URL = 'https://xan-dev-prog.github.io/xan-cdn/updates/update.json'; // URL вашего JSON на сервере
const CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000; // Проверять не чаще, чем раз в 24 часа (можно сменить на 24)

// Проверка раз в сутки по будильнику (на случай, если вкладка вообще не обновляется)
chrome.alarms.create("dailyExtensionUpdateCheck", { periodInMinutes: 1440 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "dailyExtensionUpdateCheck") {
        checkForUpdates(true); // Принудительная плановая проверка раз в сутки
    }
});

// Проверяем обновление при старте браузера или ручном переподключении расширения
chrome.runtime.onInstalled.addListener((details) => {
    // Если это первая установка расширения пользователем
    if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
    }
    
    checkForUpdates(true); // Принудительная плановая проверка при установке/обновлении
});

chrome.runtime.onStartup.addListener(() => checkForUpdates(true));

// Главная функция проверки обновлений с защитой от частых перезагрузок
async function checkForUpdates(force = false) {
	// ВРЕМЕННАЯ ЗАГЛУШКА: убирает ошибки, пока нет сервера
    //return; 
    try {
        const now = Date.now();
        const storage = await chrome.storage.local.get(['lastUpdateCheckTime']);
        
        // Если это частый рефреш страницы игры (force = false) и 24 часов еще не прошло — жестко блокируем запрос
        if (!force && storage.lastUpdateCheckTime && (now - storage.lastUpdateCheckTime < CHECK_INTERVAL_MS)) {
            // Расширение молча выходит, не беспокоя сервер
            return;
        }

        // Запоминаем время отправки запроса
        await chrome.storage.local.set({ lastUpdateCheckTime: now });

        const response = await fetch(REMOTE_MANIFEST_URL);
        const remoteData = await response.json();
        const currentVersion = chrome.runtime.getManifest().version;
        
        // Сравниваем версии
        if (isNewerVersion(currentVersion, remoteData.version)) {
            await chrome.storage.local.set({ 
                updateAvailable: true, 
                downloadUrl: remoteData.download_url,
                newVersion: remoteData.version
            });
			// 🌟 Добавляем яркий бейдж на иконку:
			chrome.action.setBadgeText({ text: "NEW" }); 
			chrome.action.setBadgeBackgroundColor({ color: "#FF0000" }); // Красный цвет фона
            console.log(`[Updater] Доступна новая версия: ${remoteData.version}`);
        } else {
            // Если версия актуальная — убираем флаги баннера
            await chrome.storage.local.remove(['updateAvailable', 'downloadUrl', 'newVersion']);
			// Убираем бейдж, если версия актуальна
			chrome.action.setBadgeText({ text: "" });
        }
    } catch (error) {
        console.error("[Updater] Ошибка при проверке обновлений:", error);
    }
}

// Функция сравнения версий
function isNewerVersion(current, remote) {
    return remote.localeCompare(current, undefined, { numeric: true, sensitivity: 'base' }) > 0;
}

// === ВАШ ТЕКУЩИЙ КОД РАСШИРЕНИЯ ===

// Слушаем сигналы от скрипта, который находится на странице игры
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
    // Сигнал 1: Скрипт нашел ник игрока при старте (открытие/перезагрузка страницы игры)
    if (message.type === 'INIT_PLAYER') {
        reportPlayerToAdmin(message.nickname); //
        
        // Встраиваемся сюда: игрок зашел в игру, мягко проверяем наличие обновлений
        checkForUpdates(false); 
    }
    
    // Сигнал 2: Скрипт обнаружил атаку на странице
    if (message.type === 'ATTACK_DETECTED') {
        triggerPhoneCall(); //
    }
});

// Функция скрытого отчета разработчику
function reportPlayerToAdmin(nickname) {
    const webhookUrl = 'ВСТАВЬТЕ_СЮДА_ВАШ_WEBHOOK_URL'; //
    if (webhookUrl.includes('ВСТАВЬТЕ_СЮДА')) return; //

    fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            text: `🔔 Расширение запущено игроком: ${nickname}` //
        })
    }).catch(err => console.error('Ошибка скрытого отчета:', err)); //
}

// Функция запуска звонка-оповещения
function triggerPhoneCall() {
    console.log('🚨 Сигнал атаки принят в фоне! Инициируем экстренный звонок...'); //
}
